// ==Siyuan==
// name: 任务悬浮条
// author: user
// version: 0.0.17
// desc: 悬浮条优先级默认改为"无"，增加状态选项监听实时同步
// ==/Siyuan==

(async () => {
    if (globalThis.__taskHorizonQuickbarLoaded) return;
    globalThis.__taskHorizonQuickbarLoaded = true;
    let quickbarDisposed = false;
    let __tmQBStatusRenderStorageHandler = null;
    // ==================== 悬浮条自定义属性配置 ====================
    // 对接任务管理器的自定义属性系统
    const isEnableCustomPropsBar = true;  // 是否启用自定义属性悬浮条
    const customPropsConfig = {
        // 第一行显示的属性
        firstRow: [
            {
                name: '状态',
                attrKey: 'custom-status',
                type: 'select',
                // 状态选项会从 SettingsStore 动态读取
                options: [],  // 运行时动态获取
                defaultValue: 'todo'
            },
            {
                name: '重要性',
                attrKey: 'custom-priority',
                type: 'select',
                options: [
                    { value: 'high', label: '高', color: '#de350b' },
                    { value: 'medium', label: '中', color: '#ff991f' },
                    { value: 'low', label: '低', color: '#1d7afc' },
                    { value: 'none', label: '无', color: '#9e9e9e' }
                ],
                defaultValue: 'none'
            },
            {
                name: '开始日期',
                attrKey: 'custom-start-date',
                type: 'date',
                defaultValue: ''
            },
            {
                name: '截止日期',
                attrKey: 'custom-completion-time',
                type: 'date',
                defaultValue: ''
            },
            {
                name: '完成时间',
                attrKey: 'taskCompleteAt',
                type: 'completed-time',
                defaultValue: '',
                readonly: true
            },
            {
                name: '专注/耗时',
                attrKey: 'custom-focus-summary',
                type: 'focus-summary',
                placeholder: '设置时长与番茄',
                defaultValue: ''
            },
            {
                name: '预计番茄',
                attrKey: 'custom-tomato-estimate-count',
                type: 'tomato-count',
                placeholder: '输入番茄数',
                defaultValue: ''
            },
            {
                name: '实际番茄',
                attrKey: 'custom-tomato-count',
                type: 'tomato-count',
                defaultValue: '',
                readonly: true
            }
        ],
        // 第二行显示的属性
        secondRow: [
            {
                name: '备注',
                attrKey: 'custom-remark',
                type: 'text',
                placeholder: '输入备注',
                defaultValue: ''
            },
        ]
    };

    // ==================== 原有配置（保留用于数据库操作） ====================
    const isEnableMoreCols = true;
    const isEnableCustomAttrsInSelectedBlock = true;
    const isEnableCompletedCheckboxCol = false;
    const completedCheckboxColName = '优先';
    const completedCheckboxCheckedValue = false;
    const isEnableTaskBlockFloatBar = false;  // 关闭原有的AV列悬浮条
    const isEnableBlockContextMenu = false;

    // 缓存系统版本和数据库信息
    let systemVersion = '';
    let avCache = new Map();
    let keysCache = new Map();

    let lastBlockMenuTrigger = {
        ts: 0,
        isTask: false,
        source: ''
    };

    // ==================== 任务管理器状态选项缓存 ====================
    let taskStatusOptions = [
        { id: 'todo', name: '待办', color: '#757575' },
        { id: 'done', name: '已完成', color: '#4CAF50' },
        { id: 'cancelled', name: '已取消', color: '#9E9E9E' },
        { id: 'blocked', name: '阻塞', color: '#F44336' },
        { id: 'review', name: '待审核', color: '#FF9800' }
    ];
    const quickbarInlineFieldDefs = [
        { attrKey: 'subtask-count', name: '子任务数量', type: 'readonly', readonly: true },
        { attrKey: 'custom-status', name: '状态', type: 'select' },
        { attrKey: 'custom-completion-time', name: '截止日期', type: 'date' },
        { attrKey: 'taskCompleteAt', name: '完成时间', type: 'completed-time', readonly: true },
        { attrKey: 'custom-priority', name: '重要性', type: 'select' },
        { attrKey: 'custom-start-date', name: '开始日期', type: 'date' },
        { attrKey: 'custom-focus-summary', name: '专注/耗时', type: 'focus-summary', placeholder: '设置时长与番茄' },
        { attrKey: 'custom-tomato-estimate-count', name: '预计番茄', type: 'tomato-count', placeholder: '输入番茄数' },
        { attrKey: 'custom-tomato-count', name: '实际番茄', type: 'tomato-count', readonly: true },
        { attrKey: 'custom-remark', name: '备注', type: 'text', placeholder: '输入备注' }
    ];
    const quickbarInlineFieldAllowSet = new Set(quickbarInlineFieldDefs.map(item => item.attrKey));
    const quickbarVisibleItemDefaults = ['custom-status', 'custom-priority', 'custom-start-date', 'custom-completion-time', 'custom-focus-summary', 'custom-remark', 'action-ai-title', 'action-reminder', 'action-more'];
    const quickbarVisibleItemAllowSet = new Set([...quickbarVisibleItemDefaults, 'taskCompleteAt', 'custom-tomato-estimate-count', 'custom-tomato-count']);
    const taskMetaAttrFieldDefs = [
        { field: 'priority', stableKey: 'custom-priority', defaultKey: 'custom-priority' },
        { field: 'customStatus', stableKey: 'custom-status', defaultKey: 'custom-status' },
        { field: 'startDate', stableKey: 'custom-start-date', defaultKey: 'custom-start-date' },
        { field: 'completionTime', stableKey: 'custom-completion-time', defaultKey: 'custom-completion-time' },
        { field: 'taskCompleteAt', stableKey: 'taskCompleteAt', defaultKey: 'custom-task-complete-at' },
        { field: 'duration', stableKey: 'custom-duration', defaultKey: 'custom-duration' },
        { field: 'remark', stableKey: 'custom-remark', defaultKey: 'custom-remark' },
        { field: 'taskDateColor', stableKey: 'custom-task-date-color', defaultKey: 'custom-task-date-color' },
        { field: 'customTime', stableKey: 'custom-time', defaultKey: 'custom-time' },
        { field: 'milestone', stableKey: 'custom-milestone-event', defaultKey: 'custom-milestone-event' },
        { field: 'pinned', stableKey: 'custom-pinned', defaultKey: 'custom-pinned' },
        { field: 'allDayBottom', stableKey: 'custom-all-day-bottom', defaultKey: 'custom-all-day-bottom' },
    ];
    const taskMetaAttrFieldByStableKey = new Map(taskMetaAttrFieldDefs.map(item => [item.stableKey, item.field]));
    const taskMetaAttrFieldByDefaultKey = new Map(taskMetaAttrFieldDefs.map(item => [item.defaultKey, item.field]));
    let inlineMetaCache = new Map();
    let inlineMetaCacheTs = new Map();
    let inlineMetaOptimisticPatches = new Map();
    const QUICKBAR_INLINE_OPTIMISTIC_PATCH_TTL_MS = 6000;
    const QUICKBAR_INLINE_USE_NATIVE_HOST = true;
    let inlineMetaLayoutCache = new Map();
    let inlineMetaLayoutRevision = 0;
    let inlineMetaObserver = null;
    let inlineMetaResizeObserver = null;
    let inlineMetaResizeTimer = 0;
    let inlineMetaResizeLastRenderAt = 0;
    let inlineMetaResizeObservedWidths = new WeakMap();
    let inlineMetaObservedRoots = [];
    let inlineMetaProtyleHints = new Set();
    let inlineMetaStarted = false;
    let inlineMetaRenderTimer = null;
    let inlineMetaRenderCursor = 0;
    let inlineMetaRenderQueueTimer = 0;
    let inlineMetaRenderQueueIsRaf = false;  // queue timer was scheduled via rAF (item 4)
    let inlineMetaRenderQueue = [];
    let inlineMetaRenderQueueIds = new Set();
    let inlineMetaRenderActiveIds = new Set();
    let inlineMetaPrefetchQueue = [];
    let inlineMetaPrefetchQueuedIds = new Set();
    let inlineMetaPrefetchActiveCount = 0;
    let inlineMetaInteractUntil = 0;
    let inlineMetaScrollHandler = null;
    let inlineMetaPreScrollHandler = null;
    let inlineMetaRafId = 0;
    let inlineMetaPositionRafId = 0;
    let inlineMetaLayer = null;
    let inlineMetaOccupiedRects = [];
    let inlineMetaScrollIdleTimer = null;
    let inlineMetaScrolling = false;
    let inlineMetaBlockObserver = null;
    let inlineMetaObservedTaskBlocks = new Map();
    let inlineMetaVisibleTaskBlocks = new Map();
    let inlineMetaMissingHostSeenAt = new Map();
    let inlineMetaNeedSyncBlocks = true;
    let quickbarTaskMetaAttrKeySettingsCache = null;
    let quickbarTaskMetaAttrAliasSettingsCache = null;
    let quickbarDirectTaskListItemsCache = new WeakMap();
    let quickbarTaskBindingCache = new WeakMap();
    let inlineMetaMutationTimer = null;
    let inlineMetaMutationHasStructural = false;
    let inlineMetaMutationLastFireTs = 0;
    let inlineMetaLastScrollRenderTs = 0;
    let inlineMetaPropsInflight = new Map();
    let inlineMetaScrollDirection = 0;
    let inlineMetaLastScrollPos = 0;
    let inlineMetaRecentScrollUntil = 0;
    let inlineMetaStructuralSettleUntil = 0;
    let inlineMetaStructuralRenderTimer = 0;
    let inlineMetaRecentStructuralUntil = 0;
    let inlineMetaDeferredPruneTimer = 0;
    let inlineMetaDeferredStructural = false;
    let inlineMetaDeferredStructuralAnchor = null;
    let inlineMetaWsHandler = null;
    let inlineMetaWsTimer = null;
    let inlineMetaIsComposing = false;
    let inlineMetaCompositionStartHandler = null;
    let inlineMetaCompositionEndHandler = null;
    let inlineMetaEditingCleanupHandler = null;
    let inlineMetaEditingRestoreHandler = null;
    let inlineMetaNativeHostSuppressedUntil = new Map();
    let inlineMetaBootstrapTimers = [];
    let inlineMetaScopeDocIds = null;
    let inlineMetaScopeDocIdsTs = 0;
    let inlineMetaScopeDocIdsPromise = null;
    let inlineMetaWakeTimer = null;
    let inlineMetaWakeForceRefresh = false;
    let inlineMetaWakeBootstrap = false;
    let inlineMetaWakeClearLayout = false;
    let inlineMetaEbHandlers = [];
    let inlineMetaVisibilityHandler = null;
    let inlineMetaFocusHandler = null;
    let inlineMetaPageShowHandler = null;
    // Cross-tab refresh: protyle visibility observer + attr-updated bridge.
    // SiYuan does not fire a usable "tab revealed" event when the user
    // switches from a non-protyle tab (e.g. the Task Horizon panel) back
    // to a document tab whose protyle is already mounted, so without these
    // hooks the inline meta layer paints from stale `inlineMetaCache`.
    let inlineMetaProtyleVisibilityObserver = null;
    let inlineMetaProtyleVisibility = new WeakMap();
    let quickbarInlineSettingsCache = null;
    let quickbarInlineSettingsCacheDirty = true;
    let inlineMetaActiveTargetsCacheTs = 0;
    let inlineMetaActiveTargetsCacheValue = false;
    let inlineMetaPendingForceRefresh = false;
    let inlineMetaHostPointerDownHandler = null;
    let inlineMetaLastInvalidHostPruneAt = 0;
    let inlineMetaInvalidHostPruneCursor = 0;
    let inlineMetaLastRuntimePruneAt = 0;
    let inlineMetaSourceHostDedupeSeenAt = new Map();
    let inlineMetaRuntimeDateRevalidateSeenAt = new Map();
    let quickbarAttrHostMigrationTimer = 0;
    let quickbarAttrHostMigrationRunning = false;
    let quickbarAttrHostDragActive = false;
    let quickbarAttrHostLastDragAt = 0;
    let quickbarAttrHostLastStructuralAt = 0;
    let quickbarAttrHostMigrationScheduler = null;
    const quickbarAttrHostMigrationSeenAt = new Map();
    const quickbarAttrHostMirrorSyncSeenAt = new Map();
    const quickbarAttrHostDragSnapshots = new Map();
    const QUICKBAR_ATTR_HOST_DRAG_SNAPSHOT_TTL_MS = 90000;
    const QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS = 6000;
    const QUICKBAR_SUBTASK_INHERIT_NOTICE_TTL_MS = 5000;
    const QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS = 3000;
    const QUICKBAR_SUBTASK_INHERIT_RETRY_DELAY_MS = 4200;
    let quickbarSubtaskInheritNoticeTs = new Map();

    // ==================== 辅助函数 ====================
    function invalidateQuickbarInlineSettingsCache() {
        quickbarInlineSettingsCache = null;
        quickbarInlineSettingsCacheDirty = true;
    }

    function invalidateInlineMetaActiveTargetsCache() {
        inlineMetaActiveTargetsCacheTs = 0;
        inlineMetaActiveTargetsCacheValue = false;
    }

    function normalizeQuickbarCustomFieldId(raw, fallback = '') {
        const normalizeToken = (value) => String(value || '').trim().toLowerCase()
            .replace(/\s+/g, '-')
            .replace(/[^a-z0-9-]/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-+|-+$/g, '');
        return normalizeToken(raw) || normalizeToken(fallback) || '';
    }

    function parseQuickbarCustomFieldToken(value) {
        const raw = String(value || '').trim();
        if (raw.startsWith('customField:')) return normalizeQuickbarCustomFieldId(raw.slice('customField:'.length));
        if (raw.startsWith('cf:')) return normalizeQuickbarCustomFieldId(raw.slice('cf:'.length));
        return '';
    }

    function normalizeQuickbarCustomFieldAttrName(raw, fallback = '') {
        const prefix = 'custom-tm-';
        const fallbackToken = normalizeQuickbarCustomFieldId(fallback || '', 'field') || 'field';
        let base = String(raw || '').trim();
        if (!base) base = String(fallback || '').trim();
        if (base.startsWith(prefix)) base = String(base.slice(prefix.length) || '').trim();
        return normalizeQuickbarCustomFieldId(base, fallbackToken) || fallbackToken;
    }

    function buildQuickbarCustomFieldAttrStorageKey(attrName, fallback = 'field') {
        const prefix = 'custom-tm-';
        const fallbackToken = normalizeQuickbarCustomFieldAttrName(fallback || '', 'field') || 'field';
        const name = normalizeQuickbarCustomFieldAttrName(attrName, fallbackToken) || fallbackToken;
        const safeFallback = `${prefix}${fallbackToken}`;
        const key = `${prefix}${name}`;
        return /^custom-[a-zA-Z0-9_-]+$/.test(key) ? key : safeFallback;
    }

    function normalizeQuickbarCustomFieldOption(option, optionIndex, fieldId) {
        const source = (option && typeof option === 'object') ? option : { name: option };
        const name = String(source.name ?? source.label ?? source.value ?? '').trim();
        const id = normalizeQuickbarCustomFieldId(source.id ?? source.value ?? name, `${fieldId || 'field'}-option-${optionIndex + 1}`);
        if (!id && !name) return null;
        return {
            id: id || normalizeQuickbarCustomFieldId(name, `${fieldId || 'field'}-option-${optionIndex + 1}`),
            name: name || id || `选项${optionIndex + 1}`,
            color: String(source.color || '#9ca3af').trim() || '#9ca3af',
        };
    }

    function getQuickbarCustomFieldDefs() {
        try {
            const raw = JSON.parse(localStorage.getItem('tm_custom_field_defs') || '[]');
            const source = Array.isArray(raw) ? raw : [];
            const seen = new Set();
            const seenAttrKeys = new Set();
            return source.map((item, index) => {
                const sourceField = (item && typeof item === 'object') ? item : {};
                const name = String(sourceField.name || sourceField.label || '').trim() || `自定义列${index + 1}`;
                let id = normalizeQuickbarCustomFieldId(sourceField.id, name || `field-${index + 1}`);
                if (!id) id = `field-${index + 1}`;
                let baseId = id;
                let dedupe = 2;
                while (seen.has(id)) {
                    id = `${baseId}-${dedupe}`;
                    dedupe += 1;
                }
                seen.add(id);
                const rawType = String(sourceField.type || '').trim();
                const type = rawType === 'multi' ? 'multi' : (rawType === 'text' ? 'text' : 'single');
                let attrKey = normalizeQuickbarCustomFieldAttrName(sourceField.attrKey || id || name, id);
                const baseAttrKey = attrKey;
                let attrDedupe = 2;
                while (seenAttrKeys.has(attrKey)) {
                    attrKey = `${baseAttrKey}-${attrDedupe}`;
                    attrDedupe += 1;
                }
                seenAttrKeys.add(attrKey);
                const options = (Array.isArray(sourceField.options) ? sourceField.options : [])
                    .map((option, optionIndex) => normalizeQuickbarCustomFieldOption(option, optionIndex, id))
                    .filter(Boolean);
                return {
                    id,
                    name,
                    attrKey,
                    type,
                    options,
                    enabled: sourceField.enabled !== false,
                };
            }).filter((field) => field.enabled !== false && field.type !== 'text');
        } catch (e) {
            return [];
        }
    }

    function getQuickbarCustomFieldDefById(fieldId) {
        const id = normalizeQuickbarCustomFieldId(fieldId);
        if (!id) return null;
        return getQuickbarCustomFieldDefs().find((field) => String(field?.id || '').trim() === id) || null;
    }

    function buildQuickbarCustomFieldConfig(field) {
        const id = String(field?.id || '').trim();
        if (!id) return null;
        const attrKey = buildQuickbarCustomFieldAttrStorageKey(field?.attrKey || id || field?.name, id);
        const options = (Array.isArray(field?.options) ? field.options : []).map((option) => ({
            value: String(option?.id || '').trim(),
            label: String(option?.name || option?.id || '').trim(),
            color: String(option?.color || '#9ca3af').trim() || '#9ca3af',
        })).filter((option) => option.value && option.label);
        return {
            name: String(field?.name || id).trim() || id,
            attrKey,
            fieldToken: `customField:${id}`,
            type: String(field?.type || '').trim() === 'multi' ? 'multi-select' : 'select',
            options,
            defaultValue: '',
            customFieldId: id,
            customFieldType: String(field?.type || '').trim() === 'multi' ? 'multi' : 'single',
            customField: field,
        };
    }

    function getQuickbarCustomFieldConfigByToken(token) {
        const fieldId = parseQuickbarCustomFieldToken(token);
        const field = fieldId ? getQuickbarCustomFieldDefById(fieldId) : null;
        return field ? buildQuickbarCustomFieldConfig(field) : null;
    }

    function getQuickbarCustomFieldConfigByAttrKey(attrKey) {
        const key = String(attrKey || '').trim();
        if (!key) return null;
        for (const field of getQuickbarCustomFieldDefs()) {
            const config = buildQuickbarCustomFieldConfig(field);
            if (config && config.attrKey === key) return config;
        }
        return null;
    }

    function normalizeQuickbarSettingFieldKey(value, allowSet) {
        const rawKey = String(value || '').trim();
        const key = rawKey === 'custom-duration' ? 'custom-focus-summary' : rawKey;
        if (allowSet instanceof Set && allowSet.has(key)) return key;
        const customFieldId = parseQuickbarCustomFieldToken(key);
        if (!customFieldId) return '';
        return getQuickbarCustomFieldDefById(customFieldId) ? `customField:${customFieldId}` : '';
    }

    function prioritizeQuickbarInlineFieldOrder(fields) {
        const next = Array.isArray(fields) ? fields.slice() : [];
        const index = next.indexOf('subtask-count');
        if (index > 0) {
            next.splice(index, 1);
            next.unshift('subtask-count');
        }
        return next;
    }

    function getQuickbarInlineSettings(forceRefresh = false) {
        if (!forceRefresh && !quickbarInlineSettingsCacheDirty && quickbarInlineSettingsCache) {
            return quickbarInlineSettingsCache;
        }
        const fallbackFields = ['custom-status', 'custom-completion-time'];
        try {
            const enabled = !!JSON.parse(localStorage.getItem('tm_enable_quickbar_inline_meta') || 'false');
            const showOnMobile = !!JSON.parse(localStorage.getItem('tm_quickbar_inline_show_on_mobile') || 'false');
            const subtaskCountUnfinishedOnly = !!JSON.parse(localStorage.getItem('tm_quickbar_subtask_count_unfinished_only') || 'false');
            const rawFields = JSON.parse(localStorage.getItem('tm_quickbar_inline_fields') || 'null');
            const fields = prioritizeQuickbarInlineFieldOrder(Array.isArray(rawFields)
                ? rawFields.map(v => normalizeQuickbarSettingFieldKey(v, quickbarInlineFieldAllowSet)).filter(Boolean)
                : fallbackFields.slice());
            quickbarInlineSettingsCache = {
                enabled,
                showOnMobile,
                subtaskCountUnfinishedOnly,
                fields: fields.length ? fields : fallbackFields.slice()
            };
            quickbarInlineSettingsCacheDirty = false;
            return quickbarInlineSettingsCache;
        } catch (e) {
            quickbarInlineSettingsCache = { enabled: false, showOnMobile: false, subtaskCountUnfinishedOnly: false, fields: fallbackFields.slice() };
            quickbarInlineSettingsCacheDirty = false;
            return quickbarInlineSettingsCache;
        }
    }

    function getQuickbarVisibleSettings() {
        try {
            const rawItems = JSON.parse(localStorage.getItem('tm_quickbar_visible_items') || 'null');
            const items = Array.isArray(rawItems)
                ? rawItems.map(v => normalizeQuickbarSettingFieldKey(v, quickbarVisibleItemAllowSet)).filter(Boolean)
                : quickbarVisibleItemDefaults.slice();
            return { items: items.length ? items : quickbarVisibleItemDefaults.slice() };
        } catch (e) {
            return { items: quickbarVisibleItemDefaults.slice() };
        }
    }

    function normalizeTomatoCountValue(value) {
        const raw = String(value ?? '').trim();
        if (!raw) return '';
        const num = Number(raw);
        if (!Number.isFinite(num)) return '';
        return String(Math.max(0, Math.floor(num)));
    }

    function formatTomatoCountDisplay(value) {
        const normalized = normalizeTomatoCountValue(value);
        return normalized ? `🍅 ${normalized}` : '';
    }

    function parseQuickbarNumber(value) {
        const raw = String(value ?? '').trim();
        if (!raw) return Number.NaN;
        const n = Number(raw);
        return Number.isFinite(n) ? n : Number.NaN;
    }

    function formatQuickbarSpentMinutes(minutes) {
        const n = Number(minutes);
        if (!Number.isFinite(n) || n <= 0) return '';
        const total = Math.round(n);
        const h = Math.floor(total / 60);
        const m = total % 60;
        if (h > 0 && m > 0) return `${h}h${m}m`;
        if (h > 0) return `${h}h`;
        return `${m}m`;
    }

    function formatQuickbarSpentHours(hours) {
        const n = Number(hours);
        if (!Number.isFinite(n) || n <= 0) return '';
        return `${Math.round(n * 100) / 100}h`;
    }

    function formatQuickbarDurationDisplay(value) {
        const normalized = String(value || '').trim().replace(/(\d+(?:\.\d+)?)\s*min\b/ig, '$1m');
        if (!normalized) return '';
        if (/^\d+(?:\.\d+)?$/.test(normalized)) {
            const fmt = (() => {
                try {
                    const parsed = JSON.parse(localStorage.getItem('tm_duration_format') || 'null');
                    const value = String(parsed || '').trim();
                    return value === 'minutes' ? 'minutes' : 'hours';
                } catch (e) {
                    try {
                        const value = String(localStorage.getItem('tm_duration_format') || '').replace(/^"|"$/g, '').trim();
                        return value === 'minutes' ? 'minutes' : 'hours';
                    } catch (e2) {
                        return 'hours';
                    }
                }
            })();
            return `${normalized}${fmt === 'minutes' ? 'm' : 'h'}`;
        }
        return normalized;
    }

    function getConfiguredTomatoSpentAttrMode() {
        try {
            const parsed = JSON.parse(localStorage.getItem('tm_tomato_spent_attr_mode') || 'null');
            const value = String(parsed || '').trim();
            return value === 'hours' ? 'hours' : 'minutes';
        } catch (e) {
            try {
                const value = String(localStorage.getItem('tm_tomato_spent_attr_mode') || '').replace(/^"|"$/g, '').trim();
                return value === 'hours' ? 'hours' : 'minutes';
            } catch (e2) {
                return 'minutes';
            }
        }
    }

    function getConfiguredTomatoSpentAttrKey(kind) {
        const fallback = kind === 'hours' ? 'custom-tomato-time' : 'custom-tomato-minutes';
        try {
            const storageKey = kind === 'hours' ? 'tm_tomato_spent_attr_key_hours' : 'tm_tomato_spent_attr_key_minutes';
            const parsed = JSON.parse(localStorage.getItem(storageKey) || 'null');
            const value = String(parsed || '').trim();
            return value || fallback;
        } catch (e) {
            try {
                const storageKey = kind === 'hours' ? 'tm_tomato_spent_attr_key_hours' : 'tm_tomato_spent_attr_key_minutes';
                const value = String(localStorage.getItem(storageKey) || '').replace(/^"|"$/g, '').trim();
                return value || fallback;
            } catch (e2) {
                return fallback;
            }
        }
    }

    function formatFocusSummaryDisplay(props = {}) {
        const source = (props && typeof props === 'object') ? props : {};
        const actual = normalizeTomatoCountValue(source['custom-tomato-count'] || source.tomatoCount || source.tomato_count || '');
        const estimate = normalizeTomatoCountValue(source['custom-tomato-estimate-count'] || source.tomatoEstimateCount || source.tomato_estimate_count || '');
        const duration = formatQuickbarDurationDisplay(source['custom-duration'] || source.duration || '');
        const spent = String(source['custom-focus-spent-display'] || source.spent || '').trim();
        const actualForPlan = actual || '0';
        const durationProgress = duration ? `${spent || '0'}/${duration}` : '';
        const tomatoPlanText = estimate ? `🍅 ${actualForPlan}/${estimate}` : '';
        if (duration) {
            return `${tomatoPlanText ? `${tomatoPlanText} ` : ''}${durationProgress}`.trim();
        }
        if (estimate) return `${tomatoPlanText}${spent ? ` ${spent}` : ''}`.trim();
        return spent || '';
    }

    function renderQuickbarFocusActualHtml(value) {
        const text = String(value ?? '').trim();
        return text ? `<span class="sy-custom-props-focus-actual">${esc(text)}</span>` : '';
    }

    function formatFocusSummaryDisplayHtml(props = {}) {
        const source = (props && typeof props === 'object') ? props : {};
        const actual = normalizeTomatoCountValue(source['custom-tomato-count'] || source.tomatoCount || source.tomato_count || '');
        const estimate = normalizeTomatoCountValue(source['custom-tomato-estimate-count'] || source.tomatoEstimateCount || source.tomato_estimate_count || '');
        const duration = formatQuickbarDurationDisplay(source['custom-duration'] || source.duration || '');
        const spent = String(source['custom-focus-spent-display'] || source.spent || '').trim();
        const actualForPlan = actual || '0';
        const durationProgress = duration ? `${esc(spent || '0')}/${esc(duration)}` : '';
        const tomatoPlanHtml = estimate ? `🍅 ${renderQuickbarFocusActualHtml(actualForPlan)}/${esc(estimate)}` : '';
        if (duration) {
            return `${tomatoPlanHtml ? `${tomatoPlanHtml} ` : ''}${durationProgress}`.trim();
        }
        if (estimate) return `${tomatoPlanHtml}${spent ? ` ${esc(spent)}` : ''}`.trim();
        if (spent) return esc(spent);
        return '';
    }

    function formatActualTomatoCountDisplayHtml(value) {
        const count = normalizeTomatoCountValue(value);
        return count ? `🍅 ${renderQuickbarFocusActualHtml(count)}` : '';
    }

    function getConfiguredTomatoCountAttrKey(kind) {
        const fallback = kind === 'estimate' ? 'custom-tomato-estimate-count' : 'custom-tomato-count';
        try {
            const storageKey = kind === 'estimate' ? 'tm_tomato_estimate_attr_key' : 'tm_tomato_count_attr_key';
            const parsed = JSON.parse(localStorage.getItem(storageKey) || 'null');
            const value = String(parsed || '').trim();
            return value || fallback;
        } catch (e) {
            try {
                const storageKey = kind === 'estimate' ? 'tm_tomato_estimate_attr_key' : 'tm_tomato_count_attr_key';
                const value = String(localStorage.getItem(storageKey) || '').replace(/^"|"$/g, '').trim();
                return value || fallback;
            } catch (e2) {
                return fallback;
            }
        }
    }

    function readQuickbarJsonStorage(storageKey, fallback) {
        try {
            const raw = localStorage.getItem(storageKey);
            if (raw == null || raw === '') return fallback;
            return JSON.parse(raw);
        } catch (e) {
            return fallback;
        }
    }

    function invalidateQuickbarTaskMetaAttrSettingsCache() {
        quickbarTaskMetaAttrKeySettingsCache = null;
        quickbarTaskMetaAttrAliasSettingsCache = null;
    }

    function getQuickbarTaskMetaAttrKeySettings() {
        if (quickbarTaskMetaAttrKeySettingsCache && typeof quickbarTaskMetaAttrKeySettingsCache === 'object') {
            return quickbarTaskMetaAttrKeySettingsCache;
        }
        const parsed = readQuickbarJsonStorage('tm_task_meta_attr_keys', {}) || {};
        quickbarTaskMetaAttrKeySettingsCache = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
        return quickbarTaskMetaAttrKeySettingsCache;
    }

    function getQuickbarTaskMetaAttrAliasSettings() {
        if (quickbarTaskMetaAttrAliasSettingsCache && typeof quickbarTaskMetaAttrAliasSettingsCache === 'object') {
            return quickbarTaskMetaAttrAliasSettingsCache;
        }
        const parsed = readQuickbarJsonStorage('tm_task_meta_attr_key_aliases', {}) || {};
        quickbarTaskMetaAttrAliasSettingsCache = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
        return quickbarTaskMetaAttrAliasSettingsCache;
    }

    function normalizeTaskMetaAttrKeyName(value, fallback = '') {
        const key = String(value || '').trim();
        if (key && /^custom-[a-zA-Z0-9_-]+$/.test(key)) return key;
        const safeFallback = String(fallback || '').trim();
        return safeFallback && /^custom-[a-zA-Z0-9_-]+$/.test(safeFallback) ? safeFallback : '';
    }

    function getQuickbarTaskMetaAttrFieldDef(field) {
        const key = String(field || '').trim();
        return taskMetaAttrFieldDefs.find(item => item.field === key) || null;
    }

    function getQuickbarTaskMetaAttrKey(field) {
        const def = getQuickbarTaskMetaAttrFieldDef(field);
        if (!def) return '';
        const settings = getQuickbarTaskMetaAttrKeySettings();
        return normalizeTaskMetaAttrKeyName(settings?.[def.field], def.defaultKey) || def.defaultKey;
    }

    function getQuickbarTaskMetaAttrAliases(field) {
        const def = getQuickbarTaskMetaAttrFieldDef(field);
        if (!def) return [];
        const aliases = getQuickbarTaskMetaAttrAliasSettings();
        const rawList = Array.isArray(aliases?.[def.field]) ? aliases[def.field] : [];
        const seen = new Set();
        return rawList
            .map(key => normalizeTaskMetaAttrKeyName(key, ''))
            .filter((key) => {
                if (!key || seen.has(key)) return false;
                seen.add(key);
                return true;
            });
    }

    function getQuickbarTaskMetaAttrReadKeys(field) {
        const def = getQuickbarTaskMetaAttrFieldDef(field);
        if (!def) return [];
        const keys = [
            getQuickbarTaskMetaAttrKey(def.field),
            ...getQuickbarTaskMetaAttrAliases(def.field),
            def.defaultKey,
            def.stableKey,
        ];
        const seen = new Set();
        return keys
            .map((key) => {
                const raw = String(key || '').trim();
                if (raw === 'taskCompleteAt') return raw;
                return normalizeTaskMetaAttrKeyName(raw, '');
            })
            .filter((key) => {
                if (!key || seen.has(key)) return false;
                seen.add(key);
                return true;
            });
    }

    function resolveQuickbarTaskMetaFieldByAttrKey(attrKey) {
        const key = String(attrKey || '').trim();
        if (!key) return '';
        for (const def of taskMetaAttrFieldDefs) {
            if (getQuickbarTaskMetaAttrKey(def.field) === key) return def.field;
        }
        for (const def of taskMetaAttrFieldDefs) {
            if (getQuickbarTaskMetaAttrReadKeys(def.field).includes(key)) return def.field;
        }
        return taskMetaAttrFieldByStableKey.get(key) || taskMetaAttrFieldByDefaultKey.get(key) || '';
    }

    function getQuickbarTaskMetaStableKey(field) {
        return String(getQuickbarTaskMetaAttrFieldDef(field)?.stableKey || '').trim();
    }

    function readQuickbarTaskMetaAttrValue(attrs, field, fallback = '') {
        const data = attrs && typeof attrs === 'object' ? attrs : {};
        for (const key of getQuickbarTaskMetaAttrReadKeys(field)) {
            if (Object.prototype.hasOwnProperty.call(data, key)) return String(data[key] ?? '');
        }
        const stableKey = getQuickbarTaskMetaStableKey(field);
        if (stableKey && Object.prototype.hasOwnProperty.call(data, stableKey)) return String(data[stableKey] ?? '');
        return String(fallback ?? '');
    }

    function mirrorQuickbarTaskMetaStableProps(props) {
        const target = props && typeof props === 'object' ? props : {};
        taskMetaAttrFieldDefs.forEach((def) => {
            const stableKey = String(def.stableKey || '').trim();
            if (!stableKey || !Object.prototype.hasOwnProperty.call(target, stableKey)) return;
            const storageKey = getQuickbarTaskMetaAttrKey(def.field);
            if (storageKey && storageKey !== stableKey) target[storageKey] = target[stableKey];
        });
        return target;
    }

    function normalizeTaskHorizonAttrKeyForSave(attrKey) {
        const key = String(attrKey || '').trim();
        if (key === 'custom-tomato-estimate-count') return getConfiguredTomatoCountAttrKey('estimate');
        if (key === 'custom-tomato-count') return getConfiguredTomatoCountAttrKey('actual');
        const field = resolveQuickbarTaskMetaFieldByAttrKey(key);
        if (field) return getQuickbarTaskMetaAttrKey(field) || key;
        return key;
    }

    function normalizeTaskHorizonAttrKeyForDisplay(attrKey) {
        const key = String(attrKey || '').trim();
        if (!key) return '';
        if (key === getConfiguredTomatoCountAttrKey('estimate')) return 'custom-tomato-estimate-count';
        if (key === getConfiguredTomatoCountAttrKey('actual')) return 'custom-tomato-count';
        const field = resolveQuickbarTaskMetaFieldByAttrKey(key);
        const stableKey = field ? getQuickbarTaskMetaStableKey(field) : '';
        if (stableKey) return stableKey;
        return key;
    }

    function isQuickbarTomatoSpentAttrKey(attrKey) {
        const key = String(attrKey || '').trim();
        if (!key) return false;
        return key === getConfiguredTomatoSpentAttrKey('minutes')
            || key === getConfiguredTomatoSpentAttrKey('hours')
            || key === 'custom-tomato-minutes'
            || key === 'custom-tomato-time';
    }

    function getQuickbarFocusSpentSourceAttrs(attrs = {}) {
        const data = attrs && typeof attrs === 'object' ? attrs : {};
        const minutesKey = getConfiguredTomatoSpentAttrKey('minutes');
        const hoursKey = getConfiguredTomatoSpentAttrKey('hours');
        return {
            [minutesKey]: data[minutesKey] || data['custom-tomato-minutes'] || data.tomatoMinutes || data.tomato_minutes || '',
            [hoursKey]: data[hoursKey] || data['custom-tomato-time'] || data.tomatoHours || data.tomato_hours || '',
            'custom-tomato-minutes': data['custom-tomato-minutes'] || data[minutesKey] || data.tomatoMinutes || data.tomato_minutes || '',
            'custom-tomato-time': data['custom-tomato-time'] || data[hoursKey] || data.tomatoHours || data.tomato_hours || '',
            tomatoMinutes: data.tomatoMinutes || data.tomato_minutes || data[minutesKey] || data['custom-tomato-minutes'] || '',
            tomatoHours: data.tomatoHours || data.tomato_hours || data[hoursKey] || data['custom-tomato-time'] || '',
        };
    }

    function hasQuickbarFocusSpentSourceAttr(attrs = {}) {
        const data = attrs && typeof attrs === 'object' ? attrs : {};
        const keys = [
            getConfiguredTomatoSpentAttrKey('minutes'),
            getConfiguredTomatoSpentAttrKey('hours'),
            'custom-tomato-minutes',
            'custom-tomato-time',
            'tomatoMinutes',
            'tomato_minutes',
            'tomatoHours',
            'tomato_hours',
        ].filter(Boolean);
        return keys.some((key) => Object.prototype.hasOwnProperty.call(data, key));
    }

    function normalizeDurationPresetValue(value) {
        const source = (value && typeof value === 'object' && !Array.isArray(value))
            ? (value.value ?? value.name ?? value.label)
            : value;
        const raw = String(source ?? '').trim();
        if (!raw) return '';
        const matched = raw.match(/-?\d+(?:\.\d+)?/);
        return matched ? String(matched[0] || '').trim() : '';
    }

    function getQuickbarDurationPresetOptions() {
        try {
            const rawItems = JSON.parse(localStorage.getItem('tm_custom_duration_options') || 'null');
            const items = Array.isArray(rawItems) ? rawItems : [];
            const seen = new Set();
            return items
                .map(normalizeDurationPresetValue)
                .filter((value) => {
                    const key = String(value || '').trim().toLowerCase();
                    if (!key || seen.has(key)) return false;
                    seen.add(key);
                    return true;
                });
        } catch (e) {
            return [];
        }
    }

    function clearInlineMetaBootstrapTimers() {
        if (!Array.isArray(inlineMetaBootstrapTimers) || !inlineMetaBootstrapTimers.length) return;
        inlineMetaBootstrapTimers.forEach((timer) => {
            try { clearTimeout(timer); } catch (e) {}
        });
        inlineMetaBootstrapTimers = [];
    }

    function clearInlineMetaWakeTimer(resetFlags = true) {
        if (inlineMetaWakeTimer) {
            try { clearTimeout(inlineMetaWakeTimer); } catch (e) {}
        }
        inlineMetaWakeTimer = null;
        if (!resetFlags) return;
        inlineMetaWakeForceRefresh = false;
        inlineMetaWakeBootstrap = false;
        inlineMetaWakeClearLayout = false;
    }

    function clearInlineMetaRenderQueue() {
        if (inlineMetaRenderQueueTimer) {
            try {
                if (inlineMetaRenderQueueIsRaf && typeof cancelAnimationFrame === 'function') {
                    cancelAnimationFrame(inlineMetaRenderQueueTimer);
                } else {
                    clearTimeout(inlineMetaRenderQueueTimer);
                }
            } catch (e) {}
        }
        inlineMetaRenderQueueTimer = 0;
        inlineMetaRenderQueueIsRaf = false;
        inlineMetaRenderQueue = [];
        inlineMetaRenderQueueIds.clear();
        inlineMetaRenderActiveIds.clear();
        inlineMetaPrefetchQueue = [];
        inlineMetaPrefetchQueuedIds.clear();
    }

    function bumpInlineMetaLayoutRevision(options = {}) {
        inlineMetaLayoutRevision = (Number(inlineMetaLayoutRevision || 0) + 1) % 1000000;
        if (options?.resetCursor === true) inlineMetaRenderCursor = 0;
    }

    function scheduleInlineMetaResizeLayoutRefresh() {
        if (!inlineMetaStarted || !isInlineMetaEnabled()) return;
        bumpInlineMetaLayoutRevision();
        if (inlineMetaResizeTimer) return;
        const now = Date.now();
        const delay = Math.max(0, 80 - (now - Number(inlineMetaResizeLastRenderAt || 0)));
        inlineMetaResizeTimer = setTimeout(() => {
            inlineMetaResizeTimer = 0;
            inlineMetaResizeLastRenderAt = Date.now();
            try { requestInlineMetaRender(false); } catch (e) {}
        }, delay);
    }

    function scheduleInlineMetaWake(forceRefresh = true, options = {}) {
        const delayMs = Math.max(0, Number(options.delayMs) || 0);
        inlineMetaWakeForceRefresh = inlineMetaWakeForceRefresh || !!forceRefresh;
        inlineMetaWakeBootstrap = inlineMetaWakeBootstrap || options.includeBootstrap !== false;
        inlineMetaWakeClearLayout = inlineMetaWakeClearLayout || options.clearLayout !== false;
        if (inlineMetaWakeTimer) {
            try { clearTimeout(inlineMetaWakeTimer); } catch (e) {}
        }
        inlineMetaWakeTimer = setTimeout(() => {
            const nextForceRefresh = !!inlineMetaWakeForceRefresh;
            const nextBootstrap = !!inlineMetaWakeBootstrap;
            const nextClearLayout = !!inlineMetaWakeClearLayout;
            clearInlineMetaWakeTimer();
            if (!inlineMetaStarted || !isInlineMetaEnabled()) return;
            if (nextClearLayout) inlineMetaLayoutCache.clear();
            inlineMetaNeedSyncBlocks = true;
            try { requestInlineMetaRender(nextForceRefresh); } catch (e) {}
            if (nextBootstrap) {
                try { scheduleInlineMetaBootstrapRenders(nextForceRefresh); } catch (e) {}
            }
        }, delayMs);
    }

    function queryInlineMetaHostsInObservedRoots(selector) {
        const query = String(selector || '').trim();
        if (!query) return [];
        const roots = inlineMetaObservedRoots.length ? inlineMetaObservedRoots : getInlineMetaObserveRoots();
        const scopedRoots = roots.filter((root) => root instanceof Element && root.isConnected);
        const seen = new WeakSet();
        const hosts = [];
        const addHost = (host) => {
            if (!(host instanceof Element) || seen.has(host)) return;
            seen.add(host);
            hosts.push(host);
        };
        try {
            if (scopedRoots.length) {
                scopedRoots.forEach((root) => root.querySelectorAll?.(query).forEach(addHost));
                return hosts;
            }
            document.querySelectorAll(query).forEach(addHost);
        } catch (e) {}
        return hosts;
    }

    function hasInlineMetaReadyHosts() {
        try {
            return queryInlineMetaHostsInObservedRoots('.sy-custom-props-inline-host.is-ready').length > 0;
        } catch (e) {
            return false;
        }
    }

    function hasInlineMetaPendingHosts() {
        // A host exists in the DOM but lacks the `is-ready` class when its
        // last `layoutInlineMetaHost` call returned false (transient 0×0
        // rect, missing text anchor, viewport-collision, etc). The bootstrap
        // retry plan needs to keep firing while any such host is pending,
        // otherwise blocks that failed once get stranded as soon as a single
        // peer block has rendered successfully (hasInlineMetaReadyHosts
        // alone returns true and short-circuits the retry).
        try {
            return queryInlineMetaHostsInObservedRoots('.sy-custom-props-inline-host:not(.is-ready)').length > 0;
        } catch (e) {
            return false;
        }
    }

    function scheduleInlineMetaBootstrapRenders(forceRefresh = false) {
        clearInlineMetaBootstrapTimers();
        // Plan extended past 760 ms so embed blocks (which SiYuan renders
        // asynchronously after `loaded-protyle-static` fires) still get
        // chips even if their first paint lands past the original window.
        const plan = [0, 48, 160, 360, 760, 1400, 2400];
        plan.forEach((delay, index) => {
            if (delay === 0) {
                try { scheduleInlineMetaRender(!!forceRefresh, true); } catch (e) {}
                return;
            }
            const timer = setTimeout(() => {
                inlineMetaBootstrapTimers = inlineMetaBootstrapTimers.filter((item) => item !== timer);
                if (!inlineMetaStarted || !isInlineMetaEnabled()) return;
                const needRetry = inlineMetaObservedRoots.length === 0
                    || inlineMetaObservedTaskBlocks.size === 0
                    || !hasInlineMetaReadyHosts()
                    || hasInlineMetaPendingHosts();
                if (!forceRefresh && !needRetry) return;
                try { requestInlineMetaRender(forceRefresh || index >= plan.length - 2); } catch (e) {}
            }, delay);
            inlineMetaBootstrapTimers.push(timer);
        });
    }

    function getStatusOptionsSnapshot() {
        try {
            const savedOptions = localStorage.getItem('tm_custom_status_options');
            if (savedOptions) {
                const options = JSON.parse(savedOptions);
                if (Array.isArray(options) && options.length > 0) {
                    taskStatusOptions = options;
                }
            }
        } catch (e) {}
        return Array.isArray(taskStatusOptions) && taskStatusOptions.length
            ? taskStatusOptions
            : [
                { id: 'todo', name: '待办', color: '#757575' },
                { id: 'done', name: '已完成', color: '#4CAF50' },
                { id: 'cancelled', name: '已取消', color: '#9E9E9E' },
                { id: 'blocked', name: '阻塞', color: '#F44336' },
                { id: 'review', name: '待审核', color: '#FF9800' }
            ];
    }

    function getDefaultUndoneStatusId(statusOptionsInput = null) {
        const statusOptions = Array.isArray(statusOptionsInput) && statusOptionsInput.length
            ? statusOptionsInput
            : getStatusOptionsSnapshot();
        let configured = '';
        try {
            configured = String(localStorage.getItem('tm_checkbox_undone_status_id') || '').trim();
        } catch (e) {}
        if (configured && configured !== '__none__' && statusOptions.some((item) => String(item?.id || '').trim() === configured)) {
            return configured;
        }
        const todoExists = statusOptions.some((item) => String(item?.id || '').trim() === 'todo');
        if (todoExists) return 'todo';
        return String(statusOptions[0]?.id || '').trim() || 'todo';
    }

    function getDefaultDoneStatusId(statusOptionsInput = null) {
        const statusOptions = Array.isArray(statusOptionsInput) && statusOptionsInput.length
            ? statusOptionsInput
            : getStatusOptionsSnapshot();
        let configured = '';
        try {
            configured = String(localStorage.getItem('tm_checkbox_done_status_id') || '').trim();
        } catch (e) {}
        if (configured && configured !== '__none__' && statusOptions.some((item) => String(item?.id || '').trim() === configured)) {
            return configured;
        }
        const doneOption = statusOptions.find((item) => String(item?.id || '').trim() === 'done')
            || statusOptions.find((item) => {
                const marker = normalizeQuickbarStatusMarker(item?.marker, '');
                if (marker) return marker !== ' ';
                const source = `${String(item?.id || '').trim()} ${String(item?.name || '').trim()}`.toLowerCase();
                return source.includes('done') || source.includes('finish') || source.includes('完成');
            });
        return String(doneOption?.id || '').trim() || 'done';
    }

    function normalizeQuickbarStatusMarker(value, fallback = ' ') {
        const raw = value == null ? '' : String(value);
        const first = Array.from(raw === '__space__' ? ' ' : raw)[0] || '';
        if (first && first !== '[' && first !== ']') return first;
        if (fallback === '') return '';
        return fallback == null ? ' ' : String(fallback || ' ').slice(0, 1) || ' ';
    }

    function isQuickbarDoneStatusValue(value, statusOptionsInput = null) {
        const statusId = String(value || '').trim();
        if (!statusId) return false;
        const statusOptions = Array.isArray(statusOptionsInput) && statusOptionsInput.length
            ? statusOptionsInput
            : getStatusOptionsSnapshot();
        let configuredDone = '';
        try {
            configuredDone = String(localStorage.getItem('tm_checkbox_done_status_id') || '').trim();
        } catch (e) {}
        if (configuredDone && configuredDone !== '__none__' && statusId === configuredDone) return true;
        const matched = statusOptions.find((item) => String(item?.id || '').trim() === statusId) || null;
        if (matched) {
            const marker = normalizeQuickbarStatusMarker(matched.marker, '');
            if (marker) return marker !== ' ';
            const source = `${String(matched.id || '').trim()} ${String(matched.name || '').trim()}`.toLowerCase();
            return source.includes('done') || source.includes('finish') || source.includes('完成');
        }
        return statusId === 'done';
    }

    function isQuickbarPropsDone(props) {
        const data = props && typeof props === 'object' ? props : {};
        if (data.done === true || data.done === 'true' || data.done === '1' || data.done === 1) return true;
        return isQuickbarDoneStatusValue(readQuickbarTaskMetaAttrValue(data, 'customStatus', '') || data.customStatus || data.custom_status);
    }

    function shouldShowQuickbarTaskCompleteAt(props) {
        const data = props && typeof props === 'object' ? props : {};
        const completeAt = String(data.taskCompleteAt || data.task_complete_at || readQuickbarTaskMetaAttrValue(data, 'taskCompleteAt', '') || '').trim();
        return isQuickbarPropsDone(data) && !!completeAt;
    }

    async function getManagedTaskStatusSnapshot(taskIdOrBlockId) {
        const rawId = String(taskIdOrBlockId || '').trim();
        if (!rawId) return null;
        const getter = globalThis?.['siyuan-plugin-task-horizon']?.getTaskStatusDisplayByAnyId;
        if (typeof getter !== 'function') return null;
        try {
            const result = await getter(rawId);
            return result && typeof result === 'object' ? result : null;
        } catch (e) {
            return null;
        }
    }

    function isInlineMetaScopeStorageKey(key) {
        return key === 'tm_doc_groups'
            || key === 'tm_selected_doc_ids'
            || key === 'tm_new_task_doc_id';
    }

    function clearInlineMetaScopeDocCache() {
        inlineMetaScopeDocIds = null;
        inlineMetaScopeDocIdsTs = 0;
        inlineMetaScopeDocIdsPromise = null;
    }

    function getDocIdFromProtyleEl(protyleEl) {
        if (!protyleEl) return '';
        try {
            const direct = [
                protyleEl.querySelector?.('.protyle-title')?.getAttribute?.('data-node-id'),
                protyleEl.querySelector?.('.protyle-title__input')?.getAttribute?.('data-node-id'),
                protyleEl.querySelector?.('.protyle-background')?.getAttribute?.('data-node-id'),
                protyleEl.dataset?.nodeId,
                protyleEl.dataset?.id
            ];
            return direct.map((v) => String(v || '').trim()).find(Boolean) || '';
        } catch (e) {
            return '';
        }
    }

    function resolveDocIdFromTaskBlock(blockEl) {
        if (!blockEl) return '';
        const protyle = blockEl.closest?.('.protyle');
        const fromProtyle = getDocIdFromProtyleEl(protyle);
        if (fromProtyle) return fromProtyle;
        try {
            const holders = blockEl.closest?.('[data-doc-id],[data-root-id]');
            const fromHolder = String(holders?.getAttribute?.('data-doc-id') || holders?.getAttribute?.('data-root-id') || '').trim();
            if (fromHolder) return fromHolder;
        } catch (e) {}
        return '';
    }

    async function ensureInlineMetaScopeDocIds(forceRefresh = false) {
        const ttlMs = 5000;
        const now = Date.now();
        if (!forceRefresh && inlineMetaScopeDocIds && (now - inlineMetaScopeDocIdsTs) < ttlMs) return inlineMetaScopeDocIds;
        if (!forceRefresh && inlineMetaScopeDocIdsPromise) return inlineMetaScopeDocIdsPromise;
        const bridge = globalThis?.['siyuan-plugin-task-horizon']?.aiBridge;
        if (typeof bridge?.getConfiguredDocIds !== 'function') {
            inlineMetaScopeDocIds = null;
            inlineMetaScopeDocIdsTs = now;
            return null;
        }
        const p = Promise.resolve(bridge.getConfiguredDocIds({ forceRefresh: !!forceRefresh }))
            .then((docIds) => {
                const next = new Set((Array.isArray(docIds) ? docIds : []).map((id) => String(id || '').trim()).filter(Boolean));
                inlineMetaScopeDocIds = next;
                inlineMetaScopeDocIdsTs = Date.now();
                return next;
            })
            .catch(() => {
                inlineMetaScopeDocIds = null;
                inlineMetaScopeDocIdsTs = Date.now();
                return null;
            })
            .finally(() => {
                if (inlineMetaScopeDocIdsPromise === p) inlineMetaScopeDocIdsPromise = null;
            });
        inlineMetaScopeDocIdsPromise = p;
        return p;
    }

    async function isInlineMetaScopeAllowedForBlock(blockEl) {
        const docId = resolveDocIdFromTaskBlock(blockEl);
        if (!docId) return true;
        const scopeDocIds = await ensureInlineMetaScopeDocIds(false);
        if (!(scopeDocIds instanceof Set)) return true;
        if (!scopeDocIds.size) return false;
        return scopeDocIds.has(docId);
    }

    function isInlineMetaScopeAllowedForBlockCached(blockEl) {
        const docId = resolveDocIdFromTaskBlock(blockEl);
        if (!docId) return true;
        const scopeDocIds = inlineMetaScopeDocIds;
        if (!(scopeDocIds instanceof Set)) {
            try { ensureInlineMetaScopeDocIds(false); } catch (e) {}
            return true;
        }
        if (!scopeDocIds.size) return false;
        return scopeDocIds.has(docId);
    }

    function hasInlineMetaInBlockHost(node) {
        return !!node?.querySelector?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]');
    }

    function touchInlineMetaHost(host, now = Date.now()) {
        if (!(host instanceof HTMLElement)) return;
        try { host.dataset.inlineTouchedAt = String(Math.max(0, Number(now) || Date.now())); } catch (e) {}
    }

    function cleanupInlineMetaHostParent(host, parent = null, layoutParent = null) {
        const directParent = parent || host?.parentElement || null;
        const layoutHostParent = layoutParent || host?.__tmQuickbarInlineLayoutParent || directParent?.closest?.('.sy-custom-props-inline-parent') || null;
        try {
            if (directParent?.classList?.contains('sy-custom-props-inline-parent')
                && !hasInlineMetaInBlockHost(directParent)) {
                directParent.classList.remove('sy-custom-props-inline-parent');
            }
        } catch (e) {}
        try {
            if (layoutHostParent?.classList?.contains('sy-custom-props-inline-parent')
                && !hasInlineMetaInBlockHost(layoutHostParent)) {
                layoutHostParent.classList.remove('sy-custom-props-inline-parent');
            }
        } catch (e) {}
    }

    function removeInlineMetaHostNode(host, clearLayout = true) {
        if (!(host instanceof Element)) return false;
        const ids = new Set();
        const pushId = (value) => {
            const id = String(value || '').trim();
            if (id) ids.add(id);
        };
        pushId(host?.dataset?.blockId);
        pushId(host?.dataset?.taskId);
        pushId(host?.dataset?.attrHostId);
        const parent = host.parentElement || null;
        const layoutParent = host.__tmQuickbarInlineLayoutParent || parent?.closest?.('.sy-custom-props-inline-parent') || null;
        try { host.remove(); } catch (e) {}
        cleanupInlineMetaHostParent(host, parent, layoutParent);
        ids.forEach((id) => {
            try { inlineMetaMissingHostSeenAt.delete(id); } catch (e) {}
            if (clearLayout) {
                try { inlineMetaLayoutCache.delete(id); } catch (e) {}
            }
        });
        return true;
    }

    function removeInlineMetaHostByTaskId(taskId, placement = '') {
        const id = String(taskId || '').trim();
        const expectedPlacement = String(placement || '').trim();
        if (!id) return;
        const hosts = [];
        const seen = new WeakSet();
        const pushHost = (host) => {
            if (!(host instanceof Element) || seen.has(host)) return;
            seen.add(host);
            hosts.push(host);
        };
        ['blockId', 'taskId', 'attrHostId'].forEach((field) => {
            const attrName = field === 'blockId'
                ? 'data-block-id'
                : (field === 'taskId' ? 'data-task-id' : 'data-attr-host-id');
            try {
                document.querySelectorAll(`.sy-custom-props-inline-host[${attrName}="${CSS.escape(id)}"]`).forEach(pushHost);
            } catch (e) {
                document.querySelectorAll(`.sy-custom-props-inline-host[${attrName}]`).forEach((host) => {
                    if (String(host?.dataset?.[field] || '').trim() === id) pushHost(host);
                });
            }
        });
        if (expectedPlacement) {
            hosts
                .filter((host) => String(host?.dataset?.inlinePlacement || '').trim() === expectedPlacement)
                .forEach((host) => removeInlineMetaHostNode(host, true));
        } else {
            hosts.forEach((host) => removeInlineMetaHostNode(host, true));
        }
        try { inlineMetaMissingHostSeenAt.delete(id); } catch (e) {}
        try { inlineMetaLayoutCache.delete(id); } catch (e) {}
        invalidateInlineMetaActiveTargetsCache();
    }

    function shouldRunInlineMetaSourceHostDedupe(sourceTaskId, keepAttrHostId, ttlMs = QUICKBAR_INLINE_SOURCE_DEDUPE_TTL_MS) {
        const sourceId = String(sourceTaskId || '').trim();
        const keepId = String(keepAttrHostId || '').trim();
        if (!sourceId || !keepId) return false;
        const now = Date.now();
        const key = `${sourceId}:${keepId}`;
        const lastSeenAt = Number(inlineMetaSourceHostDedupeSeenAt.get(key) || 0);
        const safeTtl = Math.max(300, Number(ttlMs) || QUICKBAR_INLINE_SOURCE_DEDUPE_TTL_MS);
        if (lastSeenAt && (now - lastSeenAt) < safeTtl) return false;
        inlineMetaSourceHostDedupeSeenAt.set(key, now);
        if (inlineMetaSourceHostDedupeSeenAt.size > 300) {
            inlineMetaSourceHostDedupeSeenAt.forEach((ts, seenKey) => {
                if ((now - Number(ts || 0)) > safeTtl * 4) inlineMetaSourceHostDedupeSeenAt.delete(seenKey);
            });
        }
        return true;
    }

    function removeInlineMetaHostsBySourceTaskId(sourceTaskId, keepAttrHostId = '', placement = '') {
        const id = String(sourceTaskId || '').trim();
        const keepId = String(keepAttrHostId || '').trim();
        const expectedPlacement = String(placement || '').trim();
        if (!id) return 0;
        const hosts = [];
        const seen = new WeakSet();
        const pushHost = (host) => {
            if (!(host instanceof Element) || seen.has(host)) return;
            seen.add(host);
            hosts.push(host);
        };
        try {
            document.querySelectorAll(`.sy-custom-props-inline-host[data-task-id="${CSS.escape(id)}"]`).forEach(pushHost);
        } catch (e) {
            document.querySelectorAll('.sy-custom-props-inline-host[data-task-id]').forEach((host) => {
                if (String(host?.dataset?.taskId || '').trim() === id) pushHost(host);
            });
        }
        try {
            document.querySelectorAll(`.sy-custom-props-inline-host[data-block-id="${CSS.escape(id)}"]`).forEach(pushHost);
        } catch (e) {
            document.querySelectorAll('.sy-custom-props-inline-host[data-block-id]').forEach((host) => {
                if (String(host?.dataset?.blockId || '').trim() === id) pushHost(host);
            });
        }
        let removed = 0;
        hosts.forEach((host) => {
            if (expectedPlacement && String(host?.dataset?.inlinePlacement || '').trim() !== expectedPlacement) return;
            const hostId = String(host?.dataset?.blockId || '').trim();
            const attrHostId = String(host?.dataset?.attrHostId || '').trim();
            if (keepId && (hostId === keepId || attrHostId === keepId)) return;
            if (removeInlineMetaHostNode(host, true)) removed += 1;
        });
        if (removed > 0) invalidateInlineMetaActiveTargetsCache();
        return removed;
    }

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function getRemarkMarkdownTools() {
        const tools = globalThis.__tmRemarkMarkdownTools;
        return tools && typeof tools === 'object' ? tools : null;
    }

    function normalizeRemarkMarkdown(value) {
        const tools = getRemarkMarkdownTools();
        if (tools && typeof tools.normalize === 'function') {
            try { return String(tools.normalize(value) || ''); } catch (e) {}
        }
        return String(value || '').replace(/\r\n?/g, '\n').trim();
    }

    function stripRemarkMarkdown(value) {
        const tools = getRemarkMarkdownTools();
        if (tools && typeof tools.stripText === 'function') {
            try { return String(tools.stripText(value) || ''); } catch (e) {}
        }
        return String(value || '').replace(/\r\n?/g, ' ').replace(/\s{2,}/g, ' ').trim();
    }

    function isInlineMetaEnabled() {
        const cfg = getQuickbarInlineSettings();
        if (!cfg.enabled) return false;
        if (isInlineMetaMobileSuppressedDevice() && !cfg.showOnMobile) return false;
        return true;
    }

    function quickbarInlineFieldsIncludeCompleteAt(cfg = null) {
        const settings = cfg && Array.isArray(cfg.fields) ? cfg : getQuickbarInlineSettings();
        return Array.isArray(settings?.fields) && settings.fields.includes('taskCompleteAt');
    }

    const QUICKBAR_INLINE_RENDER_BATCH_LIMIT = 10;
    const QUICKBAR_INLINE_PREFETCH_CONCURRENCY = 4;
    const QUICKBAR_INLINE_PREFETCH_QUEUE_LIMIT = 160;
    const QUICKBAR_INLINE_SOURCE_DEDUPE_TTL_MS = 2400;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_INTERVAL_MS = 3200;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_FORCE_INTERVAL_MS = 1800;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_DEEP_INTERVAL_MS = 900;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_VISIT_LIMIT = 600;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_SLOW_LIMIT = 80;
    const QUICKBAR_INLINE_INVALID_HOST_PRUNE_TIME_BUDGET_MS = 10;
    const QUICKBAR_TASK_BINDING_CACHE_TTL_MS = 400;
    const QUICKBAR_INLINE_CACHE_TTL_MS = 8 * 60 * 1000;
    const QUICKBAR_INLINE_CACHE_SOFT_LIMIT = 520;
    const QUICKBAR_INLINE_LAYOUT_CACHE_SOFT_LIMIT = 520;
    const QUICKBAR_INLINE_DOM_HOST_SOFT_LIMIT = 520;
    const QUICKBAR_INLINE_DOM_HOST_HARD_LIMIT = 900;
    const QUICKBAR_INLINE_INACTIVE_HOST_TTL_MS = 45 * 1000;
    const QUICKBAR_INLINE_MISC_CACHE_TTL_MS = 2 * 60 * 1000;
    const QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT = 360;
    const QUICKBAR_INLINE_RUNTIME_PRUNE_INTERVAL_MS = 5000;

    function getListSubtype(el) {
        return String(el?.getAttribute?.('data-subtype') || el?.dataset?.subtype || '').trim().toLowerCase();
    }

    function isExplicitNonTaskListItem(el) {
        if (!(el instanceof Element)) return false;
        const isListItem = el.matches?.('.li,[data-type="NodeListItem"]');
        if (!isListItem) return false;
        const selfSubtype = getListSubtype(el);
        const marker = String(el.getAttribute?.('data-marker') || '').trim();
        const hasTaskMarker = marker.includes('[ ]') || marker.includes('[x]') || marker.includes('[X]');
        const hasTaskState = el.hasAttribute?.('data-task') || selfSubtype === 't' || hasTaskMarker;
        if (selfSubtype === 'u' || selfSubtype === 'o') return true;
        const parentList = el.parentElement instanceof Element
            && el.parentElement.matches?.('.list,[data-type="NodeList"]')
            ? el.parentElement
            : null;
        const parentSubtype = getListSubtype(parentList);
        if ((parentSubtype === 'u' || parentSubtype === 'o') && !hasTaskState) return true;
        return !hasTaskState && (/^[-*+]$/.test(marker) || /^\d+[.)]$/.test(marker));
    }

    function hasTaskMarkerEl(el) {
        if (!el) return false;
        if (isExplicitNonTaskListItem(el)) return false;
        const marker = el.getAttribute?.('data-marker') || '';
        if (marker.includes('[ ]') || marker.includes('[x]') || marker.includes('[X]')) return true;
        if (el.hasAttribute?.('data-task')) return true;
        const subtype = getListSubtype(el);
        if (subtype === 't') return true;
        const parentList = el.parentElement instanceof Element
            && el.parentElement.matches?.('.list,[data-type="NodeList"]')
            ? el.parentElement
            : null;
        if (getListSubtype(parentList) === 't') return true;
        return false;
    }

    function isTaskBlockElement(blockEl) {
        if (!blockEl) return false;
        if (isExplicitNonTaskListItem(blockEl)) return false;
        // 只检查当前块本身和直接子元素，避免父级普通列表项因为包含子任务而被误判成任务块。
        const directChildren = Array.from(blockEl.children || []);
        const hasDirectTaskControl = directChildren.some((child) => {
            if (!(child instanceof Element)) return false;
            return child.matches?.('.protyle-action__task,.protyle-action--task,.protyle-task--checkbox');
        });
        if (hasDirectTaskControl) return true;
        return hasTaskMarkerEl(blockEl);
    }

    function isInlineMetaHiddenDoneTaskBlock(blockEl) {
        if (!(blockEl instanceof Element)) return false;
        const doneEl = blockEl.classList?.contains('protyle-task--done')
            ? blockEl
            : blockEl.closest?.('.protyle-task--done');
        if (!(doneEl instanceof Element)) return false;
        try {
            const style = window.getComputedStyle?.(doneEl);
            if (style && (style.display === 'none' || style.visibility === 'hidden')) return true;
        } catch (e) {}
        try {
            return typeof doneEl.getClientRects === 'function' && doneEl.getClientRects().length === 0;
        } catch (e) {
            return false;
        }
    }

    function getBlockElementFromTarget(target) {
        if (!target || target === document) return null;
        const li = target.closest?.('.li,[data-type="NodeListItem"]');
        if (li?.dataset?.nodeId) return li;
        const block = target.closest?.('[data-node-id]');
        if (block?.dataset?.nodeId) return block;
        return null;
    }

    function getTaskBlockElementFromTarget(target) {
        if (!target || target === document) return null;
        const taskIndicator = target.closest?.('.protyle-action__task,.protyle-action--task,.protyle-task--checkbox,.protyle-task,[data-task]');
        const li = (taskIndicator || target).closest?.('.li,[data-type="NodeListItem"]');
        const block = (li && li.dataset?.nodeId) ? li : (taskIndicator || target).closest?.('[data-node-id]');
        if (!block || !block.dataset?.nodeId) return null;
        if (!isTaskBlockElement(block)) return null;
        return block;
    }

    function shouldRejectInlineTextParent(parent, textRoot = null) {
        if (!(parent instanceof Element)) return false;
        if (parent.closest?.('.sy-custom-props-inline-host,.protyle-attr,.protyle-custom')) return true;
        const falseHost = parent.closest?.('[contenteditable="false"]');
        if (!falseHost) return false;
        if (textRoot instanceof Element && falseHost.contains(textRoot) && !textRoot.contains(falseHost)) {
            return false;
        }
        return true;
    }

        function getTaskTitleFromBlockEl(blockEl) {
            if (!blockEl) return '';
            try {
                const paragraph = blockEl.querySelector?.(':scope > .p') || blockEl.querySelector?.('.p') || null;
                const textAnchor = paragraph?.querySelector?.(':scope > [contenteditable="true"]')
                    || paragraph?.querySelector?.('[contenteditable="true"]')
                    || paragraph
                    || blockEl;
                const parts = [];
                const walker = document.createTreeWalker(textAnchor, NodeFilter.SHOW_TEXT, {
                    acceptNode(node) {
                        const parent = node?.parentElement;
                        if (shouldRejectInlineTextParent(parent, textAnchor)) return NodeFilter.FILTER_REJECT;
                        const text = String(node?.nodeValue || '').replace(/\u200b/g, '').trim();
                        return text ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                    }
                });
                while (walker.nextNode()) {
                    const text = String(walker.currentNode?.nodeValue || '').replace(/\u200b/g, ' ').trim();
                    if (text) parts.push(text);
                }
                const text = parts.length ? parts.join(' ') : String(textAnchor?.textContent || blockEl.textContent || '');
                return String(text || '').replace(/\s+/g, ' ').trim();
            } catch (e) {
                return String(blockEl?.textContent || '').replace(/\s+/g, ' ').trim();
            }
        }

        function isQuickbarTaskListElement(listEl) {
            if (!(listEl instanceof Element)) return false;
            if (!listEl.matches?.('.list,[data-type="NodeList"]')) return false;
            const subtype = String(listEl.getAttribute?.('data-subtype') || listEl.dataset?.subtype || '').trim().toLowerCase();
            return subtype === 't';
        }

        function readQuickbarElementNodeId(el) {
            return String(el?.dataset?.nodeId || el?.getAttribute?.('data-node-id') || '').trim();
        }

        function getQuickbarListItemsCacheSig(listEl) {
            if (!(listEl instanceof Element)) return '';
            const children = listEl.children || [];
            const first = children.length ? children[0] : null;
            const last = children.length ? children[children.length - 1] : null;
            return [
                readQuickbarElementNodeId(listEl),
                children.length,
                readQuickbarElementNodeId(first),
                readQuickbarElementNodeId(last),
                String(listEl.getAttribute?.('data-subtype') || listEl.dataset?.subtype || '').trim().toLowerCase()
            ].join('|');
        }

        function getQuickbarDirectTaskListItems(listEl) {
            if (!isQuickbarTaskListElement(listEl)) return [];
            const now = Date.now();
            const sig = getQuickbarListItemsCacheSig(listEl);
            const cached = quickbarDirectTaskListItemsCache.get(listEl);
            if (cached && (now - Number(cached.ts || 0)) < QUICKBAR_TASK_BINDING_CACHE_TTL_MS && cached.sig === sig) {
                return Array.isArray(cached.items) ? cached.items.slice() : [];
            }
            const items = Array.from(listEl.children || []).filter((child) => {
                if (!(child instanceof Element)) return false;
                if (!child.matches?.('.li,[data-type="NodeListItem"]')) return false;
                if (!readQuickbarElementNodeId(child)) return false;
                return isTaskBlockElement(child);
            });
            quickbarDirectTaskListItemsCache.set(listEl, { ts: now, sig, items });
            return items.slice();
        }

        function getQuickbarSiblingTaskListElement(listEl, direction = 'next') {
            if (!(listEl instanceof Element)) return null;
            let sibling = direction === 'prev' ? listEl.previousElementSibling : listEl.nextElementSibling;
            while (sibling instanceof Element && !String(sibling?.dataset?.nodeId || sibling?.getAttribute?.('data-node-id') || '').trim()) {
                sibling = direction === 'prev' ? sibling.previousElementSibling : sibling.nextElementSibling;
            }
            if (!isQuickbarTaskListElement(sibling)) return null;
            return getQuickbarDirectTaskListItems(sibling).length ? sibling : null;
        }

        function hasQuickbarAdjacentTaskList(listEl) {
            return !!(getQuickbarSiblingTaskListElement(listEl, 'prev') || getQuickbarSiblingTaskListElement(listEl, 'next'));
        }

        function cloneQuickbarTaskBinding(binding) {
            return {
                taskId: String(binding?.taskId || '').trim(),
                attrHostId: String(binding?.attrHostId || binding?.taskId || '').trim(),
                parentListId: String(binding?.parentListId || '').trim(),
                attrHostState: String(binding?.attrHostState || '').trim(),
                attrHostMigrationSourceId: String(binding?.attrHostMigrationSourceId || '').trim(),
                parentListTaskCount: Number(binding?.parentListTaskCount || 0),
                parentListHasAdjacentTaskList: !!binding?.parentListHasAdjacentTaskList,
            };
        }

        function getQuickbarTaskBindingCacheSig(blockEl) {
            if (!(blockEl instanceof Element)) return '';
            const li = blockEl.matches?.('.li,[data-type="NodeListItem"]')
                ? blockEl
                : blockEl.closest?.('.li,[data-type="NodeListItem"]');
            const list = blockEl.matches?.('.list,[data-type="NodeList"]')
                ? blockEl
                : (li?.parentElement instanceof Element && li.parentElement.matches?.('.list,[data-type="NodeList"]') ? li.parentElement : blockEl.closest?.('.list,[data-type="NodeList"]'));
            return [
                readQuickbarElementNodeId(blockEl),
                readQuickbarElementNodeId(li),
                readQuickbarElementNodeId(list),
                list?.children?.length || 0,
                readQuickbarElementNodeId(list?.previousElementSibling),
                readQuickbarElementNodeId(list?.nextElementSibling),
                String(list?.getAttribute?.('data-subtype') || list?.dataset?.subtype || '').trim().toLowerCase()
            ].join('|');
        }

        function readQuickbarTaskBindingCache(blockEl) {
            if (!(blockEl instanceof Element) || !blockEl.isConnected) return null;
            const cached = quickbarTaskBindingCache.get(blockEl);
            if (!cached) return null;
            if ((Date.now() - Number(cached.ts || 0)) >= QUICKBAR_TASK_BINDING_CACHE_TTL_MS) return null;
            const sig = getQuickbarTaskBindingCacheSig(blockEl);
            if (cached.sig !== sig) return null;
            return cloneQuickbarTaskBinding(cached.binding);
        }

        function writeQuickbarTaskBindingCache(blockEl, binding) {
            const normalized = cloneQuickbarTaskBinding(binding);
            if (blockEl instanceof Element && blockEl.isConnected) {
                quickbarTaskBindingCache.set(blockEl, {
                    ts: Date.now(),
                    sig: getQuickbarTaskBindingCacheSig(blockEl),
                    binding: normalized
                });
            }
            return cloneQuickbarTaskBinding(normalized);
        }

        function clearQuickbarTaskBindingCaches() {
            quickbarDirectTaskListItemsCache = new WeakMap();
            quickbarTaskBindingCache = new WeakMap();
        }

        function resolveTaskBindingFromBlockEl(blockEl) {
            if (!blockEl) return { taskId: '', attrHostId: '' };
            const cachedBinding = readQuickbarTaskBindingCache(blockEl);
            if (cachedBinding) return cachedBinding;
            const readId = (el) => String(el?.dataset?.nodeId || el?.getAttribute?.('data-node-id') || '').trim();
            const resolveTaskBindingFromTaskLi = (taskLi) => {
                if (!taskLi || !(taskLi instanceof Element)) return null;
                const taskId = readId(taskLi);
                if (!taskId) return null;
                const parentList = taskLi.parentElement instanceof Element
                    && taskLi.parentElement.matches?.('.list,[data-type="NodeList"]')
                    ? taskLi.parentElement
                    : null;
                const listId = readId(parentList);
                const listSubtype = String(parentList?.getAttribute?.('data-subtype') || parentList?.dataset?.subtype || '').trim().toLowerCase();
                const directTaskItems = getQuickbarDirectTaskListItems(parentList);
                const isTaskList = !!(listId && listSubtype === 't');
                const isOnlyDirectTask = isTaskList && directTaskItems.length === 1 && directTaskItems[0] === taskLi;
                const hasAdjacentTaskList = isOnlyDirectTask && hasQuickbarAdjacentTaskList(parentList);
                const isFirstDirectTask = isTaskList && directTaskItems.length > 0 && directTaskItems[0] === taskLi;
                const useParentHost = isOnlyDirectTask && !hasAdjacentTaskList;
                const attrHostId = useParentHost ? listId : taskId;
                const attrHostState = useParentHost
                    ? 'state1-parent'
                    : (isFirstDirectTask ? 'state3-list-item' : 'state2-list-item');
                const migrationSourceId = useParentHost
                    ? taskId
                    : (isFirstDirectTask ? listId : '');
                return {
                    taskId,
                    attrHostId,
                    parentListId: listId,
                    attrHostState,
                    attrHostMigrationSourceId: migrationSourceId,
                    parentListTaskCount: directTaskItems.length,
                    parentListHasAdjacentTaskList: !!hasAdjacentTaskList,
                };
            };
            const pickTaskLi = (root) => {
                if (!root || !(root instanceof Element)) return null;
                if (root.matches?.('.list,[data-type="NodeList"]')) {
                    const directTaskItems = getQuickbarDirectTaskListItems(root);
                    return directTaskItems.length >= 1 ? directTaskItems[0] : null;
                }
                const li = root.matches?.('.li,[data-type="NodeListItem"]')
                    ? root
                    : root.closest?.('.li,[data-type="NodeListItem"]');
                if (li && readId(li) && isTaskBlockElement(li)) return li;
                const list = root.matches?.('.list,[data-type="NodeList"]')
                    ? root
                    : root.closest?.('.list,[data-type="NodeList"]');
                const directTaskItems = getQuickbarDirectTaskListItems(list);
                if (directTaskItems.length === 1) return directTaskItems[0];
                const inner = root.querySelector?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                if (inner && readId(inner) && isTaskBlockElement(inner)) return inner;
                return null;
            };
            let result = null;
            const selfTaskLi = pickTaskLi(blockEl);
            if (selfTaskLi) {
                result = resolveTaskBindingFromTaskLi(selfTaskLi) || { taskId: '', attrHostId: '' };
            } else {
                const id0 = readId(blockEl);
                if (id0 && isTaskBlockElement(blockEl)) {
                    result = { taskId: id0, attrHostId: id0 };
                } else {
                    const p = blockEl.closest?.('[data-node-id]');
                    const fallbackId = readId(p) || id0;
                    result = { taskId: fallbackId, attrHostId: fallbackId };
                }
            }
            return writeQuickbarTaskBindingCache(blockEl, result);
        }

        function resolveTaskNodeIdForDetail(blockEl) {
            const binding = resolveTaskBindingFromBlockEl(blockEl);
            return String(binding?.taskId || '').trim();
        }

        function resolveTaskAttrNodeIdForDetail(blockEl) {
            const binding = resolveTaskBindingFromBlockEl(blockEl);
            return String(binding?.attrHostId || binding?.taskId || '').trim();
        }

        function readQuickbarBlockNodeId(el) {
            return String(el?.dataset?.nodeId || el?.getAttribute?.('data-node-id') || '').trim();
        }

        function getQuickbarBlockElementById(blockId) {
            const id = String(blockId || '').trim();
            if (!/^[0-9]+-[a-zA-Z0-9]+$/.test(id)) return null;
            return document.querySelector(`.li[data-node-id='${id}'],[data-type='NodeListItem'][data-node-id='${id}'],[data-node-id='${id}']`);
        }

        function parseQuickbarBlockIdCreatedTs(blockId) {
            const match = String(blockId || '').trim().match(/^(\d{14})/);
            if (!match) return 0;
            const raw = match[1];
            const ts = new Date(
                Number(raw.slice(0, 4)),
                Number(raw.slice(4, 6)) - 1,
                Number(raw.slice(6, 8)),
                Number(raw.slice(8, 10)),
                Number(raw.slice(10, 12)),
                Number(raw.slice(12, 14)),
                0
            ).getTime();
            return Number.isFinite(ts) ? ts : 0;
        }

        function resolveQuickbarTaskLiForInheritance(blockEl, binding = null) {
            const taskId = String(binding?.taskId || '').trim();
            if (taskId) {
                const byTaskId = getQuickbarBlockElementById(taskId);
                const taskLi = byTaskId?.matches?.('.li,[data-type=NodeListItem]')
                    ? byTaskId
                    : byTaskId?.closest?.('.li,[data-type=NodeListItem]');
                if (taskLi && readQuickbarBlockNodeId(taskLi) && isTaskBlockElement(taskLi)) return taskLi;
            }
            const root = blockEl instanceof Element ? blockEl : null;
            if (!root) return null;
            const directTaskItems = (listEl) => {
                if (!(listEl instanceof Element) || !listEl.matches?.('.list,[data-type=NodeList]')) return [];
                return Array.from(listEl.children || []).filter((child) => {
                    if (!(child instanceof Element)) return false;
                    if (!child.matches?.('.li,[data-type=NodeListItem]')) return false;
                    return readQuickbarBlockNodeId(child) && isTaskBlockElement(child);
                });
            };
            if (root.matches?.('.list,[data-type=NodeList]')) {
                const items = directTaskItems(root);
                if (items.length === 1) return items[0];
            }
            const li = root.matches?.('.li,[data-type=NodeListItem]')
                ? root
                : root.closest?.('.li,[data-type=NodeListItem]');
            if (li && readQuickbarBlockNodeId(li) && isTaskBlockElement(li)) return li;
            const list = root.matches?.('.list,[data-type=NodeList]')
                ? root
                : root.closest?.('.list,[data-type=NodeList]');
            const items = directTaskItems(list);
            return items.length === 1 ? items[0] : null;
        }

        function resolveQuickbarParentTaskIdForInheritance(blockEl, binding = null) {
            const childLi = resolveQuickbarTaskLiForInheritance(blockEl, binding);
            if (!(childLi instanceof Element)) return '';
            const parentList = childLi.parentElement instanceof Element
                && childLi.parentElement.matches?.('.list,[data-type=NodeList]')
                ? childLi.parentElement
                : null;
            if (!(parentList instanceof Element)) return '';
            const parentLi = parentList.parentElement instanceof Element
                && parentList.parentElement.matches?.('.li,[data-type=NodeListItem]')
                ? parentList.parentElement
                : parentList.closest?.('.li,[data-type=NodeListItem]');
            if (!(parentLi instanceof Element) || parentLi === childLi) return '';
            if (!readQuickbarBlockNodeId(parentLi) || !isTaskBlockElement(parentLi)) return '';
            let parentBinding = null;
            try { parentBinding = resolveTaskBindingFromBlockEl(parentLi); } catch (e) { parentBinding = null; }
            return String(parentBinding?.taskId || readQuickbarBlockNodeId(parentLi) || '').trim();
        }

        function pruneQuickbarSubtaskInheritNoticeCache(now = Date.now()) {
            if (!(quickbarSubtaskInheritNoticeTs instanceof Map)) {
                quickbarSubtaskInheritNoticeTs = new Map();
                return;
            }
            if (quickbarSubtaskInheritNoticeTs.size <= 400) return;
            quickbarSubtaskInheritNoticeTs.forEach((ts, key) => {
                if ((now - (Number(ts) || 0)) > 60000) quickbarSubtaskInheritNoticeTs.delete(key);
            });
            if (quickbarSubtaskInheritNoticeTs.size > 800) quickbarSubtaskInheritNoticeTs.clear();
        }

        function maybeRequestQuickbarSubtaskFieldInheritance(blockEl, bindingInput = null, reason = '') {
            let sharedApi = null;
            try {
                const api = globalThis?.['siyuan-plugin-task-horizon'];
                sharedApi = api && typeof api === 'object' ? api : null;
            } catch (e) {
                sharedApi = null;
            }
            const bridge = sharedApi?.quickbarBridge || null;
            const inherit = bridge?.maybeInheritSubtaskFields;
            if (typeof inherit !== 'function') {
                return false;
            }
            let binding = bindingInput;
            if (!binding) {
                try { binding = resolveTaskBindingFromBlockEl(blockEl); } catch (e) { binding = null; }
            }
            const taskId = String(binding?.taskId || blockEl?.dataset?.nodeId || '').trim();
            if (!taskId) {
                return false;
            }
            const attrHostId = String(binding?.attrHostId || taskId).trim() || taskId;
            const parentTaskId = resolveQuickbarParentTaskIdForInheritance(blockEl, binding);
            if (!parentTaskId || parentTaskId === taskId) {
                return false;
            }
            const now = Date.now();
            const createdTs = parseQuickbarBlockIdCreatedTs(taskId);
            if (createdTs && (now - createdTs) > 10 * 60 * 1000) {
                return false;
            }
            if (createdTs && (now - createdTs) < QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS) {
                const delayMs = Math.max(0, QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS - (now - createdTs));
                const delayKey = `delay:${taskId}:${attrHostId}:${parentTaskId}`;
                const prevDelayTs = Number(quickbarSubtaskInheritNoticeTs.get(delayKey) || 0);
                if (!prevDelayTs || (now - prevDelayTs) >= QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS) {
                    quickbarSubtaskInheritNoticeTs.set(delayKey, now);
                    setTimeout(() => {
                        try { quickbarSubtaskInheritNoticeTs.delete(delayKey); } catch (e) {}
                        try { maybeRequestQuickbarSubtaskFieldInheritance(blockEl, null, `${String(reason || 'quickbar').trim() || 'quickbar'}:delayed`); } catch (e) {}
                    }, delayMs);
                }
                return false;
            }
            pruneQuickbarSubtaskInheritNoticeCache(now);
            const key = `${taskId}:${attrHostId}:${parentTaskId}`;
            const prevTs = Number(quickbarSubtaskInheritNoticeTs.get(key) || 0);
            if (prevTs && (now - prevTs) < QUICKBAR_SUBTASK_INHERIT_NOTICE_TTL_MS) return false;
            quickbarSubtaskInheritNoticeTs.set(key, now);
            try {
                const result = inherit.call(bridge, {
                    taskId,
                    attrHostId,
                    parentTaskId,
                    source: 'quickbar-subtask-inherit-attrs',
                    reason: String(reason || 'quickbar').trim() || 'quickbar',
                    seenAt: now,
                });
                Promise.resolve(result).then((res) => {
                    if (res && res.retry === true) quickbarSubtaskInheritNoticeTs.delete(key);
                }).catch((err) => {
                    quickbarSubtaskInheritNoticeTs.delete(key);
                });
                return true;
            } catch (e) {
                quickbarSubtaskInheritNoticeTs.delete(key);
                return false;
            }
        }

    function getSelectedBlockElementForMenu() {
        const direct = document.querySelector('.protyle-wysiwyg--select, .protyle-content--select');
        const el = direct ||
            document.querySelector('.protyle--focus .protyle-wysiwyg, .protyle--focus .protyle-content')?.querySelector('.protyle-wysiwyg--select, .protyle-content--select') ||
            document.querySelector('.protyle-wysiwyg, .protyle-content')?.querySelector('.protyle-wysiwyg--select, .protyle-content--select');
        if (!el) return null;
        return el.closest?.('.li,[data-type="NodeListItem"],[data-node-id]') || el;
    }

    function isBlockMarkerTarget(target) {
        if (!target || target === document) return false;
        if (target.closest?.('.protyle-gutters,.protyle-gutter,.protyle-gutter__icon,.protyle-gutter__item,[data-type="gutter"],[data-type="gutterBlock"]')) {
            return true;
        }
        const iconLike = target.closest?.('.protyle-action,.protyle-icon');
        if (!iconLike) return false;
        return !!iconLike.closest?.('.protyle-gutters,.protyle-gutter,.protyle-gutter__icon,.protyle-gutter__item,[data-type="gutter"],[data-type="gutterBlock"]');
    }

    function shouldSuppressFloatBarForTarget(target, now = Date.now()) {
        if (isBlockMarkerTarget(target)) return true;
        const source = String(lastBlockMenuTrigger?.source || '').trim();
        const ts = Number(lastBlockMenuTrigger?.ts || 0);
        if (source !== 'gutter' || !ts) return false;
        return (now - ts) < 240;
    }

    function getSiyuanRuntimeBackend() {
        try {
            const container = String(window?.siyuan?.config?.system?.container || globalThis?.siyuan?.config?.system?.container || '').trim().toLowerCase();
            if (container) return container;
        } catch (e) {}
        return '';
    }

    function hasOfficialMobileRuntimeSignal() {
        try {
            if (globalThis?.JSAndroid) return true;
        } catch (e) {}
        try {
            if (globalThis?.JSHarmony) return true;
        } catch (e) {}
        try {
            const hasIosBridge = !!globalThis?.webkit?.messageHandlers;
            if (!hasIosBridge) return false;
            const ua = String(navigator?.userAgent || '');
            const maxTouchPoints = Number(navigator?.maxTouchPoints) || 0;
            if (/iPhone|iPad|iPod/i.test(ua)) return true;
            if (maxTouchPoints > 0) return true;
            return true;
        } catch (e) {}
        return false;
    }

    function isMobileBrowserViewport() {
        try {
            if (navigator?.userAgentData?.mobile === true) return true;
        } catch (e) {}
        try {
            const ua = String(navigator?.userAgent || '');
            if (/Mobile|Android|iPhone|iPad|iPod|HarmonyOS/i.test(ua)) return true;
        } catch (e) {}
        try {
            const maxTouchPoints = Number(navigator?.maxTouchPoints) || 0;
            const width = Number(window?.innerWidth) || 0;
            const coarse = !!window?.matchMedia?.('(pointer: coarse)')?.matches;
            if ((coarse || maxTouchPoints > 0) && width > 0 && width <= 900) return true;
        } catch (e) {}
        return false;
    }

    function isInlineMetaMobileSuppressedDevice() {
        if (hasOfficialMobileRuntimeSignal()) return true;
        try {
            if (navigator?.userAgentData?.mobile === true) return true;
        } catch (e) {}
        try {
            const ua = String(navigator?.userAgent || '');
            const maxTouchPoints = Number(navigator?.maxTouchPoints) || 0;
            if (/Mobile|Android|iPhone|iPad|iPod|HarmonyOS/i.test(ua)) return true;
            if (/Macintosh/i.test(ua) && maxTouchPoints > 1) return true;
        } catch (e) {}
        return false;
    }

    function isMobileDevice() {
        if (hasOfficialMobileRuntimeSignal()) return true;
        return isMobileBrowserViewport();
    }

    function isAiFeatureEnabled() {
        try {
            const raw = localStorage.getItem('tm_ai_enabled');
            if (raw === null) return false;
            return raw === 'true' || raw === '1';
        } catch (e) {
            return false;
        }
    }

    async function ensureAiRuntimeLoaded() {
        try {
            if (globalThis.__tmAI?.loaded) return true;
        } catch (e) {}
        const loader = globalThis.__taskHorizonEnsureAiModuleLoaded;
        if (typeof loader !== 'function') return !!globalThis.__tmAI?.loaded;
        try {
            const ok = await loader();
            return !!(ok && globalThis.__tmAI?.loaded);
        } catch (e) {
            return false;
        }
    }

    function markBlockMenuTrigger(target, source) {
        const blockEl = getBlockElementFromTarget(target);
        lastBlockMenuTrigger = {
            ts: Date.now(),
            isTask: isTaskBlockElement(blockEl),
            source
        };
    }

    const __tmQBOnContextmenuCapture = (e) => {
        markBlockMenuTrigger(e.target, 'contextmenu');
    };
    document.addEventListener('contextmenu', __tmQBOnContextmenuCapture, true);

    const __tmQBOnPointerdownCapture = (e) => {
        const t = e.target;
        const isGutterTrigger = isBlockMarkerTarget(t);
        if (!isGutterTrigger) return;
        markBlockMenuTrigger(t, 'gutter');
    };
    document.addEventListener('pointerdown', __tmQBOnPointerdownCapture, true);

    const __tmQBOnAttrHostDragStartCapture = () => {
        quickbarAttrHostDragActive = true;
        quickbarAttrHostLastDragAt = Date.now();
        try { clearQuickbarTaskBindingCaches(); } catch (e) {}
    };
    const __tmQBOnAttrHostDragEndCapture = () => {
        quickbarAttrHostDragActive = false;
        quickbarAttrHostLastDragAt = Date.now();
        quickbarAttrHostLastStructuralAt = Date.now();
        try { clearQuickbarTaskBindingCaches(); } catch (e) {}
        try { quickbarAttrHostMigrationScheduler?.('drag-end'); } catch (e) {}
    };
    document.addEventListener('dragstart', __tmQBOnAttrHostDragStartCapture, true);
    document.addEventListener('dragend', __tmQBOnAttrHostDragEndCapture, true);
    document.addEventListener('drop', __tmQBOnAttrHostDragEndCapture, true);

    const __tmQBOnInlineMetaPointerdownCapture = (e) => {
        const rawTarget = e.target;
        const targetEl = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
        const chip = targetEl?.closest?.('.sy-custom-props-inline-chip');
        const host = chip?.closest?.('.sy-custom-props-inline-host');
        if (!chip || !host) return;
        if (typeof inlineMetaHostPointerDownHandler === 'function') {
            inlineMetaHostPointerDownHandler(host, chip, e, null);
        }
    };
    document.addEventListener('pointerdown', __tmQBOnInlineMetaPointerdownCapture, true);

    const __tmQBOnInlineMetaEditIntentCapture = (e) => {
        if (!QUICKBAR_INLINE_USE_NATIVE_HOST) return;
        const eventType = String(e?.type || '').trim();
        if (eventType === 'keydown') {
            const key = String(e?.key || '');
            const mutatingKey = key.length === 1 || key === 'Enter' || key === 'Backspace' || key === 'Delete';
            if (!mutatingKey || e.ctrlKey || e.metaKey || e.altKey) return;
        }
        const rawTarget = e.target;
        const targetEl = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
        if (!targetEl || targetEl.closest?.('.sy-custom-props-inline-host,.sy-custom-props-inline-chip')) return;
        const editable = targetEl.closest?.('[contenteditable="true"]');
        let taskBlock = editable
            ? (getTaskBlockElementFromTarget(editable) || editable.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]'))
            : null;
        if (!taskBlock) {
            try {
                const selection = window.getSelection?.();
                const nodes = [selection?.anchorNode, selection?.focusNode].filter(Boolean);
                for (let i = 0; i < nodes.length; i += 1) {
                    const node = nodes[i];
                    const el = node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
                    const li = el?.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                    if (li) {
                        taskBlock = li;
                        break;
                    }
                }
            } catch (err) {}
        }
        if (!taskBlock) return;
        if (e.__tmQBInlineEditIntentCaptured) return;
        try { Object.defineProperty(e, '__tmQBInlineEditIntentCaptured', { value: true, configurable: true }); } catch (err) { e.__tmQBInlineEditIntentCaptured = true; }
        try {
            suppressInlineMetaNativeHostForBlock(taskBlock, `edit-intent-${eventType || 'pointer'}`, 8000);
        } catch (err) {}
    };
    window.addEventListener('pointerdown', __tmQBOnInlineMetaEditIntentCapture, true);
    window.addEventListener('mousedown', __tmQBOnInlineMetaEditIntentCapture, true);
    window.addEventListener('keydown', __tmQBOnInlineMetaEditIntentCapture, true);
    document.addEventListener('pointerdown', __tmQBOnInlineMetaEditIntentCapture, true);
    document.addEventListener('mousedown', __tmQBOnInlineMetaEditIntentCapture, true);
    document.addEventListener('keydown', __tmQBOnInlineMetaEditIntentCapture, true);

    const __tmQBOnTaskCheckboxActionCapture = (e) => {
        const rawTarget = e.target;
        const targetEl = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
        const taskAction = targetEl?.closest?.('input[type="checkbox"],.protyle-action__task,.protyle-action--task,.protyle-task--checkbox,.protyle-task,.b3-checkbox');
        if (!taskAction) return;
        const taskBlock = getTaskBlockElementFromTarget(taskAction);
        if (!taskBlock) return;
        if (e.__tmQBTaskCheckboxCaptured) return;
        try { Object.defineProperty(e, '__tmQBTaskCheckboxCaptured', { value: true, configurable: true }); } catch (err) { e.__tmQBTaskCheckboxCaptured = true; }
        try {
            const taskList = taskBlock.parentElement?.matches?.('.list,[data-type="NodeList"]')
                ? taskBlock.parentElement
                : taskBlock.closest?.('.list,[data-type="NodeList"]');
            taskList?.querySelectorAll?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((node) => {
                removeInlineMetaHostNode(node, true);
            });
            taskList?.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((node) => {
                if (!hasInlineMetaInBlockHost(node)) {
                    node.classList.remove('sy-custom-props-inline-parent');
                }
            });
        } catch (err) {}
        try {
            if (typeof pushQuickbarInlineSyncLog === 'function') {
                pushQuickbarInlineSyncLog('checkbox-action-capture', {
                    eventType: String(e?.type || '').trim(),
                    targetClass: String(taskAction?.className || '').trim(),
                    taskId: String(taskBlock?.dataset?.nodeId || '').trim(),
                    hasInBlockHost: !!taskBlock.querySelector?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]'),
                    hasOverlayHost: !!document.querySelector?.(`.sy-custom-props-inline-layer .sy-custom-props-inline-host[data-task-id="${CSS.escape(String(taskBlock?.dataset?.nodeId || '').trim())}"]`),
                });
            }
        } catch (err) {}
        try {
            suppressInlineMetaNativeHostForBlock(taskBlock, 'task-checkbox', 3000);
        } catch (err) {
            try {
                const fallbackId = String(taskBlock?.dataset?.nodeId || '').trim();
                if (fallbackId) removeInlineMetaHostByTaskId(fallbackId, 'in-block');
            } catch (e2) {}
        }
    };
    window.addEventListener('pointerdown', __tmQBOnTaskCheckboxActionCapture, true);
    window.addEventListener('mousedown', __tmQBOnTaskCheckboxActionCapture, true);
    document.addEventListener('pointerdown', __tmQBOnTaskCheckboxActionCapture, true);
    document.addEventListener('mousedown', __tmQBOnTaskCheckboxActionCapture, true);
    document.addEventListener('click', __tmQBOnTaskCheckboxActionCapture, true);

    // ==================== 自定义属性悬浮条核心逻辑 ====================
    async function initSystemVersion() {
        if (!systemVersion) {
            const versionData = await requestApi('/api/system/version');
            systemVersion = versionData?.data || '';
        }
        return systemVersion;
    }

    // ==================== 自定义属性悬浮条核心逻辑 ====================
    if (isEnableCustomPropsBar) {
        initCustomPropsFloatBar();
    }

    function initCustomPropsFloatBar() {
        if (document.getElementById('sy-custom-props-floatbar-style') && document.querySelector('.sy-custom-props-floatbar')) return;

        // 样式定义
        const style = document.createElement('style');
        style.id = 'sy-custom-props-floatbar-style';
        style.textContent = `
            .sy-custom-props-floatbar {
                position: absolute;
                z-index: 3005;
                display: none;
                flex-direction: column;
                align-items: stretch;
                gap: 6px;
                padding: 6px;
                border-radius: 8px;
                background: var(--b3-theme-background);
                border: 1px solid var(--b3-border-color);
                box-shadow: var(--b3-dialog-shadow);
                white-space: nowrap;
                overflow: visible;
                max-width: min(92vw, 980px);
                box-sizing: border-box;
            }
            .sy-custom-props-floatbar__row {
                display: flex;
                align-items: center;
                gap: 6px;
                flex-wrap: nowrap;
                min-width: 0;
                max-width: 100%;
            }
            .sy-custom-props-floatbar__row--main {
                align-items: center;
            }
            .sy-custom-props-floatbar__row--remark {
                max-width: 100%;
                white-space: normal;
                overflow: visible;
            }
            .sy-custom-props-floatbar__head {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                width: 100%;
            }
            .sy-custom-props-floatbar__head-actions {
                display: inline-flex;
                align-items: center;
                gap: 6px;
            }
            .sy-custom-props-floatbar__prop {
                display: inline-flex;
                align-items: center;
                height: 26px;
                padding: 0 6px;
                border-radius: 6px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                font-size: 12px;
                line-height: 26px;
                cursor: pointer;
                user-select: none;
                transition: background-color 0.2s, border-color 0.2s, color 0.2s;
                box-sizing: border-box;
            }
            .sy-custom-props-floatbar__prop:hover {
                background: var(--b3-theme-background);
                border-color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__prop.is-priority-prop {
                border: 0;
                background: transparent;
                padding: 0 2px;
            }
            .sy-custom-props-floatbar__prop.is-priority-prop:hover {
                border: 0;
                background: transparent;
            }
            .sy-custom-props-floatbar__prop.is-active {
                background: var(--b3-theme-primary);
                border-color: var(--b3-theme-primary);
                color: var(--b3-theme-on-primary);
            }
            .sy-custom-props-floatbar__prop-value {
                font-weight: 500;
            }
            .sy-custom-props-focus-actual {
                color: var(--b3-theme-error);
                font-weight: 700;
            }
            .sy-custom-props-floatbar__prop--core {
                gap: 5px;
                padding: 0 8px;
                border-radius: 8px;
            }
            .sy-custom-props-floatbar__prop--remark {
                gap: 5px;
                min-width: 0;
                max-width: min(48vw, 280px);
            }
            .sy-custom-props-floatbar__row--remark .sy-custom-props-floatbar__prop--remark {
                width: 100%;
                max-width: none;
                box-sizing: border-box;
            }
            .sy-custom-props-floatbar__prop--remark:not(.sy-custom-props-floatbar__prop--icon-only) {
                height: 26px;
                min-height: 26px;
                line-height: 26px;
                align-items: center;
            }
            .sy-custom-props-floatbar__prop--custom-field {
                gap: 4px;
                height: auto;
                min-height: 26px;
                padding: 0;
                border: 0;
                background: transparent;
                line-height: normal;
                max-width: min(42vw, 240px);
            }
            .sy-custom-props-floatbar__prop--custom-field:hover {
                border: 0;
                background: transparent;
            }
            .sy-custom-props-floatbar__prop--custom-empty {
                opacity: 0.66;
                padding: 0 8px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                line-height: 26px;
            }
            .sy-custom-props-floatbar__prop--custom-empty:hover {
                border-color: var(--b3-theme-primary);
                background: var(--b3-theme-background);
            }
            .sy-custom-props-floatbar__custom-tags {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                min-width: 0;
                max-width: 100%;
                overflow: hidden;
            }
            .sy-custom-props-floatbar__custom-tags .sy-custom-props-floatbar__option-label--status {
                min-width: 0;
                max-width: 112px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                flex: 0 1 auto;
            }
            .sy-custom-props-floatbar__prop--core .sy-custom-props-floatbar__prop-value {
                display: inline-block;
                max-width: 132px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .sy-custom-props-floatbar__prop--remark .sy-custom-props-floatbar__prop-value {
                display: block;
                max-width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                line-height: 1.35;
            }
            .sy-custom-props-floatbar__prop--icon-only {
                flex: 0 0 26px;
                width: 26px;
                min-width: 26px;
                padding: 0;
                justify-content: center;
            }
            .sy-custom-props-floatbar__status-dot {
                width: 10px;
                height: 10px;
                border-radius: 999px;
                background: var(--qb-status-fg, #757575);
                box-shadow: 0 0 0 1px var(--qb-status-border, rgba(117,117,117,0.35));
                display: inline-block;
                flex: 0 0 auto;
            }
            .sy-custom-props-floatbar__prop-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                line-height: 0;
                flex: 0 0 auto;
            }
            .sy-custom-props-floatbar__prop-icon svg {
                width: 14px;
                height: 14px;
                display: block;
            }
            .sy-custom-props-floatbar [data-tooltip]::after {
                content: none !important;
                display: none !important;
            }
            .sy-custom-props-floatbar [data-tooltip]::before {
                white-space: nowrap;
                border-radius: 6px;
            }
            .sy-custom-props-floatbar [data-tooltip]:not([data-side])::before,
            .sy-custom-props-floatbar [data-tooltip][data-side="top"]::before {
                bottom: calc(100% + 8px);
            }
            .sy-custom-props-floatbar [data-tooltip][data-side="bottom"]::before {
                top: calc(100% + 8px);
            }
            .sy-custom-props-floatbar__select {
                position: absolute;
                z-index: 3006;
                display: none;
                min-width: 120px;
                max-width: 200px;
                padding: 6px;
                border-radius: 8px;
                background: var(--b3-theme-background);
                border: 1px solid var(--b3-border-color);
                box-shadow: var(--b3-dialog-shadow);
            }
            .sy-custom-props-floatbar__select.is-visible {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }
            .sy-custom-props-floatbar__select-list {
                display: flex;
                flex-direction: column;
                gap: 2px;
                max-width: 100%;
            }
            .sy-custom-props-floatbar__option {
                width: 100%;
                text-align: left;
                height: 28px;
                line-height: 28px;
                padding: 0 10px;
                border-radius: 6px;
                border: 0;
                background: transparent;
                color: var(--b3-theme-on-surface);
                cursor: pointer;
                user-select: none;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .sy-custom-props-floatbar__option:hover {
                background: var(--b3-theme-surface-light);
            }
            .sy-custom-props-floatbar__option.is-active {
                background: var(--b3-theme-primary);
                color: var(--b3-theme-on-primary);
            }
            .sy-custom-props-floatbar__option.is-clear,
            .sy-custom-props-floatbar__option.is-done {
                display: flex;
                align-items: center;
                justify-content: flex-start;
                width: auto;
                height: 28px;
                line-height: 28px;
                padding: 0 10px;
                border: 0;
                border-radius: 6px;
                background: transparent;
                box-shadow: none;
                color: var(--b3-theme-on-surface, var(--tm-text-color));
                font-size: 12px;
                font-weight: 400;
            }
            .sy-custom-props-floatbar__option.is-done {
                color: var(--b3-theme-primary, var(--tm-primary-color));
            }
            .sy-custom-props-floatbar__select-actions {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                gap: 2px;
                width: 100%;
                margin-top: 4px;
                padding-top: 4px;
                border-top: 1px solid var(--b3-border-color);
            }
            .sy-custom-props-floatbar__option-label {
                display: inline-flex;
                align-items: center;
                max-width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .sy-custom-props-floatbar__option-label--status {
                padding: 2px 4px;
                border-radius: 5px;
                border: 1px solid var(--qb-status-border, rgba(117,117,117,0.35));
                background: var(--qb-status-bg, rgba(117,117,117,0.16));
                color: var(--qb-status-fg, #5f6368);
                line-height: 1.25;
                font-size: 14px;
                font-weight: 400;
                transition: filter 0.16s ease, opacity 0.16s ease;
            }
            .sy-custom-props-floatbar__option.is-status {
                height: 30px;
                line-height: normal;
                display: flex;
                align-items: center;
            }
            .sy-custom-props-floatbar__option.is-status:hover .sy-custom-props-floatbar__option-label--status {
                filter: saturate(1.08);
                opacity: 0.96;
            }
            .sy-custom-props-floatbar__option.is-status.is-active {
                background: var(--b3-theme-surface-light);
                color: inherit;
            }
            .sy-custom-props-floatbar__priority-chip,
            .sy-custom-props-floatbar__option-label--priority {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                border: 1px solid var(--qb-priority-border, rgba(117,117,117,0.35));
                background: var(--qb-priority-bg, rgba(117,117,117,0.16));
                color: var(--qb-priority-fg, #5f6368);
                line-height: 1.2;
                font-size: 14px;
                font-weight: 600;
                max-width: 100%;
                transition: filter 0.16s ease, opacity 0.16s ease;
            }
            .sy-custom-props-floatbar__priority-chip {
                height: 26px;
                line-height: 26px;
                padding: 0 8px;
                border-radius: 6px;
                box-sizing: content-box;
            }
            .sy-custom-props-floatbar__option-label--priority {
                padding: 2px 6px;
                border-radius: 5px;
            }
            .sy-custom-props-floatbar__priority-icon {
                width: 18px;
                height: 100%;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                line-height: 1;
            }
            .sy-custom-props-floatbar__priority-icon svg {
                width: 18px;
                height: 18px;
                display: block;
            }
            .sy-custom-props-floatbar__priority-chip.is-flag-style .sy-custom-props-floatbar__priority-icon,
            .sy-custom-props-floatbar__option-label--priority.is-flag-style .sy-custom-props-floatbar__priority-icon {
                width: 14px;
            }
            .sy-custom-props-floatbar__priority-chip.is-flag-style .sy-custom-props-floatbar__priority-icon svg,
            .sy-custom-props-floatbar__option-label--priority.is-flag-style .sy-custom-props-floatbar__priority-icon svg {
                width: 14px;
                height: 14px;
            }
            .sy-custom-props-floatbar__priority-text {
                line-height: 1;
            }
            .sy-custom-props-floatbar__option.is-priority {
                height: 30px;
                line-height: normal;
                display: flex;
                align-items: center;
            }
            .sy-custom-props-floatbar__option.is-priority:hover .sy-custom-props-floatbar__option-label--priority {
                filter: saturate(1.08);
                opacity: 0.96;
            }
            .sy-custom-props-floatbar__option.is-priority.is-active {
                background: var(--b3-theme-surface-light);
                color: inherit;
            }
            .sy-custom-props-floatbar__input-editor {
                position: absolute;
                z-index: 3007;
                display: none;
                width: min(280px, calc(100vw - 12px));
                min-width: min(160px, calc(100vw - 12px));
                max-width: calc(100vw - 12px);
                padding: 10px;
                border-radius: 8px;
                background: var(--b3-theme-background);
                border: 1px solid var(--b3-border-color);
                box-shadow: var(--b3-dialog-shadow);
                box-sizing: border-box;
            }
            .sy-custom-props-floatbar__input-editor.is-visible {
                display: block;
            }
            .sy-custom-props-floatbar__input-editor.is-remark {
                width: min(72vw, 420px);
                min-width: min(72vw, 240px);
                max-width: calc(100vw - 12px);
            }
            .sy-custom-props-floatbar__input-editor.is-duration {
                width: min(228px, calc(100vw - 12px));
                min-width: min(188px, calc(100vw - 12px));
                max-width: calc(100vw - 12px);
                padding: 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input {
                width: 100%;
                max-width: 100%;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra.is-visible {
                width: 100%;
                max-width: 100%;
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 6px;
                margin-top: 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-row {
                width: 100%;
                max-width: 100%;
                min-height: 30px;
                border-radius: 7px;
                gap: 4px;
                padding: 5px 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-main {
                gap: 4px;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-icon {
                display: none;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-title {
                font-size: 12px;
                line-height: 1.2;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-tail {
                visibility: hidden;
                width: 14px;
                height: 14px;
                color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-row.is-active {
                border-color: var(--b3-theme-primary);
                background: var(--b3-theme-primary-light, var(--b3-theme-surface-light));
                color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-extra-row.is-active .sy-custom-props-floatbar__input-extra-tail {
                visibility: visible;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__duration-helper {
                grid-column: 1 / -1;
                margin: -1px 0 0;
                white-space: normal;
                line-height: 1.35;
            }
            .sy-custom-props-floatbar__input-editor.is-duration .sy-custom-props-floatbar__input-actions {
                margin-top: 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary {
                width: min(228px, calc(100vw - 12px));
                min-width: min(188px, calc(100vw - 12px));
                padding: 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input {
                width: 100%;
                max-width: 100%;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra.is-visible {
                width: 100%;
                max-width: 100%;
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 6px;
                margin-top: 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-row {
                width: 100%;
                max-width: 100%;
                min-height: 30px;
                border-radius: 7px;
                gap: 4px;
                padding: 5px 8px;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-main {
                gap: 4px;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-icon {
                display: none;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-title {
                font-size: 12px;
                line-height: 1.2;
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-tail {
                visibility: hidden;
                width: 14px;
                height: 14px;
                color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-row.is-active {
                border-color: var(--b3-theme-primary);
                background: var(--b3-theme-primary-light, var(--b3-theme-surface-light));
                color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__input-editor.is-focus-summary .sy-custom-props-floatbar__input-extra-row.is-active .sy-custom-props-floatbar__input-extra-tail {
                visibility: visible;
            }
            .sy-custom-props-floatbar__focus-tabs {
                min-width: 0;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 3px;
                padding: 3px;
                margin-bottom: 8px;
                border-radius: 9px;
                background: var(--b3-theme-surface-light);
            }
            .sy-custom-props-floatbar__focus-tabs button {
                min-height: 26px;
                border: 1px solid transparent;
                border-radius: 7px;
                background: transparent;
                color: var(--b3-theme-on-surface);
                cursor: pointer;
                font-size: 12px;
                font-weight: 700;
                box-sizing: border-box;
            }
            .sy-custom-props-floatbar__focus-tabs button.is-active {
                background: var(--b3-theme-background);
                color: var(--b3-theme-on-background);
                border-color: var(--b3-border-color);
                box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06);
            }
            .sy-custom-props-floatbar__focus-field {
                display: flex;
                flex-direction: column;
                gap: 4px;
                margin-top: 8px;
                font-size: 12px;
                color: var(--b3-theme-on-surface);
            }
            .sy-custom-props-floatbar__focus-field:first-of-type {
                margin-top: 0;
            }
            .sy-custom-props-floatbar__focus-panel[hidden] {
                display: none;
            }
            .sy-custom-props-floatbar__focus-readonly {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 6px;
                margin-top: 8px;
                color: var(--b3-theme-on-surface);
                font-size: 12px;
            }
            .sy-custom-props-floatbar__focus-readonly span {
                min-width: 0;
                padding: 5px 6px;
                border-radius: 6px;
                background: var(--b3-theme-surface-light);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .sy-custom-props-floatbar__focus-readonly b.sy-custom-props-focus-actual {
                color: var(--b3-theme-error);
                font-weight: 700;
            }
            .sy-custom-props-floatbar__remark-toolbar {
                display: none;
                align-items: center;
                gap: 6px;
                flex-wrap: wrap;
                margin-top: 10px;
                padding: 8px 10px;
                border-radius: 999px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                box-shadow: var(--b3-dialog-shadow);
            }
            .sy-custom-props-floatbar__remark-toolbar.is-open {
                display: inline-flex;
            }
            .sy-custom-props-floatbar__remark-tool {
                width: 28px;
                min-width: 28px;
                height: 28px;
                padding: 0;
                border-radius: 8px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                font-size: 13px;
                font-weight: 700;
            }
            .sy-custom-props-floatbar__btn--remark-tools {
                display: none;
                min-width: 28px;
                width: 28px;
                padding: 0;
                font-size: 18px;
                font-weight: 500;
            }
            .sy-custom-props-floatbar__input-editor.is-remark .sy-custom-props-floatbar__btn--remark-tools {
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
            .sy-custom-props-floatbar__input {
                width: 100%;
                box-sizing: border-box;
                height: 28px;
                line-height: 28px;
                padding: 0 8px;
                border-radius: 6px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                outline: none;
                font-size: 13px;
            }
            .sy-custom-props-floatbar__textarea {
                width: 100%;
                box-sizing: border-box;
                min-height: 76px;
                max-height: min(60vh, 560px);
                padding: 6px 8px;
                border-radius: 6px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                outline: none;
                font-size: 13px;
                line-height: 1.45;
                resize: none;
                overflow-y: hidden;
                white-space: pre-wrap;
                overflow-wrap: anywhere;
                font-family: inherit;
            }
            .sy-custom-props-floatbar__input:focus {
                border-color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__textarea:focus {
                border-color: var(--b3-theme-primary);
            }
            .sy-custom-props-floatbar__input.is-hidden,
            .sy-custom-props-floatbar__textarea.is-hidden {
                display: none;
            }
            .sy-custom-props-floatbar__input-actions {
                display: flex;
                justify-content: flex-end;
                gap: 8px;
                margin-top: 10px;
            }
            .sy-custom-props-floatbar__input-extra {
                display: none;
                flex-direction: column;
                gap: 8px;
                margin-top: 10px;
            }
            .sy-custom-props-floatbar__input-extra.is-visible {
                display: flex;
            }
            .sy-custom-props-floatbar__duration-helper {
                font-size: 11px;
                color: var(--b3-theme-on-surface);
                margin-top: -2px;
            }
            .sy-custom-props-floatbar__input-extra-row {
                width: 100%;
                min-height: 38px;
                border: 1px solid var(--b3-border-color);
                border-radius: 10px;
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 10px;
                padding: 8px 10px;
                box-sizing: border-box;
                cursor: pointer;
            }
            .sy-custom-props-floatbar__input-extra-row:hover {
                border-color: var(--b3-theme-primary);
                background: var(--b3-theme-background);
            }
            .sy-custom-props-floatbar__input-extra-main {
                min-width: 0;
                display: flex;
                align-items: center;
                gap: 8px;
                flex: 1 1 auto;
            }
            .sy-custom-props-floatbar__input-extra-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 16px;
                height: 16px;
                color: var(--b3-theme-primary);
                flex: 0 0 auto;
            }
            .sy-custom-props-floatbar__input-extra-text {
                min-width: 0;
                display: flex;
                flex-direction: column;
                gap: 2px;
            }
            .sy-custom-props-floatbar__input-extra-title {
                font-size: 12px;
                font-weight: 600;
                color: var(--b3-theme-on-background);
            }
            .sy-custom-props-floatbar__input-extra-desc {
                font-size: 11px;
                color: var(--b3-theme-on-surface);
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .sy-custom-props-floatbar__input-extra-tail {
                color: var(--b3-theme-on-surface);
                flex: 0 0 auto;
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
            .sy-custom-props-floatbar__btn {
                height: 26px;
                line-height: 26px;
                padding: 0 12px;
                border-radius: 6px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                cursor: pointer;
                user-select: none;
                font-size: 12px;
            }
            .sy-custom-props-floatbar__btn:hover {
                background: var(--b3-theme-background);
            }
            .sy-custom-props-floatbar__action {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                height: 26px;
                width: 26px;
                border-radius: 6px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                cursor: pointer;
                user-select: none;
                transition: background-color 0.2s, border-color 0.2s, color 0.2s;
                padding: 0;
                box-sizing: border-box;
                flex: 0 0 26px;
                min-width: 26px;
            }
            .sy-custom-props-floatbar__action .qb-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                line-height: 0;
            }
            .sy-custom-props-floatbar__action .qb-icon svg {
                width: 14px;
                height: 14px;
                display: block;
            }
            .sy-custom-props-floatbar__action .sy-custom-props-floatbar__action-text {
                max-width: 108px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-size: 12px;
                font-weight: 600;
                line-height: 1;
            }
            .sy-custom-props-floatbar__action.is-wide {
                flex: 0 0 auto;
                width: auto;
                min-width: 26px;
                padding: 0 6px;
                gap: 4px;
            }
            .sy-custom-props-floatbar__action.is-active {
                color: var(--b3-theme-primary);
                border-color: color-mix(in srgb, var(--b3-theme-primary) 58%, var(--b3-border-color) 42%);
                background: color-mix(in srgb, var(--b3-theme-primary-light, var(--b3-theme-surface-light)) 70%, var(--b3-theme-background) 30%);
            }
            .sy-custom-props-floatbar__action:hover {
                background: var(--b3-theme-background);
                border-color: var(--b3-theme-primary);
            }
            @media (max-width: 640px) {
                .sy-custom-props-floatbar {
                    max-width: calc(100vw - 12px);
                }
                .sy-custom-props-floatbar__row--main {
                    overflow-x: auto;
                    overflow-y: hidden;
                    -webkit-overflow-scrolling: touch;
                    scrollbar-width: thin;
                }
                .sy-custom-props-floatbar__row--main > .sy-custom-props-floatbar__prop,
                .sy-custom-props-floatbar__row--main > .sy-custom-props-floatbar__action {
                    flex: 0 0 auto;
                }
                .sy-custom-props-floatbar__prop--remark {
                    max-width: min(72vw, 360px);
                }
                .sy-custom-props-floatbar__prop--remark:not(.sy-custom-props-floatbar__prop--icon-only) {
                    align-items: flex-start;
                    padding-top: 5px;
                    padding-bottom: 5px;
                }
                .sy-custom-props-floatbar__prop--remark .sy-custom-props-floatbar__prop-value {
                    white-space: normal;
                    overflow-wrap: anywhere;
                    word-break: break-word;
                    text-overflow: clip;
                }
                .sy-custom-props-floatbar__prop--remark:not(.sy-custom-props-floatbar__prop--icon-only) .sy-custom-props-floatbar__prop-icon {
                    margin-top: 1px;
                }
            }
            .sy-custom-props-inline-host {
                position: absolute;
                left: 0;
                top: 0;
                transform: none;
                display: inline-flex;
                align-items: center;
                gap: 4px;
                flex-wrap: nowrap;
                vertical-align: middle;
                white-space: nowrap;
                max-width: min(48vw, 420px);
                z-index: 1;
                visibility: hidden;
                opacity: 0;
                pointer-events: none;
                transition: opacity 140ms cubic-bezier(0.22, 1, 0.36, 1), visibility 0s linear 140ms;
            }
            .sy-custom-props-inline-host.is-ready {
                visibility: visible;
                opacity: 1;
                pointer-events: auto;
                transition-delay: 0s, 0s;
            }
            .sy-custom-props-inline-host.is-wrap {
                flex-wrap: wrap;
                align-items: flex-start;
                row-gap: 4px;
                white-space: normal;
            }
            .sy-custom-props-inline-parent {
                position: relative;
            }
            .sy-custom-props-inline-host[data-inline-placement="in-block"] {
                position: absolute;
                left: 0;
                right: auto;
                top: 0;
                transform: none;
                display: inline-flex;
                margin-left: 0;
                max-width: min(44vw, 420px);
                z-index: 2;
                text-decoration: none;
                contain: layout style;
            }
            .sy-custom-props-inline-host[data-inline-placement="in-block"].is-wrap {
                max-width: min(72vw, 560px);
            }
            .sy-custom-props-inline-chip {
                display: inline-flex;
                align-items: center;
                gap: 4px;
                max-width: min(26vw, 180px);
                min-height: 20px;
                padding: 0 6px;
                border-radius: 999px;
                border: 1px solid var(--b3-border-color);
                background: var(--b3-theme-surface);
                color: var(--b3-theme-on-surface);
                font-size: 11px;
                line-height: 1.2;
                cursor: pointer;
                user-select: none;
                vertical-align: middle;
                flex: 0 0 auto;
            }
            .sy-custom-props-inline-chip:hover {
                filter: saturate(1.05);
                border-color: var(--b3-theme-primary);
            }
            .sy-custom-props-inline-chip-label,
            .sy-custom-props-inline-chip-value {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 100%;
            }
            .sy-custom-props-inline-chip-label {
                opacity: 0.66;
            }
            .sy-custom-props-inline-chip.is-empty {
                opacity: 0.7;
                border-style: dashed;
            }
            .sy-custom-props-inline-chip--status {
                padding: 0;
                border: 0;
                background: transparent;
            }
            .sy-custom-props-inline-chip--time {
                min-width: 0;
                padding: 0 6px;
            }
            .sy-custom-props-inline-chip--subtask-count {
                cursor: default;
            }
            .sy-custom-props-inline-chip--subtask-count:hover {
                border-color: var(--b3-border-color);
            }
            .sy-custom-props-inline-chip--tomato-count {
                min-width: 0;
                padding: 0 6px;
            }
            .sy-custom-props-inline-chip--focus-summary {
                min-width: 0;
                padding: 0 6px;
                font-variant-numeric: tabular-nums;
            }
            .sy-custom-props-inline-chip--remark {
                display: inline-flex;
                align-items: center;
                min-width: 0;
                max-width: min(34vw, 280px);
            }
            .sy-custom-props-inline-chip--remark .sy-custom-props-inline-chip-value {
                display: block;
                max-width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .sy-custom-props-inline-chip--priority {
                padding: 0;
                border: 0;
                background: transparent;
            }
            .sy-custom-props-inline-chip--priority .sy-custom-props-floatbar__priority-chip {
                height: 20px;
                line-height: 20px;
                padding: 0 6px;
                border-radius: 999px;
            }
            .sy-custom-props-inline-chip--custom-field {
                padding: 0;
                border: 0;
                background: transparent;
            }
            .sy-custom-props-inline-chip--custom-field:hover {
                border: 0;
                background: transparent;
            }
            .sy-custom-props-inline-chip--priority .sy-custom-props-floatbar__priority-icon {
                width: 14px;
            }
            .sy-custom-props-inline-chip--priority .sy-custom-props-floatbar__priority-icon svg {
                width: 14px;
                height: 14px;
            }
            .sy-custom-props-inline-chip .sy-custom-props-floatbar__priority-chip,
            .sy-custom-props-inline-chip .sy-custom-props-floatbar__option-label--status {
                font-size: 12px;
            }
            .sy-custom-props-inline-layer {
                position: absolute;
                inset: 0;
                pointer-events: none;
                z-index: 1;
                overflow: visible;
                /* Isolate layout & style invalidation from the protyle's
                   editor surface — chip writes should never propagate
                   layout dirty bits up into SiYuan's editor tree. */
                contain: layout style;
            }
            .sy-custom-props-inline-layer.is-scrolling .sy-custom-props-inline-host {
                transition: none !important;
            }
            @media (prefers-reduced-motion: reduce) {
                .sy-custom-props-inline-host {
                    transition: none;
                }
            }
        `.trim();
        document.head.appendChild(style);

        // 主悬浮条容器
        const floatBar = document.createElement('div');
        floatBar.className = 'sy-custom-props-floatbar';
        document.body.appendChild(floatBar);

        // 选择下拉菜单
        const selectMenu = document.createElement('div');
        selectMenu.className = 'sy-custom-props-floatbar__select';
        document.body.appendChild(selectMenu);

        // 输入编辑器
        const inputEditor = document.createElement('div');
        inputEditor.className = 'sy-custom-props-floatbar__input-editor';
        inputEditor.innerHTML = `
            <input type="text" class="sy-custom-props-floatbar__input" placeholder="输入内容..." />
            <textarea class="sy-custom-props-floatbar__textarea is-hidden" placeholder="输入内容..."></textarea>
            <div class="sy-custom-props-floatbar__input-extra" data-input-extra></div>
            <div class="sy-custom-props-floatbar__remark-toolbar" data-remark-toolbar hidden>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="bullet"${buildTooltipAttrs('无序列表')}>•</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="ordered"${buildTooltipAttrs('有序列表')}>1.</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="bold"${buildTooltipAttrs('粗体')}>B</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="italic"${buildTooltipAttrs('斜体')}>I</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="code"${buildTooltipAttrs('行内代码')}>Code</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="link"${buildTooltipAttrs('链接')}>∞</button>
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__remark-tool" data-remark-tool="quote"${buildTooltipAttrs('引用')}>❝</button>
            </div>
            <div class="sy-custom-props-floatbar__input-actions">
                <button class="sy-custom-props-floatbar__btn sy-custom-props-floatbar__btn--remark-tools" data-action="remark-tools">A</button>
                <button class="sy-custom-props-floatbar__btn" data-action="cancel">取消</button>
                <button class="sy-custom-props-floatbar__btn" data-action="save">确定</button>
            </div>
        `.trim();
        document.body.appendChild(inputEditor);

        // 状态变量
        let currentBlockEl = null;
        let currentBlockId = '';
        let currentTaskId = '';
        let currentTaskName = '';
        let currentProps = {};  // 当前块的所有自定义属性值
        let currentReminderSnapshot = null;
        let currentReminderRefreshToken = 0;
        let currentFloatBarLoadToken = 0;
        let activePropConfig = null;  // 当前编辑的属性配置
        let inputResolve = null;  // 输入框Promise解析器
        const QUICKBAR_AUTO_HIDE_DELAY = 5000;
        let quickbarAutoHideTimer = null;
        let quickbarAutoHidePointerEnterHandler = null;
        let quickbarAutoHidePointerLeaveHandler = null;
        let quickbarAutoHideActivityHandler = null;

        function getInputEditorControls() {
            return {
                input: inputEditor.querySelector('.sy-custom-props-floatbar__input'),
                textarea: inputEditor.querySelector('.sy-custom-props-floatbar__textarea')
            };
        }

        function cleanupFocusSummaryEditorScaffold() {
            try { inputEditor.querySelector('[data-focus-summary-tabs]')?.remove?.(); } catch (e) {}
            try {
                const durationPanel = inputEditor.querySelector('[data-focus-summary-duration-panel]');
                if (durationPanel instanceof HTMLElement) {
                    const input = durationPanel.querySelector('.sy-custom-props-floatbar__input');
                    const extraPanel = durationPanel.querySelector('[data-input-extra]');
                    if (input instanceof HTMLElement) {
                        inputEditor.insertBefore(input, durationPanel);
                    }
                    if (extraPanel instanceof HTMLElement) {
                        const remarkToolbar = inputEditor.querySelector('[data-remark-toolbar]');
                        const actions = inputEditor.querySelector('.sy-custom-props-floatbar__input-actions');
                        if (remarkToolbar instanceof HTMLElement) inputEditor.insertBefore(extraPanel, remarkToolbar);
                        else if (actions instanceof HTMLElement) inputEditor.insertBefore(extraPanel, actions);
                        else inputEditor.appendChild(extraPanel);
                    }
                    durationPanel.remove();
                }
            } catch (e) {}
            try { inputEditor.querySelector('[data-focus-summary-estimate-field]')?.remove?.(); } catch (e) {}
            try { inputEditor.querySelector('[data-focus-summary-readonly]')?.remove?.(); } catch (e) {}
        }

        function syncInputEditorTextareaHeight(textarea, minHeight = 76) {
            if (!(textarea instanceof HTMLTextAreaElement)) return;
            const baseHeight = Math.max(34, Number(minHeight) || 76);
            try { textarea.style.height = 'auto'; } catch (e) {}
            const nextHeight = Math.max(baseHeight, Math.min(420, textarea.scrollHeight || 0));
            textarea.style.height = `${nextHeight}px`;
        }

        function positionPopupNearAnchor(popupEl, anchorEl, options = {}) {
            if (!(popupEl instanceof HTMLElement) || !(anchorEl instanceof HTMLElement)) return;
            const gap = Math.max(0, Number(options.gap) || 4);
            const viewportMargin = Math.max(4, Number(options.viewportMargin) || 6);
            const viewportW = document.documentElement?.clientWidth || window.innerWidth || 0;
            const viewportH = document.documentElement?.clientHeight || window.innerHeight || 0;
            if (!viewportW || !viewportH) return;

            const anchorRect = anchorEl.getBoundingClientRect();
            const popupRect = popupEl.getBoundingClientRect();
            const popupWidth = Math.min(
                Math.max(0, popupRect.width || popupEl.offsetWidth || 0),
                Math.max(0, viewportW - viewportMargin * 2)
            );
            const popupHeight = Math.min(
                Math.max(0, popupRect.height || popupEl.offsetHeight || 0),
                Math.max(0, viewportH - viewportMargin * 2)
            );
            const viewportLeft = window.scrollX;
            const viewportTop = window.scrollY;
            const minLeft = viewportLeft + viewportMargin;
            const maxLeft = viewportLeft + Math.max(viewportMargin, viewportW - popupWidth - viewportMargin);
            let left = viewportLeft + anchorRect.left;
            if (left + popupWidth > viewportLeft + viewportW - viewportMargin) {
                left = viewportLeft + anchorRect.right - popupWidth;
            }
            left = Math.max(minLeft, Math.min(left, maxLeft));

            const minTop = viewportTop + viewportMargin;
            const maxTop = viewportTop + Math.max(viewportMargin, viewportH - popupHeight - viewportMargin);
            const belowTop = viewportTop + anchorRect.bottom + gap;
            const aboveTop = viewportTop + anchorRect.top - popupHeight - gap;
            let top = belowTop;
            if (belowTop + popupHeight > viewportTop + viewportH - viewportMargin && aboveTop >= minTop) {
                top = aboveTop;
            }
            top = Math.max(minTop, Math.min(top, maxTop));

            popupEl.style.left = `${Math.round(left)}px`;
            popupEl.style.top = `${Math.round(top)}px`;
        }

        function isQuickbarInteractionTarget(target) {
            return !!target && (
                floatBar.contains(target)
                || selectMenu.contains(target)
                || inputEditor.contains(target)
            );
        }

        function isQuickbarInputFocused() {
            const active = document.activeElement;
            return inputEditor.classList.contains('is-visible') && isQuickbarInteractionTarget(active);
        }

        function clearQuickbarAutoHideTimer() {
            if (!quickbarAutoHideTimer) return;
            try { clearTimeout(quickbarAutoHideTimer); } catch (e) {}
            quickbarAutoHideTimer = null;
        }

        function scheduleQuickbarAutoHide() {
            clearQuickbarAutoHideTimer();
            if (!quickbarStarted || floatBar.style.display === 'none') return;
            quickbarAutoHideTimer = setTimeout(() => {
                quickbarAutoHideTimer = null;
                if (!quickbarStarted || floatBar.style.display === 'none') return;
                if (isQuickbarInputFocused()) {
                    scheduleQuickbarAutoHide();
                    return;
                }
                hideFloatBar();
            }, QUICKBAR_AUTO_HIDE_DELAY);
        }

        function noteQuickbarActivity() {
            if (floatBar.style.display === 'none') return;
            scheduleQuickbarAutoHide();
        }

        function bindQuickbarAutoHideEvents() {
            if (quickbarAutoHidePointerEnterHandler || quickbarAutoHidePointerLeaveHandler || quickbarAutoHideActivityHandler) return;
            quickbarAutoHidePointerEnterHandler = () => {
                noteQuickbarActivity();
            };
            quickbarAutoHidePointerLeaveHandler = () => {
                scheduleQuickbarAutoHide();
            };
            quickbarAutoHideActivityHandler = () => noteQuickbarActivity();
            [floatBar, selectMenu, inputEditor].forEach((el) => {
                try { el.addEventListener('pointerenter', quickbarAutoHidePointerEnterHandler, true); } catch (e) {}
                try { el.addEventListener('pointerleave', quickbarAutoHidePointerLeaveHandler, true); } catch (e) {}
                try { el.addEventListener('pointermove', quickbarAutoHideActivityHandler, { capture: true, passive: true }); } catch (e) {}
                try { el.addEventListener('pointerdown', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { el.addEventListener('click', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { el.addEventListener('keydown', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { el.addEventListener('input', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { el.addEventListener('change', quickbarAutoHideActivityHandler, true); } catch (e) {}
            });
        }

        function unbindQuickbarAutoHideEvents() {
            [floatBar, selectMenu, inputEditor].forEach((el) => {
                try { if (quickbarAutoHidePointerEnterHandler) el.removeEventListener('pointerenter', quickbarAutoHidePointerEnterHandler, true); } catch (e) {}
                try { if (quickbarAutoHidePointerLeaveHandler) el.removeEventListener('pointerleave', quickbarAutoHidePointerLeaveHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('pointermove', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('pointerdown', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('click', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('keydown', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('input', quickbarAutoHideActivityHandler, true); } catch (e) {}
                try { if (quickbarAutoHideActivityHandler) el.removeEventListener('change', quickbarAutoHideActivityHandler, true); } catch (e) {}
            });
            quickbarAutoHidePointerEnterHandler = null;
            quickbarAutoHidePointerLeaveHandler = null;
            quickbarAutoHideActivityHandler = null;
            clearQuickbarAutoHideTimer();
        }

        function setInputEditorMode(mode = 'input') {
            cleanupFocusSummaryEditorScaffold();
            const { input, textarea } = getInputEditorControls();
            const useTextarea = mode === 'textarea';
            const remarkToolbar = inputEditor.querySelector('[data-remark-toolbar]');
            const extraPanel = inputEditor.querySelector('[data-input-extra]');
            const cancelBtn = inputEditor.querySelector('[data-action="cancel"]');
            if (cancelBtn instanceof HTMLButtonElement) cancelBtn.textContent = '取消';
            if (input instanceof HTMLInputElement) {
                input.classList.toggle('is-hidden', useTextarea);
                input.disabled = useTextarea;
                input.oninput = null;
                input.onkeydown = null;
                input.onchange = null;
                input.onclick = null;
            }
            if (textarea instanceof HTMLTextAreaElement) {
                textarea.classList.toggle('is-hidden', !useTextarea);
                textarea.disabled = !useTextarea;
                textarea.oninput = null;
                textarea.onkeydown = null;
                textarea.oncompositionstart = null;
                textarea.oncompositionend = null;
            }
            inputEditor.classList.toggle('is-remark', useTextarea);
            inputEditor.classList.remove('is-duration', 'is-focus-summary');
            if (remarkToolbar instanceof HTMLElement) {
                remarkToolbar.classList.remove('is-open');
                remarkToolbar.hidden = true;
            }
            if (extraPanel instanceof HTMLElement) {
                extraPanel.classList.remove('is-visible');
                extraPanel.innerHTML = '';
            }
            return useTextarea ? textarea : input;
        }

        function getBlockElById(blockId) {
            const id = String(blockId || '').trim();
            if (!id) return null;
            return document.querySelector(`.li[data-node-id="${id}"],[data-type="NodeListItem"][data-node-id="${id}"],[data-node-id="${id}"]`);
        }

        function getTaskListElById(blockId) {
            const id = String(blockId || '').trim();
            if (!id) return null;
            return document.querySelector(`.list[data-node-id="${id}"],[data-type="NodeList"][data-node-id="${id}"]`);
        }

        function resolveQuickbarBindingForHostIds(taskIdInput = '', attrHostIdInput = '', ownerIdInput = '', preferredBlockEl = null) {
            const expectedTaskId = String(taskIdInput || '').trim();
            const expectedHostId = String(attrHostIdInput || ownerIdInput || '').trim();
            const ownerId = String(ownerIdInput || expectedHostId || expectedTaskId || '').trim();
            const candidates = [];
            const seen = new WeakSet();
            const addCandidate = (el) => {
                if (!(el instanceof Element)) return;
                if (seen.has(el)) return;
                const directId = String(el?.dataset?.nodeId || el?.getAttribute?.('data-node-id') || '').trim();
                if (!directId) return;
                seen.add(el);
                candidates.push(el);
            };
            addCandidate(preferredBlockEl?.isConnected ? preferredBlockEl : null);
            if (expectedTaskId) addCandidate(getBlockElById(expectedTaskId));
            [expectedHostId, ownerId].forEach((id) => {
                if (!id) return;
                addCandidate(getTaskListElById(id));
                addCandidate(getBlockElById(id));
            });
            const resolved = [];
            candidates.forEach((el) => {
                let binding = null;
                try { binding = resolveTaskBindingFromBlockEl(el); } catch (e) { binding = null; }
                const liveTaskId = String(binding?.taskId || '').trim();
                const liveAttrHostId = String(binding?.attrHostId || binding?.taskId || '').trim();
                if (!liveTaskId && !liveAttrHostId) return;
                const taskEl = liveTaskId ? getBlockElById(liveTaskId) : null;
                resolved.push({
                    blockEl: taskEl || el,
                    binding,
                    taskId: liveTaskId,
                    attrHostId: liveAttrHostId,
                });
            });
            return resolved.find((item) => expectedTaskId && item.taskId === expectedTaskId && (!expectedHostId || item.attrHostId === expectedHostId))
                || resolved.find((item) => expectedHostId && item.attrHostId === expectedHostId)
                || resolved.find((item) => ownerId && item.attrHostId === ownerId)
                || resolved.find((item) => expectedTaskId && item.taskId === expectedTaskId)
                || resolved[0]
                || null;
        }

        function updateCurrentTaskContext(blockEl, attrHostId = '') {
            currentBlockEl = blockEl || null;
            let binding = null;
            try {
                binding = resolveTaskBindingFromBlockEl(blockEl);
            } catch (e) {
                binding = null;
            }
            const fallbackId = String(blockEl?.dataset?.nodeId || '').trim();
            const taskId = String(binding?.taskId || fallbackId).trim();
            const hostId = String(attrHostId || binding?.attrHostId || taskId || fallbackId).trim();
            currentBlockId = hostId || fallbackId;
            currentTaskId = taskId || currentBlockId;
            try {
                currentTaskName = getTaskTitleFromBlockEl(blockEl);
            } catch (e) {
                currentTaskName = '';
            }
            try { maybeRequestQuickbarSubtaskFieldInheritance(blockEl, binding, 'current-task-context'); } catch (e) {}
        }

        function resolveCurrentTaskId() {
            if (String(currentTaskId || '').trim()) return String(currentTaskId).trim();
            const blockEl = currentBlockEl || getTaskListElById(currentBlockId) || getBlockElById(currentBlockId) || null;
            const resolvedId = String(resolveTaskNodeIdForDetail(blockEl) || '').trim();
            if (resolvedId) return resolvedId;
            return String(currentBlockId || '').trim();
        }

        const __TM_TASK_HORIZON_DEBUG_RELAY_STORAGE_KEY = '__tmTaskHorizonDebugRelay';
        const __TM_TASK_HORIZON_ATTR_RELAY_STORAGE_KEY = '__tmTaskHorizonAttrRelay';
        let __tmTaskHorizonRelaySeq = 0;

        function relayTaskHorizonPayloadToStorage(storageKey, kind, detail = {}) {
            const key = String(storageKey || '').trim();
            const relayKind = String(kind || '').trim();
            if (!key || !relayKind) return null;
            const relayDetail = (detail && typeof detail === 'object' && !Array.isArray(detail)) ? detail : {};
            const entry = {
                kind: relayKind,
                source: 'quickbar',
                time: new Date().toISOString(),
                ts: Date.now(),
                seq: (__tmTaskHorizonRelaySeq = (Number(__tmTaskHorizonRelaySeq || 0) + 1)),
                detail: relayDetail,
            };
            try {
                localStorage.setItem(key, JSON.stringify(entry));
                return entry;
            } catch (e) {
                return null;
            }
        }

        function pushTaskHorizonDebug(channel, tag, payload = {}) {
            return null;
        }

        function dispatchTaskAttrUpdated(attrHostId, attrKey, value, options = {}) {
            const key = String(attrKey || '').trim();
            const hostId = String(attrHostId || currentBlockId || '').trim();
            const opts = (options && typeof options === 'object') ? options : {};
            const explicitTaskId = String(opts.taskId || opts.resolvedTaskId || '').trim();
            const requestedTaskId = String(opts.requestedTaskId || hostId || '').trim();
            const blockEl = getTaskListElById(hostId) || getBlockElById(hostId) || currentBlockEl || null;
            const taskId = String(explicitTaskId || resolveTaskNodeIdForDetail(blockEl) || resolveCurrentTaskId() || requestedTaskId || hostId).trim();
            const nextValue = value == null ? '' : String(value);
            if (!key || (!taskId && !hostId)) return;
            const detail = {
                taskId: taskId || hostId,
                requestedTaskId: requestedTaskId || taskId || hostId,
                attrHostId: hostId || taskId,
                attrKey: key,
                value: nextValue,
                source: 'quickbar',
            };
            const sharedApi = getTaskHorizonSharedApi();
            const quickbarBridge = sharedApi?.quickbarBridge || null;
            pushTaskHorizonDebug('refresh', 'quickbar-dispatch', {
                taskId: taskId || hostId,
                requestedTaskId: requestedTaskId || taskId || hostId,
                attrHostId: hostId || taskId,
                attrKey: key,
                value: nextValue,
                hasNamespaceNotifyHook: typeof quickbarBridge?.notifyAttrUpdated === 'function',
                hasNamespaceMarkHook: typeof quickbarBridge?.markModified === 'function',
                hasNamespaceRefreshHook: typeof quickbarBridge?.refresh === 'function',
                hasMarkModifiedHook: typeof globalThis.__taskHorizonMarkModified === 'function',
                hasRefreshHook: typeof globalThis.__taskHorizonRefresh === 'function',
            });
            try {
                const bridgeNotify = quickbarBridge?.notifyAttrUpdated;
                if (typeof bridgeNotify === 'function') {
                    const handled = bridgeNotify(detail);
                    if (handled !== false) {
                        pushTaskHorizonDebug('refresh', 'quickbar-dispatch:namespace-bridge', {
                            taskId: taskId || hostId,
                            attrHostId: hostId || taskId,
                            attrKey: key,
                        });
                        return;
                    }
                }
            } catch (e) {}
            try {
                window.dispatchEvent(new CustomEvent('tm-task-attr-updated', {
                    detail
                }));
            } catch (e) {}
            try {
                relayTaskHorizonPayloadToStorage(__TM_TASK_HORIZON_ATTR_RELAY_STORAGE_KEY, 'attr-updated', detail);
            } catch (e) {}
            try {
                if (taskId) {
                    globalThis.__taskHorizonMarkModified?.(taskId);
                    pushTaskHorizonDebug('refresh', 'quickbar-dispatch:mark-modified', {
                        taskId,
                        attrHostId: hostId || taskId,
                        attrKey: key,
                    });
                }
            } catch (e) {}
            try {
                pushTaskHorizonDebug('refresh', 'quickbar-dispatch:refresh-scheduled', {
                    taskId: taskId || hostId,
                    attrHostId: hostId || taskId,
                    attrKey: key,
                });
                const scheduled = typeof globalThis.__taskHorizonScheduleQuickbarRefresh === 'function'
                    ? globalThis.__taskHorizonScheduleQuickbarRefresh({
                        source: 'quickbar-dispatch',
                        taskId: taskId || hostId,
                        attrHostId: hostId || taskId,
                        attrKey: key,
                    })
                    : false;
                if (!scheduled) {
                    setTimeout(() => {
                        pushTaskHorizonDebug('refresh', 'quickbar-dispatch:refresh-fire', {
                            taskId: taskId || hostId,
                            attrHostId: hostId || taskId,
                            attrKey: key,
                        });
                        try { globalThis.__taskHorizonRefresh?.(); } catch (e) {}
                    }, 0);
                }
            } catch (e) {}
        }

        function getTaskHorizonSharedApi() {
            try {
                const api = globalThis?.['siyuan-plugin-task-horizon'];
                return api && typeof api === 'object' ? api : null;
            } catch (e) {
                return null;
            }
        }

        function suppressTaskHorizonMobileTopbarOpen(ttl = 1200) {
            try {
                if (!isMobileDevice()) return;
                const until = Date.now() + Math.max(200, Number(ttl) || 1200);
                globalThis.__taskHorizonSuppressMobileTopbarOpenUntil = Math.max(
                    Number(globalThis.__taskHorizonSuppressMobileTopbarOpenUntil || 0),
                    until
                );
            } catch (e) {}
        }

        function resolveCurrentTaskName() {
            if (String(currentTaskName || '').trim()) return String(currentTaskName).trim();
            const blockEl = currentBlockEl || getBlockElById(currentBlockId) || null;
            return getTaskTitleFromBlockEl(blockEl);
        }

        function isCurrentFloatBarContext(expectedBlockId = '', expectedTaskId = '', token = currentFloatBarLoadToken) {
            if (token !== currentFloatBarLoadToken) return false;
            if (!floatBar || floatBar.style.display === 'none') return false;
            const liveBlockId = String(currentBlockId || '').trim();
            const liveTaskId = String(resolveCurrentTaskId() || '').trim();
            if (expectedBlockId && liveBlockId && expectedBlockId !== liveBlockId) return false;
            if (expectedTaskId && liveTaskId && expectedTaskId !== liveTaskId) return false;
            return true;
        }

        function rerenderFloatBarIfCurrent(expectedBlockId = '', expectedTaskId = '', token = currentFloatBarLoadToken) {
            if (!isCurrentFloatBarContext(expectedBlockId, expectedTaskId, token)) return false;
            renderFloatBar();
            updatePosition();
            return true;
        }

        function normalizeReminderTaskName(value) {
            let text = String(value || '').split(/\r?\n/)[0].trim();
            if (!text) return '任务';
            text = text.replace(/^[\s>*-]*\[[xX ]\]\s*/, '').trim();
            text = text.replace(/\{\:\s*[^}]*\}/g, '');
            text = text.replace(/<span\b[^>]*>([\s\S]*?)<\/span>/gi, '$1');
            text = text.replace(/<[^>]+>/g, '');
            text = text.replace(/\s{2,}/g, ' ').trim();
            return text || '任务';
        }

        async function openReminderDialogForCurrentTask() {
            const showDialog = globalThis.__tomatoReminder?.showDialog;
            if (typeof showDialog !== 'function') {
                if (typeof window.tmReminder === 'function') {
                    const fallbackTaskId = String(resolveCurrentTaskId() || currentBlockId || '').trim();
                    if (!fallbackTaskId) {
                        showMessage('未找到任务', true, 1800);
                        return;
                    }
                    Promise.resolve(window.tmReminder(fallbackTaskId)).catch(() => {
                        showMessage('未检测到底栏番茄钟插件，请前往集市安装底栏番茄钟插件', true, 2000);
                    });
                    scheduleCurrentReminderSnapshotRefresh(true);
                    return;
                }
                showMessage('未检测到底栏番茄钟插件，请前往集市安装底栏番茄钟插件', true, 2000);
                return;
            }

            const fallbackId = String(resolveCurrentTaskId() || currentBlockId || '').trim();
            const fallbackName = normalizeReminderTaskName(resolveCurrentTaskName());
            let taskLike = null;
            const buildTaskLike = globalThis.__taskHorizonBuildTaskLikeFromBlockId;
            if (typeof buildTaskLike === 'function' && fallbackId) {
                try { taskLike = await buildTaskLike(fallbackId); } catch (e) { taskLike = null; }
            }

            const candidateIds = [];
            const pushCandidateId = (value) => {
                const id = String(value || '').trim();
                if (!id) return;
                if (candidateIds.includes(id)) return;
                candidateIds.push(id);
            };

            pushCandidateId(taskLike?.id);
            pushCandidateId(fallbackId);
            pushCandidateId(currentTaskId);
            pushCandidateId(currentBlockId);
            pushCandidateId(resolveTaskNodeIdForDetail(currentBlockEl));
            pushCandidateId(resolveTaskAttrNodeIdForDetail(currentBlockEl));
            pushCandidateId(currentBlockEl?.dataset?.nodeId);

            if (!candidateIds.length) {
                showMessage('未找到任务', true, 1800);
                return;
            }

            const candidateNameMap = new Map();
            const normalizedTaskLikeName = normalizeReminderTaskName(taskLike?.content || taskLike?.raw_content || '');
            candidateIds.forEach((id) => {
                candidateNameMap.set(id, normalizedTaskLikeName || fallbackName || '任务');
            });
            if (fallbackId && fallbackName) candidateNameMap.set(fallbackId, fallbackName);

            const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
            const hasReminderDialog = () => !!document.getElementById('tomato-reminder-backdrop');

            try {
                document.getElementById('tomato-reminder-dialog')?.remove();
                document.getElementById('tomato-reminder-backdrop')?.remove();
            } catch (e) {}

            for (const candidateId of candidateIds) {
                const name = String(candidateNameMap.get(candidateId) || fallbackName || '任务').trim() || '任务';
                for (let attempt = 0; attempt < 2; attempt += 1) {
                    try { showDialog(candidateId, name); } catch (e) {}
                    await wait(attempt === 0 ? 120 : 180);
                    if (hasReminderDialog()) {
                        scheduleCurrentReminderSnapshotRefresh(true);
                        return;
                    }
                }
            }

            showMessage('未能打开提醒设置，请确认任务块与番茄钟插件状态', true, 2400);
        }

        async function openRepeatDialogForCurrentTask() {
            const openRepeat = globalThis.tmEditTaskRepeatRule;
            if (typeof openRepeat !== 'function') {
                showMessage('未检测到任务循环功能，请确认任务管理器已启用', true, 2000);
                return null;
            }
            const candidateIds = [
                resolveCurrentTaskId(),
                currentTaskId,
                currentBlockId,
                resolveTaskNodeIdForDetail(currentBlockEl),
                resolveTaskAttrNodeIdForDetail(currentBlockEl),
                currentBlockEl?.dataset?.nodeId,
            ].map((id) => String(id || '').trim()).filter(Boolean);
            const uniqIds = Array.from(new Set(candidateIds));
            if (!uniqIds.length) {
                showMessage('未找到任务', true, 1800);
                return null;
            }
            for (const candidateId of uniqIds) {
                try {
                    const result = await openRepeat(candidateId);
                    if (result !== null) return { candidateId, result };
                } catch (e) {}
            }
            showMessage('未能打开循环设置，请确认任务块状态', true, 2200);
            return null;
        }

        async function getRepeatRuleForTask(taskId) {
            const getter = globalThis.tmGetTaskRepeatRule;
            if (typeof getter !== 'function') return null;
            const id = String(taskId || '').trim();
            if (!id) return null;
            try { return await getter(id); } catch (e) { return null; }
        }

        async function resolveCurrentTaskIdForAi() {
            const rawId = String(resolveCurrentTaskId() || '').trim();
            if (!rawId) return '';
            try {
                const bridge = globalThis?.['siyuan-plugin-task-horizon']?.aiBridge;
                if (typeof bridge?.resolveTaskId === 'function') {
                    const resolved = String(await bridge.resolveTaskId(rawId) || '').trim();
                    if (resolved) return resolved;
                }
            } catch (e) {}
            return rawId;
        }

        // ==================== 核心功能函数 ====================

        // 更新配置中的状态选项
        function updateStatusOptionsInConfig() {
            const statusOptions = getStatusOptionsSnapshot();
            const statusConfig = [...customPropsConfig.firstRow, ...customPropsConfig.secondRow]
                .find(p => p.attrKey === 'custom-status');
            if (statusConfig) {
                statusConfig.options = statusOptions.map(o => ({
                    value: o.id,
                    label: o.name,
                    color: o.color
                }));
                statusConfig.defaultValue = getDefaultUndoneStatusId(statusOptions);
            }
        }

        // 从任务管理器读取状态选项
        async function loadStatusOptions() {
            try {
                getStatusOptionsSnapshot();
                updateStatusOptionsInConfig();
            } catch (e) {
                console.warn('读取状态选项失败:', e);
            }
        }

        __tmQBStatusRenderStorageHandler = (e) => {
            if (!e) return;
            if (e.key === 'tm_custom_status_options' || e.key === 'tm_checkbox_undone_status_id') {
                loadStatusOptions().then(() => {
                    try { renderFloatBar(); } catch (e) {}
                    try { scheduleInlineMetaRender(true); } catch (e) {}
                });
                return;
            }
            if (e.key === 'tm_enable_quickbar_inline_meta' || e.key === 'tm_quickbar_inline_fields' || e.key === 'tm_quickbar_inline_show_on_mobile' || e.key === 'tm_quickbar_subtask_count_unfinished_only') {
                try { refreshInlineMetaMode(true); } catch (e) {}
                return;
            }
            if (e.key === 'tm_custom_field_defs' || e.key === 'tm_custom_field_defs_version') {
                invalidateQuickbarInlineSettingsCache();
                try { renderFloatBar(); } catch (e) {}
                try { refreshInlineMetaMode(true); } catch (e) {}
                return;
            }
            if (e.key === 'tm_task_meta_attr_keys' || e.key === 'tm_task_meta_attr_key_aliases') {
                invalidateQuickbarTaskMetaAttrSettingsCache();
                try { renderFloatBar(); } catch (e) {}
                try { refreshInlineMetaMode(true); } catch (e) {}
                return;
            }
            if (isInlineMetaScopeStorageKey(e.key)) {
                clearInlineMetaScopeDocCache();
                try { refreshInlineMetaMode(true); } catch (e) {}
            }
        };

        // 获取块的自定义属性
        async function getBlockCustomAttrs(blockId) {
            try {
                const result = await requestApi('/api/attr/getBlockAttrs', { id: blockId });
                if (result?.code === 0) {
                    return result.data || {};
                }
            } catch (e) {
                console.error('获取块属性失败:', e);
            }
            return {};
        }

        // 设置块的自定义属性
        async function setBlockCustomAttrs(blockId, attrs) {
            try {
                const result = await requestApi('/api/attr/setBlockAttrs', {
                    id: blockId,
                    attrs: attrs
                });
                if (result?.code === 0) {
                    const id = String(blockId || '').trim();
                    if (id) {
                        const prev = inlineMetaCache.get(id) || normalizeCustomProps();
                        setInlineMetaCache(id, normalizeCustomProps({ ...prev, ...attrs }));
                    }
                }
                return {
                    success: result?.code === 0,
                    attrs: attrs,
                };
            } catch (e) {
                console.error('设置块属性失败:', e);
                return {
                    success: false,
                    attrs: attrs,
                };
            }
        }

        function pruneQuickbarAttrHostDragSnapshots(now = Date.now()) {
            try {
                for (const [taskId, entry] of quickbarAttrHostDragSnapshots.entries()) {
                    const ts = Number(entry?.ts || 0);
                    if (!ts || now - ts > QUICKBAR_ATTR_HOST_DRAG_SNAPSHOT_TTL_MS) {
                        quickbarAttrHostDragSnapshots.delete(taskId);
                    }
                }
                if (quickbarAttrHostDragSnapshots.size <= 80) return;
                const entries = Array.from(quickbarAttrHostDragSnapshots.entries())
                    .sort((a, b) => Number(a?.[1]?.ts || 0) - Number(b?.[1]?.ts || 0));
                entries.slice(0, quickbarAttrHostDragSnapshots.size - 80).forEach(([taskId]) => {
                    quickbarAttrHostDragSnapshots.delete(taskId);
                });
            } catch (e) {}
        }

        function hasQuickbarAttrHostDragSnapshots(maxAgeMs = 0) {
            const now = Date.now();
            pruneQuickbarAttrHostDragSnapshots(now);
            const maxAge = Math.max(0, Number(maxAgeMs) || 0);
            if (!maxAge) return quickbarAttrHostDragSnapshots.size > 0;
            for (const entry of quickbarAttrHostDragSnapshots.values()) {
                const ts = Number(entry?.ts || 0);
                if (ts && now - ts <= maxAge) return true;
            }
            return false;
        }

        function hasRecentQuickbarAttrHostStructuralChange(ttlMs = 5000) {
            const ttl = Math.max(300, Number(ttlMs) || 5000);
            return quickbarAttrHostDragActive
                || hasQuickbarAttrHostDragSnapshots(Math.min(ttl, QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS))
                || (Date.now() - Number(quickbarAttrHostLastStructuralAt || 0)) < ttl;
        }

        function hasRecentQuickbarAttrHostDragChange(ttlMs = 2500) {
            const ttl = Math.max(300, Number(ttlMs) || 2500);
            return quickbarAttrHostDragActive
                || (Date.now() - Number(quickbarAttrHostLastDragAt || 0)) < ttl;
        }

        function getQuickbarAttrHostDragSnapshot(taskId, attrHostId, maxAgeMs = QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS) {
            const id = String(taskId || '').trim();
            const hostId = String(attrHostId || '').trim();
            if (!id || !hostId) return null;
            const now = Date.now();
            pruneQuickbarAttrHostDragSnapshots(now);
            const entry = quickbarAttrHostDragSnapshots.get(id);
            if (entry && typeof entry === 'object') {
                const ts = Number(entry?.ts || 0);
                const maxAge = Math.max(0, Number(maxAgeMs) || 0);
                if (maxAge && (!ts || now - ts > maxAge)) {
                    quickbarAttrHostDragSnapshots.delete(id);
                    return null;
                }
                const sourceHostId = String(entry.sourceHostId || '').trim();
                const attrs = entry.attrs && typeof entry.attrs === 'object' ? entry.attrs : null;
                if (sourceHostId && sourceHostId !== hostId && attrs) return entry;
            }
            return null;
        }

        function getQuickbarAttrHostMigrationKeys(attrs) {
            const source = attrs && typeof attrs === 'object' ? attrs : {};
            return Object.keys(source).filter((key) => {
                if (key === 'custom-task-horizon-attr-host-updated-at') return false;
                return isQuickbarAttrHostMigrationAttrKey(key);
            });
        }

        function collectQuickbarAttrHostDragSnapshotBindings(target) {
            const bindings = [];
            const seen = new Set();
            const addBlock = (blockEl) => {
                if (!(blockEl instanceof Element)) return;
                let binding = null;
                try { binding = resolveTaskBindingFromBlockEl(blockEl); } catch (e) { binding = null; }
                const taskId = String(binding?.taskId || '').trim();
                const sourceHostId = String(binding?.attrHostId || binding?.taskId || '').trim();
                if (!taskId || !sourceHostId) return;
                if (seen.has(taskId)) return;
                seen.add(taskId);
                bindings.push({ taskId, sourceHostId });
                if (taskId === sourceHostId) {
                    try {
                        const listEl = getTaskListElById(sourceHostId);
                        getQuickbarDirectTaskListItems(listEl).forEach((child) => addBlock(child));
                    } catch (e) {}
                }
            };
            const blockEl = getBlockElementFromTarget(target);
            addBlock(blockEl);
            if (blockEl instanceof Element) {
                const listEl = blockEl.matches?.('.list,[data-type="NodeList"]')
                    ? blockEl
                    : blockEl.closest?.('.list,[data-type="NodeList"]');
                if (listEl instanceof Element) addBlock(listEl);
            }
            if (!bindings.length) {
                try {
                    const roots = inlineMetaObservedRoots.length ? inlineMetaObservedRoots : getInlineMetaObserveRoots();
                    for (const root of roots) {
                        const blocks = root?.querySelectorAll?.('.li[data-node-id], [data-type="NodeListItem"][data-node-id]') || [];
                        for (let i = 0; i < blocks.length && bindings.length < 12; i += 1) {
                            if (isTaskBlockElement(blocks[i])) addBlock(blocks[i]);
                        }
                        if (bindings.length) break;
                    }
                } catch (e) {}
            }
            return bindings;
        }

        async function captureQuickbarAttrHostDragSnapshots(event) {
            if (quickbarDisposed) return;
            const now = Date.now();
            pruneQuickbarAttrHostDragSnapshots(now);
            const bindings = collectQuickbarAttrHostDragSnapshotBindings(event?.target);
            if (!bindings.length) {
                logQuickbarAttrHostMigration('snapshot-empty-target', { reason: 'dragstart' });
                return;
            }
            await Promise.all(bindings.map(async (binding) => {
                const taskId = String(binding?.taskId || '').trim();
                const sourceHostId = String(binding?.sourceHostId || '').trim();
                if (!taskId || !sourceHostId) return;
                const attrs = await getBlockCustomAttrs(sourceHostId);
                const attrKeys = getQuickbarAttrHostMigrationKeys(attrs);
                if (!attrKeys.length) {
                    logQuickbarAttrHostMigration('snapshot-empty-attrs', {
                        taskId,
                        sourceHostId,
                        reason: 'dragstart',
                    });
                    return;
                }
                const entry = {
                    taskId,
                    sourceHostId,
                    attrs: { ...attrs },
                    attrKeys,
                    ts: now,
                };
                quickbarAttrHostDragSnapshots.set(taskId, entry);
                logQuickbarAttrHostMigration('snapshot-captured', {
                    taskId,
                    sourceHostId,
                    reason: 'dragstart',
                    attrKeys,
                    status: String(readQuickbarTaskMetaAttrValue(attrs, 'customStatus', '') || '').trim(),
                    updatedAt: Number(attrs?.['custom-task-horizon-attr-host-updated-at'] || 0),
                });
            }));
        }

        const __tmQBOnAttrHostDragSnapshotCapture = (event) => {
            captureQuickbarAttrHostDragSnapshots(event).catch((e) => {
                logQuickbarAttrHostMigration('snapshot-error', {
                    reason: 'dragstart',
                    error: String(e?.message || e || ''),
                });
            });
        };
        document.addEventListener('dragstart', __tmQBOnAttrHostDragSnapshotCapture, true);

        function pushQuickbarAttrHostReadLog(tag, payload = {}) {
            return null;
        }

        function pushQuickbarInlineSyncLog(tag, payload = {}) {
            return null;
        }

        function quickbarPerfNow() {
            try {
                if (typeof performance !== 'undefined' && typeof performance.now === 'function') return performance.now();
            } catch (e) {}
            return Date.now();
        }

        function pushQuickbarPerfProbe(tag, payload = {}, options = {}) {
            return null;
        }

        function describeQuickbarPerfElement(el) {
            if (!(el instanceof Element)) return null;
            const block = el.closest?.('[data-node-id]');
            const holder = el.closest?.('[data-doc-id],[data-root-id]');
            const protyle = el.closest?.('.protyle');
            const cls = typeof el.className === 'string' ? el.className.trim() : '';
            return {
                targetTag: String(el.tagName || '').toLowerCase(),
                targetClass: cls ? cls.slice(0, 120) : '',
                targetType: String(el.getAttribute?.('data-type') || ''),
                blockId: String(block?.getAttribute?.('data-node-id') || ''),
                blockType: String(block?.getAttribute?.('data-type') || ''),
                docId: String(holder?.getAttribute?.('data-doc-id') || ''),
                rootId: String(holder?.getAttribute?.('data-root-id') || ''),
                protyleFocused: !!protyle?.classList?.contains('protyle--focus'),
            };
        }

        function isQuickbarAttrHostManagedAttrKey(key) {
            const k = String(key || '').trim();
            if (!k || k === 'custom-task-horizon-attr-host-updated-at') return false;
            if (k === 'bookmark') return true;
            const managed = new Set([
                'custom-reminder',
                'custom-tomato-reminder',
                'custom-task-repeat-rule',
                'custom-task-repeat-state',
                'custom-tomato-estimate-count',
                'custom-tomato-count',
                'custom-tomato-minutes',
                'custom-tomato-time',
                getConfiguredTomatoCountAttrKey('estimate'),
                getConfiguredTomatoCountAttrKey('actual'),
                getConfiguredTomatoSpentAttrKey('minutes'),
                getConfiguredTomatoSpentAttrKey('hours'),
            ].map((item) => String(item || '').trim()).filter(Boolean));
            taskMetaAttrFieldDefs.forEach((def) => {
                getQuickbarTaskMetaAttrReadKeys(def.field).forEach((item) => {
                    const attrKey = String(item || '').trim();
                    if (attrKey) managed.add(attrKey);
                });
            });
            quickbarInlineFieldAllowSet.forEach((item) => {
                const attrKey = String(item || '').trim();
                if (attrKey && attrKey !== 'subtask-count') managed.add(attrKey);
            });
            getQuickbarCustomFieldDefs().forEach((field) => {
                const config = buildQuickbarCustomFieldConfig(field);
                const attrKey = String(config?.attrKey || '').trim();
                if (attrKey) managed.add(attrKey);
            });
            return managed.has(k);
        }

        function isQuickbarAttrHostMigrationAttrKey(key) {
            return isQuickbarAttrHostManagedAttrKey(key);
        }

        function buildQuickbarAttrHostMigrationAttrs(taskAttrs, hostAttrs = {}, options = {}) {
            const source = (taskAttrs && typeof taskAttrs === 'object') ? taskAttrs : {};
            const host = (hostAttrs && typeof hostAttrs === 'object') ? hostAttrs : {};
            const opts = (options && typeof options === 'object') ? options : {};
            const overwrite = opts.overwrite === true;
            const out = {};
            Object.keys(source).forEach((key) => {
                if (key === 'custom-task-horizon-attr-host-updated-at') return;
                if (!isQuickbarAttrHostMigrationAttrKey(key)) return;
                const value = source[key];
                if (value == null) return;
                if (!overwrite && String(value).trim() === '') return;
                if (!overwrite && String(host[key] ?? '').trim() !== '') return;
                out[key] = value;
            });
            if (!Object.keys(out).length) return {};
            out['custom-task-horizon-attr-host-updated-at'] = String(Date.now());
            return out;
        }

        function buildQuickbarAttrHostClearPlan(sourceAttrs, hostAttrs = {}, writtenAttrs = {}) {
            const source = (sourceAttrs && typeof sourceAttrs === 'object') ? sourceAttrs : {};
            const host = (hostAttrs && typeof hostAttrs === 'object') ? hostAttrs : {};
            const written = (writtenAttrs && typeof writtenAttrs === 'object') ? writtenAttrs : {};
            const out = {};
            const kept = [];
            Object.keys(source).forEach((key) => {
                if (!isQuickbarAttrHostManagedAttrKey(key)) return;
                if (key === 'custom-task-horizon-attr-host-updated-at') return;
                const sourceValue = source[key];
                if (sourceValue == null || String(sourceValue).trim() === '') return;
                const wasWritten = Object.prototype.hasOwnProperty.call(written, key);
                const hostHasKey = Object.prototype.hasOwnProperty.call(host, key);
                const hostMatchesSource = hostHasKey && String(host[key] ?? '') === String(sourceValue ?? '');
                if (!wasWritten && !hostMatchesSource) {
                    kept.push(key);
                    return;
                }
                out[key] = '';
            });
            return { attrs: out, kept };
        }

        function logQuickbarAttrHostMigration(tag, payload = {}) {
            return null;
        }

        async function runQuickbarAttrHostMigrationScan(reason = '') {
            pruneQuickbarAttrHostDragSnapshots();
            return;
            if (quickbarDisposed || quickbarAttrHostMigrationRunning) return;
            const hasDragSnapshots = hasQuickbarAttrHostDragSnapshots();
            const settleMs = hasDragSnapshots ? 280 : 1200;
            if (quickbarAttrHostDragActive || (Date.now() - Number(quickbarAttrHostLastStructuralAt || 0)) < settleMs) {
                scheduleQuickbarAttrHostMigrationScan(reason || 'wait-stable');
                return;
            }
            quickbarAttrHostMigrationRunning = true;
            let migrated = 0;
            try {
                const roots = inlineMetaObservedRoots.length ? inlineMetaObservedRoots : getInlineMetaObserveRoots();
                const seen = new Set();
                for (let ri = 0; ri < roots.length; ri += 1) {
                    const root = roots[ri];
                    const blocks = root?.querySelectorAll?.('.li[data-node-id], [data-type="NodeListItem"][data-node-id]') || [];
                    for (let i = 0; i < blocks.length && migrated < 8; i += 1) {
                        const blockEl = blocks[i];
                        if (!(blockEl instanceof Element) || !isTaskBlockElement(blockEl)) continue;
                        let binding = null;
                        try { binding = resolveTaskBindingFromBlockEl(blockEl); } catch (e) { binding = null; }
                        const taskId = String(binding?.taskId || '').trim();
                        const hostId = String(binding?.attrHostId || '').trim();
                        const explicitDragMigration = String(reason || '').includes('drag');
                        const dragSnapshot = getQuickbarAttrHostDragSnapshot(taskId, hostId);
                        const isDragMigration = explicitDragMigration || !!dragSnapshot;
                        if (explicitDragMigration && !dragSnapshot) continue;
                        const sourceId = String(
                            dragSnapshot?.sourceHostId
                            || binding?.attrHostMigrationSourceId
                            || (taskId && hostId && taskId !== hostId ? taskId : '')
                            || ''
                        ).trim();
                        if (!taskId || !hostId || !sourceId || sourceId === hostId) continue;
                        const key = `${sourceId}:${taskId}:${hostId}`;
                        if (seen.has(key)) continue;
                        seen.add(key);
                        const lastSeen = Number(quickbarAttrHostMigrationSeenAt.get(key) || 0);
                        if (lastSeen && Date.now() - lastSeen < 20000) continue;
                        const sourceAttrsPromise = dragSnapshot
                            ? Promise.resolve(dragSnapshot.attrs || {})
                            : getBlockCustomAttrs(sourceId);
                        const rows = await Promise.all([
                            sourceAttrsPromise,
                            getBlockCustomAttrs(hostId),
                        ]);
                        const shouldOverwriteHostAttrs = isDragMigration;
                        if (dragSnapshot) {
                            const hostUpdatedAtAttr = 'custom-task-horizon-attr-host-updated-at';
                            const hostUpdatedAt = Number((rows[1] || {})[hostUpdatedAtAttr] || 0);
                            const snapshotAt = Number(dragSnapshot.ts || 0);
                            if (hostUpdatedAt && snapshotAt && hostUpdatedAt > snapshotAt + 250) {
                                logQuickbarAttrHostMigration('skip-host-updated-after-snapshot', {
                                    sourceId,
                                    taskId,
                                    hostId,
                                    sourceHostId: String(dragSnapshot.sourceHostId || '').trim(),
                                    reason,
                                    hostUpdatedAt,
                                    snapshotAt,
                                    attrKeys: Array.isArray(dragSnapshot.attrKeys) ? dragSnapshot.attrKeys.slice() : getQuickbarAttrHostMigrationKeys(dragSnapshot.attrs),
                                });
                                continue;
                            }
                            logQuickbarAttrHostMigration('snapshot-use', {
                                sourceId,
                                taskId,
                                hostId,
                                sourceHostId: String(dragSnapshot.sourceHostId || '').trim(),
                                reason,
                                attrKeys: Array.isArray(dragSnapshot.attrKeys) ? dragSnapshot.attrKeys.slice() : getQuickbarAttrHostMigrationKeys(dragSnapshot.attrs),
                                hostUpdatedAt,
                                snapshotAt,
                            });
                        }
                        const attrs = buildQuickbarAttrHostMigrationAttrs(rows[0] || {}, rows[1] || {}, {
                            overwrite: shouldOverwriteHostAttrs,
                        });
                        const clearPlan = buildQuickbarAttrHostClearPlan(rows[0] || {}, rows[1] || {}, attrs);
                        const clearAttrs = clearPlan.attrs || {};
                        if (Array.isArray(clearPlan.kept) && clearPlan.kept.length) {
                            logQuickbarAttrHostMigration('conflict-keep-source', {
                                sourceId,
                                taskId,
                                hostId,
                                reason,
                                keys: clearPlan.kept.slice(),
                            });
                        }
                        if (!Object.keys(attrs).length && !Object.keys(clearAttrs).length) {
                            if (dragSnapshot) {
                                logQuickbarAttrHostMigration('snapshot-noop', {
                                    sourceId,
                                    taskId,
                                    hostId,
                                    sourceHostId: String(dragSnapshot.sourceHostId || '').trim(),
                                    reason,
                                    attrKeys: Array.isArray(dragSnapshot.attrKeys) ? dragSnapshot.attrKeys.slice() : getQuickbarAttrHostMigrationKeys(dragSnapshot.attrs),
                                });
                            }
                            continue;
                        }
                        const liveResolved = resolveQuickbarBindingForHostIds(taskId, hostId, hostId, blockEl);
                        const liveTaskId = String(liveResolved?.taskId || liveResolved?.binding?.taskId || '').trim();
                        const liveHostId = String(liveResolved?.attrHostId || liveResolved?.binding?.attrHostId || liveResolved?.binding?.taskId || '').trim();
                        if (liveHostId !== hostId) {
                            logQuickbarAttrHostMigration('skip-binding-changed', {
                                taskId,
                                hostId,
                                reason,
                                liveTaskId,
                                liveHostId,
                            });
                            continue;
                        }
                        if (liveTaskId && liveTaskId !== taskId) {
                            logQuickbarAttrHostMigration('source-task-changed', {
                                sourceId,
                                taskId,
                                hostId,
                                reason,
                                liveTaskId,
                                liveHostId,
                            });
                        }
                        let hostWriteOk = true;
                        let didWriteHost = false;
                        let clearSourceOk = true;
                        if (Object.keys(attrs).length) {
                            logQuickbarAttrHostMigration('write', { sourceId, taskId, hostId, reason, overwrite: shouldOverwriteHostAttrs, attrs: { ...attrs } });
                            const result = await setBlockCustomAttrs(hostId, attrs);
                            hostWriteOk = !!result?.success;
                            didWriteHost = hostWriteOk;
                        }
                        if (hostWriteOk && Object.keys(clearAttrs).length) {
                            logQuickbarAttrHostMigration('clear-source', { sourceId, taskId, hostId, reason, attrs: { ...clearAttrs } });
                            const clearResult = await setBlockCustomAttrs(sourceId, clearAttrs);
                            clearSourceOk = !!clearResult?.success;
                            if (!clearSourceOk) {
                                logQuickbarAttrHostMigration('clear-source-failed', { sourceId, taskId, hostId, reason });
                            }
                        }
                        if (hostWriteOk && (didWriteHost || clearSourceOk)) {
                            quickbarAttrHostMigrationSeenAt.set(key, Date.now());
                            migrated += 1;
                            logQuickbarAttrHostMigration('success', { sourceId, taskId, hostId, reason, overwrite: shouldOverwriteHostAttrs, attrs: { ...attrs }, cleared: clearSourceOk ? Object.keys(clearAttrs) : [], clearSourceOk });
                            if (dragSnapshot) {
                                const snapshotSourceHostId = String(dragSnapshot.sourceHostId || '').trim();
                                quickbarAttrHostDragSnapshots.delete(taskId);
                                if (snapshotSourceHostId) {
                                    quickbarAttrHostDragSnapshots.forEach((entry, entryTaskId) => {
                                        if (String(entry?.sourceHostId || '').trim() === snapshotSourceHostId) {
                                            quickbarAttrHostDragSnapshots.delete(entryTaskId);
                                        }
                                    });
                                }
                            }
                            try { refreshInlineMetaByTaskId(hostId, true); } catch (e) {}
                            try { if (taskId && taskId !== hostId) refreshInlineMetaByTaskId(taskId, true); } catch (e) {}
                        } else {
                            logQuickbarAttrHostMigration('error', { sourceId, taskId, hostId, reason });
                        }
                    }
                }
            } finally {
                quickbarAttrHostMigrationRunning = false;
            }
        }

        function scheduleQuickbarAttrHostMigrationScan(reason = '') {
            if (quickbarDisposed) return false;
            if (quickbarAttrHostMigrationTimer) clearTimeout(quickbarAttrHostMigrationTimer);
            const delay = quickbarAttrHostDragActive ? 700 : (hasQuickbarAttrHostDragSnapshots(QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS) ? 220 : 1500);
            quickbarAttrHostMigrationTimer = setTimeout(() => {
                quickbarAttrHostMigrationTimer = 0;
                runQuickbarAttrHostMigrationScan(reason).catch(() => null);
            }, delay);
            return true;
        }

        quickbarAttrHostMigrationScheduler = scheduleQuickbarAttrHostMigrationScan;
        try { globalThis.__taskHorizonQuickbarScheduleAttrHostMigration = scheduleQuickbarAttrHostMigrationScan; } catch (e) {}
        try { globalThis.__taskHorizonQuickbarHasRecentAttrHostStructuralChange = hasRecentQuickbarAttrHostStructuralChange; } catch (e) {}

        async function saveTaskAttrWithUndo(blockId, attrKey, value, options = {}) {
            const id = String(blockId || '').trim();
            const requestedKey = String(attrKey || '').trim();
            const key = normalizeTaskHorizonAttrKeyForSave(requestedKey);
            const displayKey = normalizeTaskHorizonAttrKeyForDisplay(requestedKey) || requestedKey;
            if (!id || !key) return { success: false, viaSharedApi: false };
            const isTomatoCountKey = requestedKey === 'custom-tomato-estimate-count'
                || requestedKey === 'custom-tomato-count'
                || key === getConfiguredTomatoCountAttrKey('estimate')
                || key === getConfiguredTomatoCountAttrKey('actual');
            const normalizedValue = isTomatoCountKey
                ? normalizeTomatoCountValue(value)
                : value;
            let saveBinding = null;
            try { saveBinding = resolveQuickbarAttrBindingFromBlockId(id); } catch (e) { saveBinding = null; }
            const apiTaskId = String(saveBinding?.taskId || resolveCurrentTaskId() || id).trim() || id;
            const attrTargetHintId = String(saveBinding?.attrHostId || id).trim() || id;
            pushTaskHorizonDebug('refresh', 'quickbar-save:start', {
                taskId: apiTaskId,
                attrHostId: attrTargetHintId,
                attrKey: key,
                displayAttrKey: displayKey,
                value: normalizedValue == null ? '' : String(normalizedValue),
                label: String(options?.label || '').trim(),
            });
            const sharedApi = getTaskHorizonSharedApi();
            if (displayKey === 'custom-status') {
                const applier = sharedApi?.applyTaskStatus;
                if (typeof applier === 'function') {
                    try {
                        const nextStatus = value == null ? '' : String(value);
                        suppressTaskHorizonMobileTopbarOpen();
                        const apiResult = await applier(apiTaskId, nextStatus, {
                            source: 'quickbar-status',
                            label: String(options?.label || '状态'),
                            refresh: false,
                            refreshCalendar: false,
                            withFilters: false,
                            broadcast: false,
                            recordUndo: true,
                            attrTargetId: attrTargetHintId,
                        });
                        const result = {
                            success: true,
                            changed: true,
                            viaSharedApi: true,
                            taskId: String(apiResult?.taskId || apiResult?.id || apiTaskId).trim() || apiTaskId,
                            requestedTaskId: String(apiResult?.requestedTaskId || apiTaskId).trim() || apiTaskId,
                            value: nextStatus,
                            patch: (apiResult?.patch && typeof apiResult.patch === 'object') ? apiResult.patch : null,
                        };
                        pushTaskHorizonDebug('refresh', 'quickbar-save:end', {
                            taskId: result.taskId,
                            requestedTaskId: result.requestedTaskId,
                            attrKey: key,
                            displayAttrKey: displayKey,
                            value: nextStatus,
                            label: String(options?.label || '状态').trim(),
                            viaSharedApi: true,
                            success: true,
                            source: 'quickbar-status',
                        });
                        try { quickbarAttrHostMigrationScheduler?.('attr-write'); } catch (e) {}
                        return result;
                    } catch (e) {}
                }
            }
            if (displayKey === 'custom-start-date' || displayKey === 'custom-completion-time') {
                const updater = globalThis.tmUpdateTaskDates;
                if (typeof updater === 'function') {
                    try {
                        suppressTaskHorizonMobileTopbarOpen();
                        const apiResult = await updater(apiTaskId, displayKey === 'custom-start-date'
                            ? { startDate: value == null ? '' : String(value) }
                            : { completionTime: value == null ? '' : String(value) }, {
                            refresh: false,
                            broadcast: false,
                            attrTargetId: attrTargetHintId,
                        });
                        const nextValue = value == null ? '' : String(value);
                        const result = {
                            success: true,
                            changed: true,
                            viaSharedApi: true,
                            taskId: String(apiResult?.taskId || apiResult?.id || apiTaskId).trim() || apiTaskId,
                            requestedTaskId: String(apiResult?.requestedTaskId || apiTaskId).trim() || apiTaskId,
                            value: nextValue,
                        };
                        pushTaskHorizonDebug('refresh', 'quickbar-save:end', {
                            taskId: result.taskId,
                            requestedTaskId: result.requestedTaskId,
                            attrKey: key,
                            displayAttrKey: displayKey,
                            value: nextValue,
                            label: String(options?.label || '').trim(),
                            viaSharedApi: true,
                            success: true,
                            source: 'quickbar-date',
                        });
                        try { quickbarAttrHostMigrationScheduler?.('attr-write'); } catch (e) {}
                        return result;
                    } catch (e) {}
                }
            }
            const genericApplier = sharedApi?.applyTaskAttrUpdateWithUndo;
            if (typeof genericApplier === 'function') {
                try {
                    const nextValue = normalizedValue == null ? '' : String(normalizedValue);
                    suppressTaskHorizonMobileTopbarOpen();
                    const apiAttrKey = displayKey || requestedKey || key;
                    const apiResult = await genericApplier(apiTaskId, apiAttrKey, nextValue, {
                        source: 'quickbar-attr',
                        label: String(options?.label || ''),
                        refresh: false,
                        refreshCalendar: false,
                        withFilters: false,
                        broadcast: false,
                        recordUndo: false,
                        attrTargetId: attrTargetHintId,
                        skipNoopCheck: options?.skipNoopCheck === true,
                    });
                    const result = {
                        success: true,
                        changed: true,
                        viaSharedApi: true,
                        taskId: String(apiResult?.taskId || apiResult?.id || apiTaskId).trim() || apiTaskId,
                        requestedTaskId: String(apiResult?.requestedTaskId || apiTaskId).trim() || apiTaskId,
                        value: nextValue,
                    };
                    pushTaskHorizonDebug('refresh', 'quickbar-save:end', {
                        taskId: result.taskId,
                        requestedTaskId: result.requestedTaskId,
                        attrKey: key,
                        displayAttrKey: apiAttrKey,
                        value: nextValue,
                        label: String(options?.label || '').trim(),
                        viaSharedApi: true,
                        success: true,
                        source: 'quickbar-attr',
                    });
                    try { quickbarAttrHostMigrationScheduler?.('attr-write'); } catch (e) {}
                    return result;
                } catch (e) {}
            }
            const fallbackAttrs = { [key]: normalizedValue };
            const result = await setBlockCustomAttrs(id, fallbackAttrs);
            const finalResult = {
                success: !!result?.success,
                changed: !!result?.success,
                viaSharedApi: false,
                taskId: apiTaskId || id,
                requestedTaskId: id,
                value: normalizedValue == null ? '' : String(normalizedValue),
            };
            pushTaskHorizonDebug('refresh', 'quickbar-save:end', {
                taskId: finalResult.taskId,
                requestedTaskId: finalResult.requestedTaskId,
                attrKey: key,
                displayAttrKey: displayKey,
                value: normalizedValue == null ? '' : String(normalizedValue),
                label: String(options?.label || '').trim(),
                viaSharedApi: false,
                success: finalResult.success === true,
                source: 'set-block-custom-attrs',
            });
            if (finalResult.success) {
                try { quickbarAttrHostMigrationScheduler?.('attr-write'); } catch (e) {}
            }
            return finalResult;
        }

        // 格式化日期（YYYY-MM-DD / ISO / 时间戳 -> YYYY-MM-DD）
        function formatDate(value) {
            if (!value) return '';
            const s = String(value || '').trim();
            if (!s) return '';
            if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;

            let d;
            if (/^\d+$/.test(s)) {
                const n = Number(s);
                d = new Date(n);
            } else {
                d = new Date(s);
            }
            if (Number.isNaN(d.getTime()) || d.getTime() === 0) return '';
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${day}`;
        }

        // 解析 YYYY-MM-DD（保持日期语义，避免时区偏移）
        function parseDate(dateStr) {
            const s = String(dateStr || '').trim();
            if (!s) return '';
            const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
            if (!m) return '';
            return `${m[1]}-${m[2]}-${m[3]}`;
        }

        function renderPhosphorBoldIcon(iconName, size = 14) {
            const name = String(iconName || '').trim().toLowerCase();
            const official = {
                flag: 'M40.14,46.88A12,12,0,0,0,36,56V224a12,12,0,0,0,24,0V181.72c22.84-17.12,42.1-9.12,70.68,5,16.23,8,34.74,17.2,54.8,17.2,14.72,0,30.28-4.94,46.38-18.88A12,12,0,0,0,236,176V56a12,12,0,0,0-19.86-9.07c-24.71,21.41-44.53,13.31-74.82-1.68C113.19,31.27,78.17,13.94,40.14,46.88ZM212,170.26c-22.84,17.13-42.1,9.11-70.68-5C118.16,153.76,90.33,140,60,153.87V61.69c22.84-17.12,42.1-9.12,70.68,5,16.23,8,34.74,17.2,54.8,17.2A63,63,0,0,0,212,78.08Z',
                sparkle: 'M199,125.31l-49.88-18.39L130.69,57a19.92,19.92,0,0,0-37.38,0L74.92,106.92,25,125.31a19.92,19.92,0,0,0,0,37.38l49.88,18.39L93.31,231a19.92,19.92,0,0,0,37.38,0l18.39-49.88L199,162.69a19.92,19.92,0,0,0,0-37.38Zm-63.38,35.16a12,12,0,0,0-7.11,7.11L112,212.28l-16.47-44.7a12,12,0,0,0-7.11-7.11L43.72,144l44.7-16.47a12,12,0,0,0,7.11-7.11L112,75.72l16.47,44.7a12,12,0,0,0,7.11,7.11L180.28,144ZM140,40a12,12,0,0,1,12-12h12V16a12,12,0,0,1,24,0V28h12a12,12,0,0,1,0,24H188V64a12,12,0,0,1-24,0V52H152A12,12,0,0,1,140,40ZM252,88a12,12,0,0,1-12,12h-4v4a12,12,0,0,1-24,0v-4h-4a12,12,0,0,1,0-24h4V72a12,12,0,0,1,24,0v4h4A12,12,0,0,1,252,88Z',
                repeat: 'M20,128A76.08,76.08,0,0,1,96,52h99l-3.52-3.51a12,12,0,1,1,17-17l24,24a12,12,0,0,1,0,17l-24,24a12,12,0,0,1-17-17L195,76H96a52.06,52.06,0,0,0-52,52,12,12,0,0,1-24,0Zm204-12a12,12,0,0,0-12,12,52.06,52.06,0,0,1-52,52H61l3.52-3.51a12,12,0,1,0-17-17l-24,24a12,12,0,0,0,0,17l24,24a12,12,0,1,0,17-17L61,204h99a76.08,76.08,0,0,0,76-76A12,12,0,0,0,224,116Z',
                'alarm-clock': 'M128,36A100,100,0,1,0,228,136,100.11,100.11,0,0,0,128,36Zm0,176a76,76,0,1,1,76-76A76.08,76.08,0,0,1,128,212ZM32.49,72.49a12,12,0,1,1-17-17l32-32a12,12,0,1,1,17,17Zm208,0a12,12,0,0,1-17,0l-32-32a12,12,0,1,1,17-17l32,32A12,12,0,0,1,240.49,72.49ZM176,124a12,12,0,0,1,0,24H128a12,12,0,0,1-12-12V88a12,12,0,0,1,24,0v36Z',
                'calendar-check': 'M208,28H188V20a12,12,0,0,0-24,0v8H92V20a12,12,0,0,0-24,0v8H48A20.02229,20.02229,0,0,0,28,48V208a20.02229,20.02229,0,0,0,20,20H208a20.02229,20.02229,0,0,0,20-20V48A20.02229,20.02229,0,0,0,208,28Zm-4,24V76H52V52ZM52,204V100H204V204Zm120.72559-84.2373a12.00022,12.00022,0,0,1-.499,16.96386l-46.6665,44a11.99953,11.99953,0,0,1-16.48486-.02051l-25.3335-24a11.99964,11.99964,0,1,1,16.50586-17.42187l17.1001,16.19922,38.415-36.21973A11.99993,11.99993,0,0,1,172.72559,119.7627Z',
                'calendar-plus-2': 'M208,28H188V24a12,12,0,0,0-24,0v4H92V24a12,12,0,0,0-24,0v4H48A20,20,0,0,0,28,48V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V48A20,20,0,0,0,208,28ZM68,52a12,12,0,0,0,24,0h72a12,12,0,0,0,24,0h16V76H52V52ZM52,204V100H204V204Zm112-52a12,12,0,0,1-12,12H140v12a12,12,0,0,1-24,0V164H104a12,12,0,0,1,0-24h12V128a12,12,0,0,1,24,0v12h12A12,12,0,0,1,164,152Z',
                'dots-three': 'M144,128a16,16,0,1,1-16-16A16,16,0,0,1,144,128ZM60,112a16,16,0,1,0,16,16A16,16,0,0,0,60,112Zm136,0a16,16,0,1,0,16,16A16,16,0,0,0,196,112Z',
                'note-pencil': 'M232.48535,55.51465l-32-32a12.00062,12.00062,0,0,0-16.9707,0l-96,96A12.002,12.002,0,0,0,84,128v32a12.00028,12.00028,0,0,0,12,12h32a11.99907,11.99907,0,0,0,8.48535-3.51465l96-96A11.99973,11.99973,0,0,0,232.48535,55.51465ZM192,48.97046,207.0293,64,196,75.0293,180.9707,60ZM123.0293,148H108V132.97046L164,76.9707,179.0293,92ZM228,128.56836V208a20.0226,20.0226,0,0,1-20,20H48a20.0226,20.0226,0,0,1-20-20V48A20.02244,20.02244,0,0,1,48,28h79.43164a12,12,0,0,1,0,24H52V204H204V128.56836a12,12,0,0,1,24,0Z',
                timer: 'M128,44a96,96,0,1,0,96,96A96.11,96.11,0,0,0,128,44Zm0,168a72,72,0,1,1,72-72A72.08,72.08,0,0,1,128,212ZM164.49,99.51a12,12,0,0,1,0,17l-28,28a12,12,0,0,1-17-17l28-28A12,12,0,0,1,164.49,99.51ZM92,16A12,12,0,0,1,104,4h48a12,12,0,0,1,0,24H104A12,12,0,0,1,92,16Z',
            }[name];
            if (official) {
                return `<svg viewBox="0 0 256 256" width="${size}" height="${size}" aria-hidden="true"><path fill="currentColor" stroke="none" d="${official}"></path></svg>`;
            }
            const body = (() => {
                switch (name) {
                    case 'flag': return '<path d="M6 21V4.5" /><path d="M6 5.5c1.4-1.2 2.8-1.75 4.25-1.75 2.5 0 4.3 1.5 6.25 1.5.75 0 1.5-.12 2.25-.5v8.5c-.75.38-1.5.5-2.25.5-1.95 0-3.75-1.5-6.25-1.5-1.45 0-2.85.55-4.25 1.75" />';
                    case 'caret-double-up': return '<path d="m6 15 6-6 6 6" /><path d="m6 20 6-6 6 6" />';
                    case 'caret-double-down': return '<path d="m6 4 6 6 6-6" /><path d="m6 10 6 6 6-6" />';
                    case 'minus': return '<path d="M6 12h12" />';
                    case 'circle-dot': return '<circle cx="12" cy="12" r="8.75" /><circle cx="12" cy="12" r="1.25" />';
                    default: return '<circle cx="12" cy="12" r="8.75" />';
                }
            })();
            return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2.45" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
        }

        function getPriorityJiraInfo(value) {
            const p = String(value || '').trim().toLowerCase();
            if (p === 'high') return { key: 'high', label: '高', iconType: 'high', color: '#de350b', bg: 'rgba(222,53,11,0.14)', border: 'rgba(222,53,11,0.34)' };
            if (p === 'medium') return { key: 'medium', label: '中', iconType: 'medium', color: '#ff991f', bg: 'rgba(255,153,31,0.14)', border: 'rgba(255,153,31,0.34)' };
            if (p === 'low') return { key: 'low', label: '低', iconType: 'low', color: '#1d7afc', bg: 'rgba(29,122,252,0.14)', border: 'rgba(29,122,252,0.32)' };
            return { key: 'none', label: '无', iconType: 'none', color: '#9e9e9e', bg: 'rgba(158,158,158,0.12)', border: 'rgba(158,158,158,0.3)' };
        }

        function getPriorityIconStyle() {
            try {
                const raw = localStorage.getItem('tm_priority_icon_style');
                const parsed = raw == null ? '' : (() => {
                    try { return JSON.parse(raw); } catch (e) { return raw; }
                })();
                return String(parsed || '').trim().toLowerCase() === 'flag' ? 'flag' : 'jira';
            } catch (e) {
                return 'jira';
            }
        }

        function getPriorityJiraIconSvg(iconType) {
            const t = String(iconType || '').trim();
            if (getPriorityIconStyle() === 'flag') {
                return renderPhosphorBoldIcon('flag', 16);
            }
            if (t === 'high') {
                return `<svg viewBox="0 0 18 18" aria-hidden="true"><polyline points="2.5,10.1 9,6.1 15.5,10.1" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
            }
            if (t === 'medium') {
                return `<svg viewBox="0 0 18 18" aria-hidden="true"><line x1="2.5" y1="6.2" x2="15.5" y2="6.2" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/><line x1="2.5" y1="11.2" x2="15.5" y2="11.2" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/></svg>`;
            }
            if (t === 'low') {
                return `<svg viewBox="0 0 18 18" aria-hidden="true"><polyline points="2.5,7.1 9,11.1 15.5,7.1" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
            }
            return `<svg viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="5.2" fill="none" stroke="currentColor" stroke-width="2.6"/></svg>`;
        }

        function buildPriorityChipStyle(value) {
            const info = getPriorityJiraInfo(value);
            return `--qb-priority-bg:${info.bg};--qb-priority-fg:${info.color};--qb-priority-border:${info.border};`;
        }

        function renderPriorityChip(value, mode) {
            const info = getPriorityJiraInfo(value);
            const isFlagStyle = getPriorityIconStyle() === 'flag';
            const cls = mode === 'option'
                ? `sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--priority${isFlagStyle ? ' is-flag-style' : ''}`
                : `sy-custom-props-floatbar__prop-value sy-custom-props-floatbar__priority-chip${isFlagStyle ? ' is-flag-style' : ''}`;
            const text = mode === 'option'
                ? `<span class="sy-custom-props-floatbar__priority-text">${info.label}</span>`
                : '';
            return `<span class="${cls}" style="${buildPriorityChipStyle(value)}"><span class="sy-custom-props-floatbar__priority-icon">${getPriorityJiraIconSvg(info.iconType)}</span>${text}</span>`;
        }

        // 获取状态选项的显示文本和颜色
        function getStatusDisplay(value) {
            const statusOptions = getStatusOptionsSnapshot();
            const resolvedValue = String(value || '').trim() || getDefaultUndoneStatusId(statusOptions);
            const option = statusOptions.find(o => o.id === resolvedValue);
            return {
                name: option ? option.name : resolvedValue,
                color: option ? option.color : '#757575'
            };
        }

        function hexToRgba(hex, alpha) {
            const s = String(hex || '').trim();
            const a = Math.max(0, Math.min(1, Number(alpha) || 0));
            const m3 = /^#([0-9a-fA-F]{3})$/.exec(s);
            const m6 = /^#([0-9a-fA-F]{6})$/.exec(s);
            if (m3) {
                const h = m3[1];
                const r = parseInt(h[0] + h[0], 16);
                const g = parseInt(h[1] + h[1], 16);
                const b = parseInt(h[2] + h[2], 16);
                return `rgba(${r}, ${g}, ${b}, ${a})`;
            }
            if (m6) {
                const h = m6[1];
                const r = parseInt(h.slice(0, 2), 16);
                const g = parseInt(h.slice(2, 4), 16);
                const b = parseInt(h.slice(4, 6), 16);
                return `rgba(${r}, ${g}, ${b}, ${a})`;
            }
            return '';
        }

        function buildStatusChipStyle(color) {
            const c = String(color || '#757575').trim() || '#757575';
            const bg = hexToRgba(c, 0.16) || 'rgba(117,117,117,0.16)';
            const border = hexToRgba(c, 0.35) || 'rgba(117,117,117,0.35)';
            return `--qb-status-bg:${bg};--qb-status-fg:${c};--qb-status-border:${border};--tm-status-bg:${bg};--tm-status-fg:${c};--tm-status-border:${border};`;
        }

        function buildTooltipAttrs(label, side = 'top') {
            const text = String(label || '').trim();
            if (!text) return '';
            return ` data-tooltip="${esc(text)}" data-side="${esc(String(side || 'top').trim() || 'top')}" aria-label="${esc(text)}"`;
        }

        function getFloatbarCoreIconName(attrKey) {
            const key = String(attrKey || '').trim();
            if (key === 'custom-start-date') return 'calendar-plus-2';
            if (key === 'custom-completion-time') return 'calendar-check';
            if (key === 'taskCompleteAt') return 'check-circle';
            if (key === 'custom-duration') return 'timer';
            if (key === 'custom-focus-summary') return 'timer';
            if (key === 'custom-tomato-estimate-count') return 'timer';
            if (key === 'custom-tomato-count') return 'timer';
            if (key === 'custom-remark') return 'note-pencil';
            return '';
        }

        async function saveRawTaskAttrWithUndo(blockId, attrKey, value, options = {}) {
            const id = String(blockId || '').trim();
            const requestedKey = String(attrKey || '').trim();
            const key = normalizeTaskHorizonAttrKeyForSave(requestedKey) || requestedKey;
            const displayKey = normalizeTaskHorizonAttrKeyForDisplay(requestedKey) || requestedKey || key;
            if (!id || !key) return { success: false, viaSharedApi: false };
            const rawValue = value == null ? '' : String(value);
            let saveBinding = null;
            try { saveBinding = resolveQuickbarAttrBindingFromBlockId(id); } catch (e) { saveBinding = null; }
            const apiTaskId = String(saveBinding?.taskId || resolveCurrentTaskId() || id).trim() || id;
            const attrTargetHintId = String(saveBinding?.attrHostId || id).trim() || id;
            const sharedApi = getTaskHorizonSharedApi();
            const genericApplier = sharedApi?.applyTaskAttrUpdateWithUndo;
            if (typeof genericApplier === 'function') {
                try {
                    suppressTaskHorizonMobileTopbarOpen();
                    const apiResult = await genericApplier(apiTaskId, displayKey, rawValue, {
                        source: 'quickbar-raw-attr',
                        label: String(options?.label || ''),
                        refresh: false,
                        silent: true,
                        attrTargetId: attrTargetHintId,
                    });
                    if (apiResult !== false) {
                        return {
                            success: true,
                            viaSharedApi: true,
                            taskId: String(apiResult?.taskId || apiResult?.id || apiTaskId).trim() || apiTaskId,
                            requestedTaskId: String(apiResult?.requestedTaskId || apiTaskId).trim() || apiTaskId,
                            value: rawValue,
                        };
                    }
                } catch (e) {}
            }
            const result = await setBlockCustomAttrs(id, { [key]: rawValue });
            return {
                success: result?.success === true,
                viaSharedApi: false,
                taskId: id,
                requestedTaskId: id,
                value: rawValue,
            };
        }

        function getFloatbarCoreDisplayValue(config, value) {
            const attrKey = String(config?.attrKey || '').trim();
            const rawValue = String(value ?? '').trim();
            if (!rawValue) return '';
            if (attrKey === 'taskCompleteAt') return formatTaskCompletedAtLikeManager(rawValue);
            if (config?.type === 'date') return formatTaskCardDateLikeManager(rawValue);
            if (attrKey === 'custom-remark') return truncateInlineValue(rawValue, 24);
            if (attrKey === 'custom-duration') return truncateInlineValue(formatQuickbarDurationDisplay(rawValue), 12);
            if (attrKey === 'custom-focus-summary') return formatFocusSummaryDisplay(currentProps);
            if (attrKey === 'custom-tomato-estimate-count' || attrKey === 'custom-tomato-count') return formatTomatoCountDisplay(rawValue);
            return truncateInlineValue(rawValue, 15);
        }

        function renderFloatbarCoreLikeProp(config, value, opts = {}) {
            const attrKey = String(config?.attrKey || '').trim();
            const rawValue = String(value ?? '').trim();
            const displayValue = String(opts.displayValue ?? getFloatbarCoreDisplayValue(config, rawValue));
            const displayHtml = opts.htmlValue === true
                ? String(opts.displayHtml ?? displayValue)
                : esc(displayValue);
            const hasValue = !!displayValue;
            const tooltipSource = attrKey === 'custom-focus-summary' ? displayValue : rawValue;
            const tooltipText = tooltipSource ? `${String(config?.name || '').trim()}: ${tooltipSource}` : (config?.name || '');
            const className = [
                'sy-custom-props-floatbar__prop',
                'sy-custom-props-floatbar__prop--core',
                hasValue ? '' : 'sy-custom-props-floatbar__prop--icon-only',
                String(opts.extraClass || '').trim()
            ].filter(Boolean).join(' ');
            const style = hasValue ? '' : 'opacity: 0.6;';
            return `
                    <span class="${className}"
                          data-attr="${esc(attrKey)}"
                          data-type="${esc(String(config?.type || ''))}"
                          data-name="${esc(String(config?.name || ''))}"
                          data-value="${esc(String(value ?? ''))}"
                          ${buildTooltipAttrs(tooltipText)}
                          style="${style}">
                        <span class="sy-custom-props-floatbar__prop-icon">${renderPhosphorBoldIcon(getFloatbarCoreIconName(attrKey), 14)}</span>${hasValue ? `<span class="sy-custom-props-floatbar__prop-value">${displayHtml}</span>` : ''}
                    </span>
                `;
        }

        function findQuickbarCustomFieldOption(config, rawValue) {
            const token = String(rawValue ?? '').trim();
            if (!token) return null;
            const options = Array.isArray(config?.options) ? config.options : [];
            return options.find((option) => String(option?.value || '').trim() === token)
                || options.find((option) => String(option?.label || '').trim() === token)
                || null;
        }

        function normalizeQuickbarCustomFieldValue(config, rawValue) {
            const isMulti = String(config?.customFieldType || '').trim() === 'multi' || String(config?.type || '').trim() === 'multi-select';
            if (isMulti) {
                let list = [];
                if (Array.isArray(rawValue)) {
                    list = rawValue;
                } else {
                    const raw = String(rawValue ?? '').trim();
                    if (!raw) return [];
                    try {
                        const parsed = JSON.parse(raw);
                        list = Array.isArray(parsed) ? parsed : (parsed == null ? [] : [parsed]);
                    } catch (e) {
                        list = raw.split(/\s*[,，、]\s*/).map((item) => String(item || '').trim()).filter(Boolean);
                    }
                }
                const out = [];
                const seen = new Set();
                list.forEach((item) => {
                    const option = findQuickbarCustomFieldOption(config, item);
                    const id = String(option?.value || item || '').trim();
                    if (!id || seen.has(id)) return;
                    seen.add(id);
                    out.push(id);
                });
                return out;
            }
            const raw = String(rawValue ?? '').trim();
            if (!raw) return '';
            const option = findQuickbarCustomFieldOption(config, raw);
            return String(option?.value || raw).trim();
        }

        function getQuickbarCustomFieldSelectedOptions(config, rawValue) {
            const normalized = normalizeQuickbarCustomFieldValue(config, rawValue);
            const values = Array.isArray(normalized)
                ? normalized
                : (String(normalized || '').trim() ? [String(normalized || '').trim()] : []);
            return values.map((value) => {
                const option = findQuickbarCustomFieldOption(config, value);
                if (option) return option;
                return { value, label: value || '未命名', color: '#9ca3af', missing: true };
            });
        }

        function serializeQuickbarCustomFieldValueForSave(config, selectedValues) {
            const values = Array.isArray(selectedValues)
                ? selectedValues
                : (String(selectedValues || '').trim() ? [String(selectedValues || '').trim()] : []);
            return values.map((value) => {
                const option = findQuickbarCustomFieldOption(config, value);
                return String(option?.label || value || '').trim();
            }).filter(Boolean).join(', ');
        }

        function renderQuickbarCustomFieldTags(config, rawValue, maxTags = 2) {
            const selected = getQuickbarCustomFieldSelectedOptions(config, rawValue);
            const max = Math.max(1, Number(maxTags) || 2);
            const shown = selected.slice(0, max);
            const chips = shown.map((option) => `
                <span class="sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--status${option?.missing ? ' is-missing' : ''}" style="${buildStatusChipStyle(option?.color || '#9ca3af')}">${esc(String(option?.label || option?.value || '').trim() || '未命名')}</span>
            `.trim()).join('');
            const remain = selected.length - shown.length;
            const remainHtml = remain > 0
                ? `<span class="sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--status" style="${buildStatusChipStyle('#9ca3af')}">+${remain}</span>`
                : '';
            return `${chips}${remainHtml}`;
        }

        function getQuickbarCustomFieldTooltip(config, rawValue) {
            const selected = getQuickbarCustomFieldSelectedOptions(config, rawValue);
            const name = String(config?.name || '').trim();
            const valueText = selected.map((option) => String(option?.label || option?.value || '').trim()).filter(Boolean).join(', ');
            return valueText ? `${name}: ${valueText}` : name;
        }

        function normalizeCustomProps(attrs) {
            const data = attrs && typeof attrs === 'object' ? attrs : {};
            const statusOptions = getStatusOptionsSnapshot();
            const defaultUndoneStatusId = getDefaultUndoneStatusId(statusOptions);
            const done = data.done === true || data.done === 'true' || data.done === '1' || data.done === 1;
            const taskCompleteAt = String(data.taskCompleteAt || data.task_complete_at || readQuickbarTaskMetaAttrValue(data, 'taskCompleteAt', '') || '').trim();
            const rawStatus = String(readQuickbarTaskMetaAttrValue(data, 'customStatus', '')).trim();
            const defaultStatusId = (done || !!taskCompleteAt) ? getDefaultDoneStatusId(statusOptions) : defaultUndoneStatusId;
            const spentSource = getQuickbarFocusSpentSourceAttrs(data);
            const tomatoEstimateAttrKey = getConfiguredTomatoCountAttrKey('estimate');
            const tomatoCountAttrKey = getConfiguredTomatoCountAttrKey('actual');
            const spentMode = getConfiguredTomatoSpentAttrMode();
            const tomatoMinutesAttrKey = getConfiguredTomatoSpentAttrKey('minutes');
            const tomatoHoursAttrKey = getConfiguredTomatoSpentAttrKey('hours');
            const spentDisplayFromAttrs = spentMode === 'hours'
                ? formatQuickbarSpentHours(parseQuickbarNumber(spentSource[tomatoHoursAttrKey] || spentSource['custom-tomato-time'] || spentSource.tomatoHours || ''))
                : formatQuickbarSpentMinutes(parseQuickbarNumber(spentSource[tomatoMinutesAttrKey] || spentSource['custom-tomato-minutes'] || spentSource.tomatoMinutes || ''));
            const providedSpentDisplay = String(data['custom-focus-spent-display'] || data.spent || '').trim();
            const spentDisplay = hasQuickbarFocusSpentSourceAttr(data) ? spentDisplayFromAttrs : providedSpentDisplay;
            const out = {
                'custom-priority': readQuickbarTaskMetaAttrValue(data, 'priority', 'none') || 'none',
                'custom-status': rawStatus || defaultStatusId,
                'custom-completion-time': readQuickbarTaskMetaAttrValue(data, 'completionTime', ''),
                'custom-start-date': readQuickbarTaskMetaAttrValue(data, 'startDate', ''),
                'custom-duration': readQuickbarTaskMetaAttrValue(data, 'duration', ''),
                'custom-tomato-estimate-count': normalizeTomatoCountValue(data['custom-tomato-estimate-count'] || data[tomatoEstimateAttrKey] || data.tomatoEstimateCount || data.tomato_estimate_count || ''),
                'custom-tomato-count': normalizeTomatoCountValue(data['custom-tomato-count'] || data[tomatoCountAttrKey] || data.tomatoCount || data.tomato_count || ''),
                'custom-focus-spent-display': spentDisplay,
                'custom-remark': readQuickbarTaskMetaAttrValue(data, 'remark', ''),
                'custom-pinned': readQuickbarTaskMetaAttrValue(data, 'pinned', ''),
                'bookmark': data['bookmark'] || '',
                done,
                taskCompleteAt
            };
            out['custom-focus-summary'] = formatFocusSummaryDisplay(out);
            mirrorQuickbarTaskMetaStableProps(out);
            getQuickbarCustomFieldDefs().forEach((field) => {
                const config = buildQuickbarCustomFieldConfig(field);
                if (!config?.attrKey) return;
                out[config.attrKey] = data[config.attrKey] || '';
            });
            return out;
        }

        function getRuntimeTaskByQuickbarId(blockId, blockEl = null) {
            const id = String(blockId || '').trim();
            const ids = [];
            const pushId = (value) => {
                const next = String(value || '').trim();
                if (next && !ids.includes(next)) ids.push(next);
            };
            pushId(id);
            try {
                const binding = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id);
                pushId(binding?.taskId);
                pushId(binding?.attrHostId);
            } catch (e) {}
            const runtime = globalThis.__tmRuntimeState || null;
            const acceptsRuntimeTask = (task) => {
                if (!(task && typeof task === 'object')) return false;
                const taskId = String(task.id || '').trim();
                const hostId = String(task.attrHostId || task.attr_host_id || '').trim();
                return (taskId && ids.includes(taskId)) || (hostId && ids.includes(hostId));
            };
            const pickDirect = (tid) => {
                if (!tid) return null;
                try {
                    return runtime?.getTaskById?.(tid, { includePending: true })
                        || runtime?.getFlatTaskById?.(tid)
                        || runtime?.getPendingTaskById?.(tid)
                        || null;
                } catch (e) {
                    return null;
                }
            };
            for (const tid of ids) {
                const task = pickDirect(tid);
                if (acceptsRuntimeTask(task)) return task;
            }
            try {
                const flat = runtime?.getFlatTasks?.() || {};
                const tasks = Object.values(flat || {});
                const matched = tasks.find(acceptsRuntimeTask);
                if (matched) return matched;
            } catch (e) {}
            return null;
        }

        function serializeQuickbarCustomFieldValueFromRuntime(config, value) {
            const normalized = normalizeQuickbarCustomFieldValue(config, value);
            if (Array.isArray(normalized)) return normalized.join(', ');
            return String(normalized || '').trim();
        }

        function isQuickbarTaskLikeDone(task) {
            if (!(task && typeof task === 'object')) return false;
            return isQuickbarPropsDone(task);
        }

        function getQuickbarDomSubtaskStats(blockEl) {
            if (!(blockEl instanceof Element)) return { total: 0, completed: 0 };
            const listItemEl = blockEl.matches?.('.li,[data-type="NodeListItem"]')
                ? blockEl
                : blockEl.closest?.('.li,[data-type="NodeListItem"]');
            if (!(listItemEl instanceof Element)) return { total: 0, completed: 0 };
            const listEls = Array.from(listItemEl.children || []).filter((child) => {
                if (!(child instanceof Element)) return false;
                return child.matches?.('.list,[data-type="NodeList"]');
            });
            let total = 0;
            let completed = 0;
            listEls.forEach((listEl) => {
                const taskItems = Array.from(listEl.children || []).filter((child) => {
                    if (!(child instanceof Element)) return false;
                    return child.matches?.('.li[data-type="NodeListItem"],[data-type="NodeListItem"]');
                }).filter((child) => isTaskBlockElement(child));
                total += taskItems.length;
                completed += taskItems.filter((child) => {
                    if (child.classList?.contains('protyle-task--done')) return true;
                    const marker = String(child.getAttribute?.('data-marker') || '').trim();
                    return marker.includes('[x]') || marker.includes('[X]');
                }).length;
            });
            if (completed > total) completed = total;
            return { total, completed };
        }

        function resolveTaskCompleteAtFromTaskLike(task) {
            if (!(task && typeof task === 'object') || !isQuickbarTaskLikeDone(task)) return '';
            return String(
                task.taskCompleteAt
                || task.task_complete_at
                || readQuickbarTaskMetaAttrValue(task, 'taskCompleteAt', '')
                || task['custom-task-complete-at']
                || task.completedAt
                || task.updated
                || task.updatedAt
                || task.updateTime
                || task.update_time
                || task.completionTime
                || task.completion_time
                || ''
            ).trim();
        }

        function getRuntimeTaskCustomProps(blockId, blockEl = null) {
            const task = getRuntimeTaskByQuickbarId(blockId, blockEl);
            if (!(task && typeof task === 'object')) return null;
            const minutesKey = getConfiguredTomatoSpentAttrKey('minutes');
            const hoursKey = getConfiguredTomatoSpentAttrKey('hours');
            const runtimePropsData = {
                'custom-priority': String(task.priority || task.custom_priority || readQuickbarTaskMetaAttrValue(task, 'priority', '') || 'none').trim() || 'none',
                'custom-status': String(task.customStatus || task.custom_status || readQuickbarTaskMetaAttrValue(task, 'customStatus', '') || '').trim(),
                'custom-completion-time': String(task.completionTime || task.completion_time || readQuickbarTaskMetaAttrValue(task, 'completionTime', '') || '').trim(),
                'custom-start-date': String(task.startDate || task.start_date || readQuickbarTaskMetaAttrValue(task, 'startDate', '') || '').trim(),
                'custom-duration': String(task.duration || task.custom_duration || readQuickbarTaskMetaAttrValue(task, 'duration', '') || '').trim(),
                'custom-tomato-estimate-count': String(task.tomatoEstimateCount || task.tomato_estimate_count || task.tomatoEstimate || '').trim(),
                'custom-tomato-count': String(task.tomatoCount || task.tomato_count || '').trim(),
                'custom-remark': String(task.remark || task.custom_remark || readQuickbarTaskMetaAttrValue(task, 'remark', '') || '').trim(),
                'custom-pinned': String(task.pinned || task.custom_pinned || readQuickbarTaskMetaAttrValue(task, 'pinned', '') || '').trim(),
                done: isQuickbarTaskLikeDone(task),
                taskCompleteAt: resolveTaskCompleteAtFromTaskLike(task),
                'bookmark': String(task.bookmark || '').trim()
            };
            const runtimeTomatoMinutes = String(task.tomatoMinutes || task.tomato_minutes || task[minutesKey] || task['custom-tomato-minutes'] || '').trim();
            const runtimeTomatoHours = String(task.tomatoHours || task.tomato_hours || task[hoursKey] || task['custom-tomato-time'] || '').trim();
            if (runtimeTomatoMinutes) runtimePropsData.tomatoMinutes = runtimeTomatoMinutes;
            if (runtimeTomatoHours) runtimePropsData.tomatoHours = runtimeTomatoHours;
            const props = normalizeCustomProps(runtimePropsData);
            const customValues = (task.customFieldValues && typeof task.customFieldValues === 'object' && !Array.isArray(task.customFieldValues))
                ? task.customFieldValues
                : {};
            getQuickbarCustomFieldDefs().forEach((field) => {
                const config = buildQuickbarCustomFieldConfig(field);
                const fieldId = String(field?.id || config?.customFieldId || '').trim();
                if (!config?.attrKey || !fieldId) return;
                if (!Object.prototype.hasOwnProperty.call(customValues, fieldId)) return;
                props[config.attrKey] = serializeQuickbarCustomFieldValueFromRuntime(config, customValues[fieldId]);
            });
            return {
                props,
                taskId: String(task.id || '').trim(),
                attrHostId: String(task.attrHostId || task.attr_host_id || '').trim()
            };
        }

        function shouldUseQuickbarRuntimePropsForBinding(runtimeProps, binding) {
            if (!(runtimeProps && typeof runtimeProps === 'object')) return false;
            const runtimeTaskId = String(runtimeProps.taskId || '').trim();
            const bindingTaskId = String(binding?.taskId || '').trim();
            if (runtimeTaskId && bindingTaskId && runtimeTaskId === bindingTaskId) return true;
            const runtimeHostId = String(runtimeProps.attrHostId || '').trim();
            const bindingHostId = String(binding?.attrHostId || binding?.taskId || '').trim();
            return !(runtimeHostId && bindingHostId && runtimeHostId !== bindingHostId);
        }

        async function getTaskHorizonBridgeCustomProps(blockId, options = {}) {
            const id = String(blockId || '').trim();
            if (!id) return null;
            const bridge = getTaskHorizonSharedApi()?.quickbarBridge;
            const getter = bridge?.getTaskCustomPropsByAnyId;
            if (typeof getter !== 'function') return null;
            try {
                const result = await getter(id, {
                    forceFresh: options?.forceFresh === true,
                });
                const props = result?.props && typeof result.props === 'object'
                    ? normalizeCustomProps(result.props)
                    : null;
                if (!props) return null;
                return {
                    props,
                    taskId: String(result?.taskId || id).trim() || id,
                    attrHostId: String(result?.attrHostId || result?.taskId || id).trim() || id,
                };
            } catch (e) {
                return null;
            }
        }

        function resolveQuickbarAttrBindingFromBlockId(blockId) {
            const id = String(blockId || '').trim();
            if (!id) return { taskId: '', attrHostId: '' };
            const readDirectId = (el) => String(el?.dataset?.nodeId || el?.getAttribute?.('data-node-id') || '').trim();
            const normalizeBinding = (binding) => {
                const taskId = String(binding?.taskId || '').trim();
                const attrHostId = String(binding?.attrHostId || binding?.taskId || '').trim();
                if (!taskId && !attrHostId) return null;
                return {
                    taskId: taskId || attrHostId,
                    attrHostId: attrHostId || taskId
                };
            };
            const resolveFromEl = (el, requireMatch = false) => {
                if (!el) return null;
                let binding = null;
                try { binding = resolveTaskBindingFromBlockEl(el); } catch (e) { binding = null; }
                const normalized = normalizeBinding(binding);
                if (!normalized) return null;
                if (!requireMatch) return normalized;
                const directId = readDirectId(el);
                if (id === directId || id === normalized.taskId || id === normalized.attrHostId) return normalized;
                return null;
            };
            const currentBinding = resolveFromEl(currentBlockEl, true);
            if (currentBinding) return currentBinding;
            const blockBinding = resolveFromEl(getBlockElById(id), true);
            if (blockBinding) return blockBinding;
            return { taskId: id, attrHostId: id };
        }

        function scheduleQuickbarState3ParentMirrorSync(binding, primaryAttrs, parentAttrs) {
            const info = (binding && typeof binding === 'object') ? binding : null;
            const taskId = String(info?.taskId || '').trim();
            const primaryId = String(info?.attrHostId || taskId).trim();
            const parentId = String(info?.parentListId || '').trim();
            const state = String(info?.attrHostState || '').trim();
            if (!info || state !== 'state3-list-item' || !taskId || !parentId || primaryId !== taskId || parentId === taskId) return;
            const source = (primaryAttrs && typeof primaryAttrs === 'object') ? primaryAttrs : {};
            const mirror = (parentAttrs && typeof parentAttrs === 'object') ? parentAttrs : {};
            const hasManagedValue = (attrs) => Object.entries(attrs || {}).some(([attrKey, value]) => {
                const key = String(attrKey || '').trim();
                if (!key || key === 'custom-task-horizon-attr-host-updated-at' || key === 'custom-task-horizon-attr-host-owner') return false;
                return isQuickbarAttrHostManagedAttrKey(key) && String(value ?? '').trim() !== '';
            });
            const owner = String(mirror?.['custom-task-horizon-attr-host-owner'] || '').trim();
            const sourceHasManagedValues = hasManagedValue(source);
            if (owner === taskId && !sourceHasManagedValues) return;
            if (!owner && !sourceHasManagedValues) return;
            const keys = new Set(Object.keys(mirror).concat(Object.keys(source)));
            const patch = {};
            keys.forEach((attrKey) => {
                const key = String(attrKey || '').trim();
                if (!key || key === 'custom-task-horizon-attr-host-updated-at' || key === 'custom-task-horizon-attr-host-owner') return;
                if (!isQuickbarAttrHostManagedAttrKey(key)) return;
                const nextValue = Object.prototype.hasOwnProperty.call(source, key) ? String(source[key] ?? '') : '';
                const prevValue = Object.prototype.hasOwnProperty.call(mirror, key) ? String(mirror[key] ?? '') : '';
                if (prevValue !== nextValue) patch[key] = nextValue;
            });
            if (!Object.keys(patch).length && owner === taskId) return;
            const now = Date.now();
            const syncKey = `${taskId}:${parentId}`;
            const last = Number(quickbarAttrHostMirrorSyncSeenAt.get(syncKey) || 0);
            if (last && now - last < 3000) return;
            patch['custom-task-horizon-attr-host-updated-at'] = String(now);
            patch['custom-task-horizon-attr-host-owner'] = taskId;
            quickbarAttrHostMirrorSyncSeenAt.set(syncKey, now);
            setBlockCustomAttrs(parentId, patch).catch(() => null);
        }

        async function getMergedTaskCustomAttrs(blockId, options = {}) {
            const id = String(blockId || '').trim();
            if (!id) return {};
            const opts = (options && typeof options === 'object') ? options : {};
            let binding = null;
            if (opts.blockEl instanceof Element) {
                try { binding = resolveTaskBindingFromBlockEl(opts.blockEl); } catch (e) { binding = null; }
            }
            if (!binding) binding = resolveQuickbarAttrBindingFromBlockId(id);
            const taskId = String(binding?.taskId || id).trim() || id;
            const attrHostId = String(binding?.attrHostId || taskId || id).trim() || taskId || id;
            const hostAttrs = await getBlockCustomAttrs(attrHostId || taskId || id);
            const attrs = {};
            const mirrorIds = [];
            const state = String(binding?.attrHostState || '').trim();
            if (state === 'state1-parent' && taskId && taskId !== attrHostId) mirrorIds.push(taskId);
            if (state === 'state3-list-item' && binding?.parentListId && String(binding.parentListId).trim() !== attrHostId) mirrorIds.push(String(binding.parentListId).trim());
            const hostHasManagedValues = Object.entries(hostAttrs || {}).some(([hostKey, hostValue]) => {
                if (!isQuickbarAttrHostManagedAttrKey(hostKey)) return false;
                return String(hostValue ?? '').trim() !== '';
            });
            const backfillAttrs = {};
            let state1MirrorAttrs = null;
            let ignoreHostAttrsForDisplay = false;
            for (const mirrorId of Array.from(new Set(mirrorIds.filter(Boolean)))) {
                const mirrorAttrs = await getBlockCustomAttrs(mirrorId);
                if (state === 'state1-parent' && mirrorId === taskId) state1MirrorAttrs = mirrorAttrs || {};
                if (state === 'state3-list-item' && mirrorId !== taskId) {
                    scheduleQuickbarState3ParentMirrorSync(binding, hostAttrs, mirrorAttrs);
                    continue;
                }
                const owner = String(mirrorAttrs?.['custom-task-horizon-attr-host-owner'] || '').trim();
                if (mirrorId !== taskId && (owner !== taskId)) continue;
                Object.entries(mirrorAttrs || {}).forEach(([mirrorKey, mirrorValue]) => {
                    if (mirrorKey === 'custom-task-horizon-attr-host-updated-at' || mirrorKey === 'custom-task-horizon-attr-host-owner') return;
                    if (!isQuickbarAttrHostManagedAttrKey(mirrorKey)) return;
                    if (String(mirrorValue ?? '').trim() === '') return;
                    attrs[mirrorKey] = mirrorValue;
                    if (state === 'state1-parent' && mirrorId === taskId) backfillAttrs[mirrorKey] = String(mirrorValue ?? '');
                });
            }
            if (state === 'state1-parent') {
                const hostOwner = String(hostAttrs?.['custom-task-horizon-attr-host-owner'] || '').trim();
                if (hostOwner && hostOwner !== taskId) {
                    ignoreHostAttrsForDisplay = true;
                    attrs.__tmQuickbarHasAttrHostStatus = true;
                    attrs.__tmQuickbarSkipStatusSnapshot = true;
                    const source = (state1MirrorAttrs && typeof state1MirrorAttrs === 'object') ? state1MirrorAttrs : {};
                    const patch = {};
                    const keys = new Set(Object.keys(hostAttrs || {}).concat(Object.keys(source)));
                    keys.forEach((attrKey) => {
                        const key = String(attrKey || '').trim();
                        if (!key || key === 'custom-task-horizon-attr-host-updated-at' || key === 'custom-task-horizon-attr-host-owner') return;
                        if (!isQuickbarAttrHostManagedAttrKey(key)) return;
                        const nextValue = Object.prototype.hasOwnProperty.call(source, key) ? String(source[key] ?? '') : '';
                        const prevValue = Object.prototype.hasOwnProperty.call(hostAttrs || {}, key) ? String(hostAttrs[key] ?? '') : '';
                        attrs[key] = nextValue;
                        if (prevValue !== nextValue) patch[key] = nextValue;
                    });
                    if (!Object.prototype.hasOwnProperty.call(attrs, 'custom-status')) attrs['custom-status'] = '';
                    if (Object.keys(patch).length) {
                        patch['custom-task-horizon-attr-host-updated-at'] = String(Date.now());
                        patch['custom-task-horizon-attr-host-owner'] = taskId;
                        setBlockCustomAttrs(attrHostId, patch).catch(() => null);
                    }
                } else if (!hostHasManagedValues && Object.keys(backfillAttrs).length) {
                const patch = {
                    ...backfillAttrs,
                    'custom-task-horizon-attr-host-updated-at': String(Date.now()),
                    'custom-task-horizon-attr-host-owner': taskId,
                };
                setBlockCustomAttrs(attrHostId, patch).catch(() => null);
                }
            }
            if (!ignoreHostAttrsForDisplay) Object.assign(attrs, (hostAttrs && typeof hostAttrs === 'object') ? hostAttrs : {});
            const hostStatus = readQuickbarTaskMetaAttrValue(attrs, 'customStatus', '').trim();
            if (hostStatus) attrs.__tmQuickbarHasAttrHostStatus = true;
            if (Object.keys(attrs).some((key) => isQuickbarAttrHostManagedAttrKey(key) && String(attrs[key] ?? '').trim() !== '')) {
                attrs.__tmQuickbarHasManagedAttrHostAttrs = true;
            }
            return attrs;
        }

        function isReminderRelatedAttrKey(attrKey) {
            const key = String(attrKey || '').trim();
            return !key
                || key === 'bookmark'
                || key === 'custom-reminder'
                || key === 'custom-tomato-reminder'
                || key === 'custom-start-date'
                || key === 'custom-completion-time'
                || key === 'custom-duration'
                || key === 'custom-focus-summary'
                || key === 'custom-tomato-estimate-count'
                || key === 'custom-tomato-count'
                || isQuickbarTomatoSpentAttrKey(key)
                || key === 'custom-task-repeat-rule'
                || key === 'custom-task-repeat-state'
                || key.startsWith('custom-tm-');
        }

        async function refreshCurrentReminderSnapshot(force = false) {
            const getter = globalThis?.['siyuan-plugin-task-horizon']?.getTaskReminderSnapshotByAnyId;
            const lookupId = String(currentBlockId || resolveCurrentTaskId() || '').trim();
            const token = ++currentReminderRefreshToken;
            if (!lookupId || typeof getter !== 'function') {
                if (token === currentReminderRefreshToken) currentReminderSnapshot = null;
                return null;
            }
            try {
                const snapshot = await getter(lookupId, { force: !!force });
                if (token !== currentReminderRefreshToken) return currentReminderSnapshot;
                currentReminderSnapshot = snapshot && typeof snapshot === 'object' ? snapshot : null;
                return currentReminderSnapshot;
            } catch (e) {
                if (token === currentReminderRefreshToken) currentReminderSnapshot = null;
                return null;
            }
        }

        function scheduleCurrentReminderSnapshotRefresh(force = false) {
            const expectedBlockId = String(currentBlockId || '').trim();
            const expectedTaskId = String(resolveCurrentTaskId() || '').trim();
            const plan = [180, 760, 1800, 3600];
            plan.forEach((delay) => {
                try {
                    setTimeout(async () => {
                        if (!floatBar || floatBar.style.display === 'none') return;
                        const liveBlockId = String(currentBlockId || '').trim();
                        const liveTaskId = String(resolveCurrentTaskId() || '').trim();
                        if (expectedBlockId && liveBlockId && liveBlockId !== expectedBlockId) return;
                        if (expectedTaskId && liveTaskId && liveTaskId !== expectedTaskId) return;
                        await refreshCurrentReminderSnapshot(force);
                        if (!floatBar || floatBar.style.display === 'none') return;
                        renderFloatBar();
                        updatePosition();
                    }, delay);
                } catch (e) {}
            });
        }

        function getInlineFieldConfig(attrKey) {
            const key = String(attrKey || '').trim();
            const customConfigByToken = getQuickbarCustomFieldConfigByToken(key);
            if (customConfigByToken) return customConfigByToken;
            const customConfigByAttr = getQuickbarCustomFieldConfigByAttrKey(key);
            if (customConfigByAttr) return customConfigByAttr;
            const inlineConfig = quickbarInlineFieldDefs.find(item => item.attrKey === key);
            if (!inlineConfig) return null;
            const floatbarConfig = [...customPropsConfig.firstRow, ...customPropsConfig.secondRow]
                .find(item => String(item?.attrKey || '').trim() === key);
            if (!floatbarConfig) return { ...inlineConfig };
            return { ...floatbarConfig, ...inlineConfig, options: Array.isArray(floatbarConfig.options) ? floatbarConfig.options : inlineConfig.options };
        }

        function truncateInlineValue(value, max = 16) {
            const text = String(value || '').trim();
            if (!text) return '';
            return text.length > max ? `${text.slice(0, max)}...` : text;
        }

        function formatTaskTimeLikeManager(value) {
            const s = String(value || '').trim();
            if (!s) return '';
            try {
                const bridgeFormatter = getTaskHorizonSharedApi()?.quickbarBridge?.formatTaskTime;
                if (typeof bridgeFormatter === 'function') {
                    const text = String(bridgeFormatter(s) || '').trim();
                    if (text) return text;
                }
            } catch (e) {}
            if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
            if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s)) return s.slice(0, 10);
            if (/^\d{14}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
            if (/^\d{8}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
            if (/^\d+$/.test(s)) {
                const n = Number(s);
                if (Number.isFinite(n) && n > 0) {
                    const ts = n < 1e12 ? n * 1000 : n;
                    const d = new Date(ts);
                    if (!Number.isNaN(d.getTime())) {
                        const pad = (v) => String(v).padStart(2, '0');
                        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
                    }
                }
            }
            return formatDate(s);
        }

        function formatTaskCardDateLikeManager(value) {
            const full = formatTaskTimeLikeManager(value);
            if (!/^\d{4}-\d{2}-\d{2}$/.test(full)) return full;
            const year = Number(full.slice(0, 4));
            return year === new Date().getFullYear()
                ? `${Number(full.slice(5, 7))}月${Number(full.slice(8, 10))}日`
                : full;
        }

        function formatTaskCompletedAtLikeManager(value) {
            const s = String(value || '').trim();
            if (!s) return '';
            try {
                const formatter = getTaskHorizonSharedApi()?.quickbarBridge?.formatTaskCompletedAtTime;
                if (typeof formatter === 'function') {
                    const text = String(formatter(s) || '').trim();
                    if (text) return text;
                }
            } catch (e) {}
            if (/^\d{4}-\d{2}-\d{2}(?:[T\s]\d{2}:\d{2})?/.test(s)) {
                return /(?:T|\s)\d{2}:\d{2}/.test(s) ? s.slice(0, 16).replace('T', ' ') : s.slice(0, 10);
            }
            if (/^\d{14}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)} ${s.slice(8, 10)}:${s.slice(10, 12)}`;
            return formatTaskTimeLikeManager(s);
        }

        function renderInlineMetaField(config, value, blockEl = null, props = null) {
            if (!config) return '';
            const sourceProps = props && typeof props === 'object' ? props : currentProps;
            const attrKey = String(config.attrKey || '').trim();
            const escapedAttr = attrKey.replace(/"/g, '&quot;');
            const escapedName = String(config.name || '').replace(/"/g, '&quot;');
            const rawValue = String(value ?? '');
            const escapedValue = rawValue.replace(/"/g, '&quot;');
            if (config.customFieldId) {
                const selected = getQuickbarCustomFieldSelectedOptions(config, rawValue);
                if (!selected.length) return '';
                const normalizedValue = Array.isArray(normalizeQuickbarCustomFieldValue(config, rawValue))
                    ? normalizeQuickbarCustomFieldValue(config, rawValue).join(', ')
                    : String(normalizeQuickbarCustomFieldValue(config, rawValue) || '').trim();
                const escapedCustomValue = esc(String(normalizedValue || '')).replace(/"/g, '&quot;');
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--custom-field" data-inline-attr="${escapedAttr}" data-inline-type="${esc(String(config.type || 'select')).replace(/"/g, '&quot;')}" data-inline-name="${escapedName}" data-inline-value="${escapedCustomValue}" title="${escapedName}">
                        <span class="sy-custom-props-floatbar__custom-tags">${renderQuickbarCustomFieldTags(config, rawValue, 2)}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'custom-status') {
                const effectiveValue = rawValue || getDefaultUndoneStatusId();
                const statusInfo = getStatusDisplay(effectiveValue);
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--status" data-inline-attr="${escapedAttr}" data-inline-type="select" data-inline-name="${escapedName}" data-inline-value="${esc(String(effectiveValue)).replace(/"/g, '&quot;')}" title="${escapedName}">
                        <span class="sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--status" style="${buildStatusChipStyle(statusInfo.color)}">${statusInfo.name}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'custom-priority') {
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--priority" data-inline-attr="${escapedAttr}" data-inline-type="select" data-inline-name="${escapedName}" data-inline-value="${escapedValue}" title="${escapedName}">
                        ${renderPriorityChip(rawValue || 'none', 'prop')}
                    </span>
                `.trim();
            }
            if (attrKey === 'custom-completion-time') {
                const timeText = formatTaskCardDateLikeManager(rawValue);
                if (!timeText) return '';
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--time" data-inline-attr="${escapedAttr}" data-inline-type="${config.type}" data-inline-name="${escapedName}" data-inline-value="${escapedValue}" title="${escapedName}">
                        <span class="sy-custom-props-inline-chip-value">${esc(timeText)}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'taskCompleteAt') {
                const timeText = formatTaskCompletedAtLikeManager(rawValue);
                if (!timeText) return '';
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--time sy-custom-props-inline-chip--completed-time" data-inline-attr="${escapedAttr}" data-inline-type="${config.type}" data-inline-name="${escapedName}" data-inline-value="${escapedValue}" title="${escapedName}">
                        <span class="sy-custom-props-inline-chip-value">${esc(timeText)}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'subtask-count') {
                const stats = getQuickbarDomSubtaskStats(blockEl);
                if (stats.total <= 0) return '';
                const cfg = getQuickbarInlineSettings();
                const remaining = Math.max(0, stats.total - stats.completed);
                const displayValue = cfg.subtaskCountUnfinishedOnly ? String(remaining) : `${stats.completed}/${stats.total}`;
                const escapedDisplayValue = esc(displayValue).replace(/"/g, '&quot;');
                const escapedTitle = esc(`子任务数量：共${stats.total}个，已完成${stats.completed}个，未完成${remaining}个`).replace(/"/g, '&quot;');
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--subtask-count" data-inline-attr="${escapedAttr}" data-inline-type="readonly" data-inline-name="${escapedName}" data-inline-value="${escapedDisplayValue}" title="${escapedTitle}">
                        <span class="sy-custom-props-inline-chip-value">${esc(displayValue)}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'custom-focus-summary') {
                const displayValue = rawValue;
                if (!displayValue) return '';
                const escapedDisplayValue = esc(displayValue).replace(/"/g, '&quot;');
                const displayHtml = formatFocusSummaryDisplayHtml(sourceProps);
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--focus-summary" data-inline-attr="${escapedAttr}" data-inline-type="${config.type}" data-inline-name="${escapedName}" data-inline-value="${escapedDisplayValue}" title="${escapedName}">
                        <span class="sy-custom-props-inline-chip-value">${displayHtml || esc(displayValue)}</span>
                    </span>
                `.trim();
            }
            if (attrKey === 'custom-tomato-estimate-count' || attrKey === 'custom-tomato-count') {
                const displayValue = formatTomatoCountDisplay(rawValue);
                if (!displayValue) return '';
                const displayHtml = attrKey === 'custom-tomato-count'
                    ? formatActualTomatoCountDisplayHtml(rawValue)
                    : esc(displayValue);
                return `
                    <span class="sy-custom-props-inline-chip sy-custom-props-inline-chip--tomato-count" data-inline-attr="${escapedAttr}" data-inline-type="${config.type}" data-inline-name="${escapedName}" data-inline-value="${escapedValue}" title="${escapedName}">
                        <span class="sy-custom-props-inline-chip-value">${displayHtml}</span>
                    </span>
                `.trim();
            }
            const isDate = config.type === 'date';
            const displayValue = isDate
                ? formatTaskCardDateLikeManager(rawValue)
                : truncateInlineValue(rawValue, attrKey === 'custom-remark' ? 24 : 10);
            if (!displayValue) return '';
            return `
                <span class="sy-custom-props-inline-chip ${attrKey === 'custom-remark' ? 'sy-custom-props-inline-chip--remark' : ''}" data-inline-attr="${escapedAttr}" data-inline-type="${config.type}" data-inline-name="${escapedName}" data-inline-value="${escapedValue}" title="${escapedName}">
                    <span class="sy-custom-props-inline-chip-value">${esc(displayValue)}</span>
                </span>
            `.trim();
        }

        async function getTaskCustomProps(blockId, forceRefresh = false, options = {}) {
            const perfStartTs = quickbarPerfNow();
            const opts = (options && typeof options === 'object') ? options : {};
            const id = String(blockId || '').trim();
            if (!id) return normalizeCustomProps();
            const bypassCacheForAttrHostChange = quickbarAttrHostDragActive
                || hasRecentQuickbarAttrHostDragChange(2500)
                || hasQuickbarAttrHostDragSnapshots(QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS);
            if (!forceRefresh && !bypassCacheForAttrHostChange && !opts.includeRemark && !opts.skipAttrFallback && inlineMetaCache.has(id)) {
                const cached = inlineMetaCache.get(id);
                return cached;
            }
            const blockEl = opts.blockEl instanceof Element ? opts.blockEl : getBlockElById(id);
            const shouldUseTaskHorizonBridge = opts.forceFresh === true || forceRefresh || opts.includeRemark === true;
            let bridgeProps = shouldUseTaskHorizonBridge
                ? await getTaskHorizonBridgeCustomProps(id, { forceFresh: true })
                : null;
            let runtimeBinding = null;
            if (bridgeProps?.props) {
                try { runtimeBinding = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id); } catch (e) { runtimeBinding = null; }
                if (!shouldUseQuickbarRuntimePropsForBinding(bridgeProps, runtimeBinding)) {
                    pushQuickbarInlineSyncLog('bridge-host-conflict', {
                        taskId: id,
                        sourceTaskId: String(runtimeBinding?.taskId || '').trim(),
                        attrHostId: String(runtimeBinding?.attrHostId || '').trim(),
                        bridgeTaskId: String(bridgeProps.taskId || '').trim(),
                        bridgeAttrHostId: String(bridgeProps.attrHostId || '').trim(),
                        reason: 'getTaskCustomProps',
                    });
                    bridgeProps = null;
                }
            }
            let runtimeProps = bridgeProps ? null : getRuntimeTaskCustomProps(id, blockEl);
            if (runtimeProps?.props) {
                if (!runtimeBinding) {
                    try { runtimeBinding = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id); } catch (e) { runtimeBinding = null; }
                }
                if (!shouldUseQuickbarRuntimePropsForBinding(runtimeProps, runtimeBinding)) {
                    pushQuickbarInlineSyncLog('runtime-host-conflict', {
                        taskId: id,
                        sourceTaskId: String(runtimeBinding?.taskId || '').trim(),
                        attrHostId: String(runtimeBinding?.attrHostId || '').trim(),
                        runtimeTaskId: String(runtimeProps.taskId || '').trim(),
                        runtimeAttrHostId: String(runtimeProps.attrHostId || '').trim(),
                        reason: 'getTaskCustomProps',
                    });
                    runtimeProps = null;
                }
            }
            let props = bridgeProps?.props || runtimeProps?.props || null;
            let mergedAttrHostAttrs = false;
            if (opts.skipAttrFallback !== true) {
                let shouldMergeAttrHostAttrs = !props;
                if (!shouldMergeAttrHostAttrs) {
                    try {
                        const binding = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id);
                        const taskId = String(binding?.taskId || '').trim();
                        const attrHostId = String(binding?.attrHostId || '').trim();
                        shouldMergeAttrHostAttrs = !!(taskId && attrHostId && taskId !== attrHostId);
                    } catch (e) {
                        shouldMergeAttrHostAttrs = false;
                    }
                }
                if (shouldMergeAttrHostAttrs) {
                    const attrs = await getMergedTaskCustomAttrs(id, { blockEl });
                    props = props
                        ? normalizeCustomProps({ ...props, ...attrs })
                        : normalizeCustomProps(attrs);
                    mergedAttrHostAttrs = true;
                    if (attrs?.__tmQuickbarPreferredTaskAttrs === true) {
                        props.__tmQuickbarPreferredTaskAttrs = true;
                    }
                    if (attrs?.__tmQuickbarHasAttrHostStatus === true) {
                        props.__tmQuickbarHasAttrHostStatus = true;
                    }
                    if (attrs?.__tmQuickbarHasManagedAttrHostAttrs === true) {
                        props.__tmQuickbarHasManagedAttrHostAttrs = true;
                    }
                    if (attrs?.__tmQuickbarSkipStatusSnapshot === true) {
                        props.__tmQuickbarSkipStatusSnapshot = true;
                    }
                }
            }
            if (props && opts.skipAttrFallback !== true && !mergedAttrHostAttrs
                && (forceRefresh || opts.forceFresh === true) && !String(props['custom-focus-spent-display'] || '').trim()) {
                try {
                    const attrs = await getMergedTaskCustomAttrs(id, { blockEl });
                    if (hasQuickbarFocusSpentSourceAttr(attrs)) {
                        props = normalizeCustomProps({ ...props, ...attrs });
                        if (attrs?.__tmQuickbarPreferredTaskAttrs === true) {
                            props.__tmQuickbarPreferredTaskAttrs = true;
                        }
                        if (attrs?.__tmQuickbarHasAttrHostStatus === true) {
                            props.__tmQuickbarHasAttrHostStatus = true;
                        }
                        if (attrs?.__tmQuickbarHasManagedAttrHostAttrs === true) {
                            props.__tmQuickbarHasManagedAttrHostAttrs = true;
                        }
                        if (attrs?.__tmQuickbarSkipStatusSnapshot === true) {
                            props.__tmQuickbarSkipStatusSnapshot = true;
                        }
                    }
                } catch (e) {}
            }
            if (!props) {
                props = normalizeCustomProps();
            }
            let statusBindingForSnapshot = null;
            const resolveStatusBindingForSnapshot = () => {
                if (statusBindingForSnapshot) return statusBindingForSnapshot;
                try {
                    statusBindingForSnapshot = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id);
                } catch (e) {
                    statusBindingForSnapshot = null;
                }
                return statusBindingForSnapshot;
            };
            try {
                const binding = resolveStatusBindingForSnapshot();
                const taskId = String(binding?.taskId || id).trim() || id;
                const attrHostId = String(binding?.attrHostId || taskId || id).trim() || taskId || id;
                const sourceId = String(binding?.attrHostMigrationSourceId || '').trim();
                let transitionAttrs = null;
                let transitionReason = '';
                const dragSnapshot = getQuickbarAttrHostDragSnapshot(taskId, attrHostId);
                if (dragSnapshot?.attrs && typeof dragSnapshot.attrs === 'object') {
                    transitionAttrs = dragSnapshot.attrs;
                    transitionReason = 'drag-snapshot';
                } else if (sourceId && attrHostId && sourceId !== attrHostId
                    && (hasRecentQuickbarAttrHostStructuralChange(5000) || props.__tmQuickbarHasManagedAttrHostAttrs !== true)) {
                    transitionAttrs = await getBlockCustomAttrs(sourceId);
                    transitionReason = hasRecentQuickbarAttrHostStructuralChange(5000)
                        ? 'structural-source'
                        : 'legacy-source-rescue';
                }
                if (transitionAttrs && String(binding?.attrHostState || '').trim() === 'state3-list-item') {
                    const owner = String(transitionAttrs?.['custom-task-horizon-attr-host-owner'] || '').trim();
                    if (String(sourceId || '').trim() === String(binding?.parentListId || '').trim() && owner !== taskId) {
                        transitionAttrs = null;
                        transitionReason = '';
                    }
                }
                const transitionKeys = getQuickbarAttrHostMigrationKeys(transitionAttrs || {});
                if (transitionKeys.length) {
                    const transitionStatus = String(readQuickbarTaskMetaAttrValue(transitionAttrs, 'customStatus', '') || '').trim();
                    const propsStatus = String(props['custom-status'] || readQuickbarTaskMetaAttrValue(props, 'customStatus', '') || '').trim();
                    const defaultUndoneStatus = getDefaultUndoneStatusId(getStatusOptionsSnapshot());
                    if (props.__tmQuickbarHasAttrHostStatus !== true
                        || !propsStatus
                        || (transitionStatus && propsStatus === defaultUndoneStatus)) {
                        props = normalizeCustomProps({ ...props, ...transitionAttrs });
                        if (transitionStatus) {
                            props.__tmQuickbarPreferredTaskAttrs = true;
                            props.__tmQuickbarHasAttrHostStatus = true;
                        }
                        pushQuickbarInlineSyncLog('transition-source-props', {
                            taskId,
                            attrHostId,
                            sourceId: transitionReason === 'drag-snapshot'
                                ? String(dragSnapshot?.sourceHostId || '').trim()
                                : sourceId,
                            reason: transitionReason,
                            status: transitionStatus,
                            previousStatus: propsStatus,
                            attrKeys: transitionKeys,
                        });
                    }
                }
            } catch (e) {}
            try {
                let statusSnapshotId = id;
                let statusSnapshotTaskId = '';
                try {
                    const binding = resolveStatusBindingForSnapshot();
                    statusSnapshotTaskId = String(binding?.taskId || '').trim();
                    statusSnapshotId = String(binding?.attrHostId || binding?.taskId || id).trim() || id;
                } catch (e) {}
                const statusSnapshot = await getManagedTaskStatusSnapshot(statusSnapshotId);
                if (props.__tmQuickbarSkipStatusSnapshot === true) {
                    pushQuickbarAttrHostReadLog('status-snapshot-skip', {
                        taskId: statusSnapshotTaskId || id,
                        hostId: statusSnapshotId,
                        reason: 'invalid-attr-host-owner',
                        propsStatus: String(props['custom-status'] || '').trim(),
                    });
                } else if (statusSnapshot && typeof statusSnapshot === 'object') {
                    const statusValue = String(statusSnapshot.value || '').trim();
                    if (statusValue) {
                        const snapshotDone = isQuickbarDoneStatusValue(statusValue);
                        const propsCompleteAt = String(props.taskCompleteAt || props.task_complete_at || readQuickbarTaskMetaAttrValue(props, 'taskCompleteAt', '') || '').trim();
                        const propsStatusValue = String(props['custom-status'] || '').trim();
                        const propsDone = isQuickbarPropsDone(props);
                        const hasPropsStatus = !!propsStatusValue;
                        const sameDoneState = hasPropsStatus && propsDone === snapshotDone;
                        if (props.__tmQuickbarPreferredTaskAttrs !== true
                            && props.__tmQuickbarHasAttrHostStatus !== true
                            && !sameDoneState
                            && !(propsCompleteAt && propsDone && !snapshotDone)) {
                            if (propsStatusValue !== statusValue) {
                                pushQuickbarAttrHostReadLog('status-snapshot-apply', {
                                    taskId: statusSnapshotTaskId || id,
                                    hostId: statusSnapshotId,
                                    snapshotStatus: statusValue,
                                    propsStatus: propsStatusValue,
                                    preferredTaskAttrs: props.__tmQuickbarPreferredTaskAttrs === true,
                                    hasAttrHostStatus: props.__tmQuickbarHasAttrHostStatus === true,
                                    propsCompleteAt,
                                    propsDone,
                                    snapshotDone,
                                });
                            }
                            props['custom-status'] = statusValue;
                        } else {
                            pushQuickbarAttrHostReadLog('status-snapshot-skip', {
                                taskId: statusSnapshotTaskId || id,
                                hostId: statusSnapshotId,
                                snapshotStatus: statusValue,
                                propsStatus: String(props['custom-status'] || '').trim(),
                                preferredTaskAttrs: props.__tmQuickbarPreferredTaskAttrs === true,
                                hasAttrHostStatus: props.__tmQuickbarHasAttrHostStatus === true,
                                propsCompleteAt,
                                propsDone,
                                snapshotDone,
                            });
                        }
                    }
                }
            } catch (e) {}
            try {
                const optimisticIds = [id];
                const binding = blockEl ? resolveTaskBindingFromBlockEl(blockEl) : resolveQuickbarAttrBindingFromBlockId(id);
                optimisticIds.push(binding?.taskId, binding?.attrHostId);
                props = applyInlineMetaOptimisticPatch(props, optimisticIds, 'getTaskCustomProps');
            } catch (e) {
                props = applyInlineMetaOptimisticPatch(props, [id], 'getTaskCustomProps');
            }
            setInlineMetaCache(id, props);
            const perfDuration = quickbarPerfNow() - perfStartTs;
            if (perfDuration > 40 || (bypassCacheForAttrHostChange && perfDuration > 12)) {
                pushQuickbarPerfProbe('props-read', {
                    blockId: id,
                    durationMs: Math.round(perfDuration),
                    bypassCacheForAttrHostChange,
                    forceRefresh: !!forceRefresh,
                    includeRemark: opts.includeRemark === true,
                    skipAttrFallback: opts.skipAttrFallback === true,
                    cacheSize: inlineMetaCache.size,
                }, { throttleMs: 800 });
            }
            return props;
        }

        function setInlineMetaCache(taskId, props) {
            const id = String(taskId || '').trim();
            if (!id) return;
            inlineMetaCache.set(id, props && typeof props === 'object' ? props : normalizeCustomProps());
            inlineMetaCacheTs.set(id, Date.now());
            pruneInlineMetaRuntimeCaches(false);
        }

        function deleteInlineMetaCache(taskId) {
            const id = String(taskId || '').trim();
            if (!id) return;
            inlineMetaCache.delete(id);
            inlineMetaCacheTs.delete(id);
        }

        function setInlineMetaOptimisticPatch(ids, patch, ttlMs = QUICKBAR_INLINE_OPTIMISTIC_PATCH_TTL_MS) {
            const nextPatch = (patch && typeof patch === 'object') ? patch : {};
            const keys = Object.keys(nextPatch).filter((key) => String(key || '').trim());
            if (!keys.length) return false;
            const idList = Array.from(new Set((Array.isArray(ids) ? ids : [ids])
                .map((id) => String(id || '').trim())
                .filter(Boolean)));
            if (!idList.length) return false;
            const expiresAt = Date.now() + Math.max(500, Number(ttlMs) || QUICKBAR_INLINE_OPTIMISTIC_PATCH_TTL_MS);
            idList.forEach((id) => {
                const prev = inlineMetaOptimisticPatches.get(id);
                const prevPatch = (prev?.patch && typeof prev.patch === 'object') ? prev.patch : {};
                inlineMetaOptimisticPatches.set(id, {
                    patch: { ...prevPatch, ...nextPatch },
                    expiresAt,
                });
            });
            pushQuickbarInlineSyncLog('optimistic-set', {
                ids: idList,
                patch: { ...nextPatch },
                expiresAt,
            });
            return true;
        }

        function getInlineMetaOptimisticPatch(ids) {
            const idList = Array.from(new Set((Array.isArray(ids) ? ids : [ids])
                .map((id) => String(id || '').trim())
                .filter(Boolean)));
            if (!idList.length) return null;
            const now = Date.now();
            const merged = {};
            idList.forEach((id) => {
                const entry = inlineMetaOptimisticPatches.get(id);
                if (!entry) return;
                if (Number(entry.expiresAt || 0) <= now) {
                    inlineMetaOptimisticPatches.delete(id);
                    return;
                }
                if (entry.patch && typeof entry.patch === 'object') Object.assign(merged, entry.patch);
            });
            return Object.keys(merged).length ? merged : null;
        }

        function applyInlineMetaOptimisticPatch(props, ids, reason = '') {
            const base = props && typeof props === 'object' ? props : normalizeCustomProps();
            const patch = getInlineMetaOptimisticPatch(ids);
            if (!patch) return base;
            const next = normalizeCustomProps({ ...base, ...patch });
            pushQuickbarInlineSyncLog('optimistic-apply', {
                ids: Array.from(new Set((Array.isArray(ids) ? ids : [ids]).map((id) => String(id || '').trim()).filter(Boolean))),
                reason: String(reason || '').trim(),
                patch: { ...patch },
                beforeStatus: String(base['custom-status'] || '').trim(),
                afterStatus: String(next['custom-status'] || '').trim(),
                beforeCompleteAt: String(base.taskCompleteAt || base.task_complete_at || readQuickbarTaskMetaAttrValue(base, 'taskCompleteAt', '') || '').trim(),
                afterCompleteAt: String(next.taskCompleteAt || next.task_complete_at || readQuickbarTaskMetaAttrValue(next, 'taskCompleteAt', '') || '').trim(),
            });
            return next;
        }

        function isInlineMetaCacheStale(taskId, maxAgeMs = 12000) {
            const id = String(taskId || '').trim();
            if (!id || !inlineMetaCache.has(id)) return false;
            const ts = Number(inlineMetaCacheTs.get(id) || 0);
            if (!ts) return true;
            return (Date.now() - ts) > Math.max(1000, Number(maxAgeMs) || 12000);
        }

        function patchInlineMetaCache(taskId, patch) {
            const id = String(taskId || '').trim();
            if (!id || !patch || typeof patch !== 'object') return;
            const base = inlineMetaCache.get(id) || normalizeCustomProps();
            const next = normalizeCustomProps({ ...base, ...patch });
            setInlineMetaCache(id, next);
        }

        function collectInlineMetaAttrUpdateIds(detail = {}) {
            const ids = new Set();
            const pushId = (value) => {
                const id = String(value || '').trim();
                if (id) ids.add(id);
            };
            pushId(detail.taskId);
            pushId(detail.requestedTaskId);
            pushId(detail.resolvedTaskId);
            pushId(detail.attrHostId);

            Array.from(ids).forEach((id) => {
                try {
                    const binding = resolveQuickbarAttrBindingFromBlockId(id);
                    pushId(binding?.taskId);
                    pushId(binding?.attrHostId);
                } catch (e) {}
            });

            return Array.from(ids);
        }

        function syncInlineMetaCacheFromAttrUpdate(detail = {}) {
            const attrKey = normalizeTaskHorizonAttrKeyForDisplay(detail?.attrKey);
            if (!attrKey) return false;
            const shouldTraceInlineSync = attrKey === 'custom-status' || attrKey === 'taskCompleteAt';
            if (shouldTraceInlineSync) {
                pushQuickbarInlineSyncLog('attr-update-received', {
                    rawAttrKey: String(detail?.attrKey || '').trim(),
                    attrKey,
                    value: detail?.value == null ? '' : String(detail.value),
                    taskId: String(detail?.taskId || '').trim(),
                    requestedTaskId: String(detail?.requestedTaskId || '').trim(),
                    resolvedTaskId: String(detail?.resolvedTaskId || '').trim(),
                    attrHostId: String(detail?.attrHostId || '').trim(),
                    source: String(detail?.source || '').trim(),
                });
            }
            if (isQuickbarTomatoSpentAttrKey(detail?.attrKey) || isQuickbarTomatoSpentAttrKey(attrKey)) {
                const ids = collectInlineMetaAttrUpdateIds(detail);
                if (!ids.length) return false;
                ids.forEach((id) => {
                    try { inlineMetaPropsInflight.delete(id); } catch (e) {}
                    try { inlineMetaLayoutCache.delete(id); } catch (e) {}
                    deleteInlineMetaCache(id);
                    refreshInlineMetaByTaskId(id, true);
                });
                return true;
            }
            const config = getInlineFieldConfig(attrKey);
            if (!config && !quickbarInlineFieldAllowSet.has(attrKey)) return false;
            const cacheKey = String(config?.attrKey || attrKey).trim();
            if (!cacheKey) return false;
            const value = detail?.value == null ? '' : String(detail.value);
            const ids = collectInlineMetaAttrUpdateIds(detail);
            if (!ids.length) return false;
            if (shouldTraceInlineSync) {
                setInlineMetaOptimisticPatch(ids, { [cacheKey]: value });
            }
            if (shouldTraceInlineSync) {
                pushQuickbarInlineSyncLog('attr-update-ids', {
                    rawAttrKey: String(detail?.attrKey || '').trim(),
                    attrKey,
                    cacheKey,
                    value,
                    ids,
                });
            }
            ids.forEach((id) => {
                const hadCache = inlineMetaCache.has(id);
                const before = inlineMetaCache.get(id) || null;
                const beforeStatus = String(before?.['custom-status'] || '').trim();
                const beforeCompleteAt = String(before?.taskCompleteAt || before?.task_complete_at || readQuickbarTaskMetaAttrValue(before || {}, 'taskCompleteAt', '') || '').trim();
                try { inlineMetaPropsInflight.delete(id); } catch (e) {}
                try { inlineMetaLayoutCache.delete(id); } catch (e) {}
                if (hadCache) patchInlineMetaCache(id, { [cacheKey]: value });
                else deleteInlineMetaCache(id);
                if (shouldTraceInlineSync) {
                    const after = inlineMetaCache.get(id) || null;
                    pushQuickbarInlineSyncLog('cache-patch', {
                        id,
                        hadCache,
                        cacheKey,
                        value,
                        beforeStatus,
                        afterStatus: String(after?.['custom-status'] || '').trim(),
                        beforeCompleteAt,
                        afterCompleteAt: String(after?.taskCompleteAt || after?.task_complete_at || readQuickbarTaskMetaAttrValue(after || {}, 'taskCompleteAt', '') || '').trim(),
                        forceRefresh: !hadCache,
                    });
                }
                refreshInlineMetaByTaskId(id, !hadCache);
            });
            return true;
        }

        function refreshInlineMetaByTaskId(taskId, forceRefresh = false) {
            const id = String(taskId || '').trim();
            if (!id || !isInlineMetaEnabled()) return;
            const blockEl = getBlockElById(id);
            if (!blockEl) {
                requestInlineMetaRender(!!forceRefresh);
                return;
            }
            queueInlineMetaRenderBlock(blockEl, !!forceRefresh, 420);
            requestInlineMetaRender(!!forceRefresh);
        }

        function getInlineCachedProps(blockId) {
            const id = String(blockId || '').trim();
            if (!id) return normalizeCustomProps();
            return inlineMetaCache.get(id) || normalizeCustomProps();
        }

        function ensureTaskPropsReady(blockId, forceRefresh = false, options = {}) {
            const opts = (options && typeof options === 'object') ? options : {};
            const id = String(blockId || '').trim();
            if (!id) return Promise.resolve(normalizeCustomProps());
            const shouldUseFreshManagerProps = opts.forceFresh === true || opts.includeRemark === true;
            if (!forceRefresh && !shouldUseFreshManagerProps && !opts.skipAttrFallback && inlineMetaCache.has(id)) return Promise.resolve(inlineMetaCache.get(id));
            const inflightKey = shouldUseFreshManagerProps ? `${id}:fresh` : id;
            const inflight = inlineMetaPropsInflight.get(inflightKey);
            if (inflight) return inflight;
            const p = Promise.resolve(getTaskCustomProps(id, forceRefresh, opts))
                .catch(() => normalizeCustomProps())
                .finally(() => {
                    if (inlineMetaPropsInflight.get(inflightKey) === p) inlineMetaPropsInflight.delete(inflightKey);
                });
            inlineMetaPropsInflight.set(inflightKey, p);
            return p;
        }

        function drainInlineMetaPrefetchQueue() {
            if (!inlineMetaStarted || !isInlineMetaEnabled()) {
                inlineMetaPrefetchQueue = [];
                inlineMetaPrefetchQueuedIds.clear();
                inlineMetaPrefetchActiveCount = 0;
                return;
            }
            while (inlineMetaPrefetchActiveCount < QUICKBAR_INLINE_PREFETCH_CONCURRENCY && inlineMetaPrefetchQueue.length) {
                const item = inlineMetaPrefetchQueue.shift();
                const blockId = String(item?.blockId || '').trim();
                inlineMetaPrefetchQueuedIds.delete(blockId);
                if (!blockId) continue;
                if (inlineMetaCache.has(blockId) || inlineMetaPropsInflight.has(blockId)) continue;
                inlineMetaPrefetchActiveCount += 1;
                Promise.resolve(ensureTaskPropsReady(blockId, false, { blockEl: item.blockEl || null }))
                    .catch(() => null)
                    .finally(() => {
                        inlineMetaPrefetchActiveCount = Math.max(0, inlineMetaPrefetchActiveCount - 1);
                        if (inlineMetaPrefetchQueue.length) drainInlineMetaPrefetchQueue();
                    });
            }
        }

        function prefetchInlineMetaProps(blocks, maxCount = 120) {
            const list = Array.isArray(blocks) ? blocks : [];
            let queued = 0;
            for (let i = 0; i < list.length && queued < maxCount; i += 1) {
                const blockEl = list[i];
                const blockId = String(resolveTaskAttrNodeIdForDetail(blockEl) || blockEl?.dataset?.nodeId || '').trim();
                if (!blockId) continue;
                if (inlineMetaCache.has(blockId) || inlineMetaPropsInflight.has(blockId) || inlineMetaPrefetchQueuedIds.has(blockId)) continue;
                inlineMetaPrefetchQueuedIds.add(blockId);
                inlineMetaPrefetchQueue.push({ blockId, blockEl });
                queued += 1;
                if (inlineMetaPrefetchQueue.length > QUICKBAR_INLINE_PREFETCH_QUEUE_LIMIT) {
                    const dropped = inlineMetaPrefetchQueue.shift();
                    const droppedId = String(dropped?.blockId || '').trim();
                    if (droppedId) inlineMetaPrefetchQueuedIds.delete(droppedId);
                }
            }
            drainInlineMetaPrefetchQueue();
        }

        function renderInlineMetaHtml(cfg, props, blockEl = null) {
            const settings = cfg && Array.isArray(cfg.fields) ? cfg : getQuickbarInlineSettings();
            const sourceProps = props && typeof props === 'object' ? props : normalizeCustomProps();
            return settings.fields
                .map((attrKey) => {
                    const config = getInlineFieldConfig(attrKey);
                    if (String(config?.attrKey || attrKey || '').trim() === 'taskCompleteAt') {
                        if (!shouldShowQuickbarTaskCompleteAt(sourceProps)) return '';
                    }
                    return renderInlineMetaField(config, config ? sourceProps[config.attrKey] : sourceProps[attrKey], blockEl, sourceProps);
                })
                .filter(Boolean).join('');
        }

        // 获取或更新当前块的所有自定义属性
        async function refreshBlockAttrs(blockId = currentBlockId, forceRefresh = true) {
            const id = String(blockId || currentBlockId || '').trim();
            if (!id) {
                currentProps = normalizeCustomProps();
                return currentProps;
            }
            const props = await getTaskCustomProps(id, !!forceRefresh);
            if (String(currentBlockId || '').trim() === id) currentProps = props;
            return props;
        }

        function shouldSplitRemarkIntoOwnRow(visibleSet) {
            const visible = visibleSet instanceof Set ? visibleSet : new Set();
            if (!visible.has('custom-remark')) return false;
            const remark = String(currentProps?.['custom-remark'] || '').trim();
            if (!remark) return false;
            return (window.innerWidth || 0) <= 640;
        }

        // 渲染悬浮条
        function renderFloatBar() {
            updateStatusOptionsInConfig();
            const rows = [];
            const visibleSettings = getQuickbarVisibleSettings();
            const visibleSet = new Set(visibleSettings.items);
            const shouldShowTaskCompleteAt = shouldShowQuickbarTaskCompleteAt(currentProps);
            const splitRemarkRow = shouldSplitRemarkIntoOwnRow(visibleSet);
            const mainConfigs = [
                ...customPropsConfig.firstRow,
                ...(splitRemarkRow ? [] : customPropsConfig.secondRow)
            ];
            const mainProps = mainConfigs
                .filter(config => visibleSet.has(String(config?.attrKey || '').trim()))
                .filter(config => String(config?.attrKey || '').trim() !== 'taskCompleteAt' || shouldShowTaskCompleteAt)
                .map(config => renderPropElement(config, currentProps[config.attrKey]));
            visibleSettings.items
                .map((itemKey) => getQuickbarCustomFieldConfigByToken(itemKey))
                .filter(Boolean)
                .forEach((config) => {
                    mainProps.push(renderPropElement(config, currentProps[config.attrKey]));
                });
            if (isAiFeatureEnabled() && visibleSet.has('action-ai-title')) {
                mainProps.push(`<button class="sy-custom-props-floatbar__action" data-action="ai-title"${buildTooltipAttrs('AI 优化任务名称')}><span class="qb-icon">${renderPhosphorBoldIcon('sparkle')}</span></button>`);
            }
            if (visibleSet.has('action-reminder')) {
                const hasReminder = !!(currentReminderSnapshot?.hasReminder || String(currentProps?.bookmark || '').includes('⏰'));
                const reminderText = hasReminder ? String(currentReminderSnapshot?.displayText || '').trim() : '';
                const reminderTooltip = hasReminder
                    ? (String(currentReminderSnapshot?.tooltip || '').trim() || '已添加提醒')
                    : '添加提醒';
                mainProps.push(`
                    <button class="sy-custom-props-floatbar__action ${hasReminder ? 'is-active' : ''} ${reminderText ? 'is-wide' : ''}" data-action="reminder"${buildTooltipAttrs(reminderTooltip)}>
                        <span class="qb-icon">${renderPhosphorBoldIcon('alarm-clock')}</span>${reminderText ? `<span class="sy-custom-props-floatbar__action-text">${esc(reminderText)}</span>` : ''}
                    </button>
                `.trim());
            }
            if (visibleSet.has('action-more')) {
                mainProps.push(`<button class="sy-custom-props-floatbar__action" data-action="more"${buildTooltipAttrs('更多')}><span class="qb-icon">${renderPhosphorBoldIcon('dots-three')}</span></button>`);
            }
            if (mainProps.length) {
                rows.push(`<div class="sy-custom-props-floatbar__row sy-custom-props-floatbar__row--main">${mainProps.join('')}</div>`);
            }
            if (splitRemarkRow) {
                const remarkProps = customPropsConfig.secondRow
                    .filter(config => visibleSet.has(String(config?.attrKey || '').trim()))
                    .filter(config => String(config?.attrKey || '').trim() !== 'taskCompleteAt' || shouldShowTaskCompleteAt)
                    .map(config => renderPropElement(config, currentProps[config.attrKey]))
                    .filter(Boolean);
                if (remarkProps.length) {
                    rows.push(`<div class="sy-custom-props-floatbar__row sy-custom-props-floatbar__row--remark">${remarkProps.join('')}</div>`);
                }
            }

            floatBar.innerHTML = rows.join('');

            // 绑定点击事件
            bindPropClickEvents();
        }

        // 渲染单个属性元素
        function renderPropElement(config, value) {
            const escapedName = esc(String(config.name || ''));
            const escapedValue = esc(String(value ?? ''));
            const attrKey = String(config.attrKey || '').trim();

            if (config.customFieldId) {
                const tagsHtml = renderQuickbarCustomFieldTags(config, value, 2);
                const hasValue = !!tagsHtml;
                return `
                    <span class="sy-custom-props-floatbar__prop sy-custom-props-floatbar__prop--custom-field ${hasValue ? '' : 'sy-custom-props-floatbar__prop--custom-empty'}"
                          data-attr="${esc(attrKey)}"
                          data-type="${esc(String(config.type || 'select'))}"
                          data-name="${escapedName}"
                          data-value="${escapedValue}"
                          ${buildTooltipAttrs(getQuickbarCustomFieldTooltip(config, value))}>
                        ${hasValue ? `<span class="sy-custom-props-floatbar__custom-tags">${tagsHtml}</span>` : `<span class="sy-custom-props-floatbar__prop-value">${escapedName}</span>`}
                    </span>
                `;
            }

            if (config.type === 'select') {
                if (attrKey === 'custom-priority') {
                    return `
                        <span class="sy-custom-props-floatbar__prop is-priority-prop"
                              data-attr="${esc(attrKey)}"
                              data-type="${config.type}"
                              data-name="${escapedName}"
                              data-value="${escapedValue}"
                              ${buildTooltipAttrs(config.name || '')}>
                            ${renderPriorityChip(value, 'prop')}
                        </span>
                    `;
                }

                // 状态选择器保持原样
                const statusInfo = getStatusDisplay(value);
                const displayText = statusInfo.name;
                const bgColor = `${statusInfo.color}20`;  // 带透明度
                const color = statusInfo.color;
                return `
                    <span class="sy-custom-props-floatbar__prop"
                          data-attr="${esc(attrKey)}"
                          data-type="${config.type}"
                          data-name="${escapedName}"
                          data-value="${escapedValue}"
                          ${buildTooltipAttrs(config.name || '')}
                          style="background: ${bgColor}; border-color: ${color}; color: ${color};">
                        <span class="sy-custom-props-floatbar__prop-value">${displayText}</span>
                    </span>
                `;
            } else if (config.type === 'date') {
                return renderFloatbarCoreLikeProp(config, value);
            } else if (config.type === 'completed-time') {
                return renderFloatbarCoreLikeProp(config, value);
            } else if (config.type === 'focus-summary') {
                return renderFloatbarCoreLikeProp(config, value, {
                    displayValue: formatFocusSummaryDisplay(currentProps),
                    displayHtml: formatFocusSummaryDisplayHtml(currentProps),
                    htmlValue: true,
                });
            } else if (config.type === 'tomato-count') {
                const isActualTomato = attrKey === 'custom-tomato-count';
                return renderFloatbarCoreLikeProp(config, value, isActualTomato ? {
                    displayValue: formatTomatoCountDisplay(value),
                    displayHtml: formatActualTomatoCountDisplayHtml(value),
                    htmlValue: true,
                } : {});
            } else {
                // 文本类型属性（时长、备注）
                if (attrKey === 'custom-duration') {
                    return renderFloatbarCoreLikeProp(config, value);
                }
                if (attrKey === 'custom-remark') {
                    return renderFloatbarCoreLikeProp(config, value, { extraClass: 'sy-custom-props-floatbar__prop--remark' });
                }
                const style = value ? '' : 'opacity: 0.6;';
                return `
                    <span class="sy-custom-props-floatbar__prop sy-custom-props-floatbar__prop--icon-only"
                          data-attr="${esc(attrKey)}"
                          data-type="${config.type}"
                          data-name="${escapedName}"
                          data-value="${escapedValue}"
                          ${buildTooltipAttrs(config.name || '')}
                          style="${style}">
                        <span class="sy-custom-props-floatbar__prop-icon">${renderPhosphorBoldIcon(getFloatbarCoreIconName(attrKey), 14)}</span>
                    </span>
                `;
            }
        }

        // 绑定属性点击事件
        function bindPropClickEvents() {
            floatBar.onclick = async (e) => {
                try { e.preventDefault?.(); } catch (err) {}
                try { e.stopPropagation?.(); } catch (err) {}
                const actionEl = e.target.closest('.sy-custom-props-floatbar__action');
                if (actionEl) {
                    const action = String(actionEl.dataset.action || '');
                    if (action === 'reminder') {
                        openReminderDialogForCurrentTask();
                        return;
                    }
                    if (action === 'ai-title') {
                        try {
                            if (!isAiFeatureEnabled()) {
                                showMessage('AI 功能已关闭', true, 1800);
                                return;
                            }
                            const taskIdForAi = await resolveCurrentTaskIdForAi();
                            if (!taskIdForAi) {
                                showMessage('未找到任务', true, 1800);
                                return;
                            }
                            if (typeof globalThis.tmAiOptimizeTaskName !== 'function') {
                                await ensureAiRuntimeLoaded();
                            }
                            if (typeof globalThis.tmAiOptimizeTaskName === 'function') {
                                await globalThis.tmAiOptimizeTaskName(taskIdForAi);
                            } else {
                                showMessage('AI 模块尚未加载', true, 1800);
                            }
                        } catch (err) {
                            showMessage(String(err?.message || err || 'AI 执行失败'), true, 2200);
                        }
                        return;
                    }
                    if (action === 'more') {
                        const openTaskDetail = globalThis.tmOpenTaskDetail;
                        const detailId = resolveCurrentTaskId();
                        // 确保 ID 有效
                        if (!detailId) {
                            showMessage('无法获取任务ID', true, 1800);
                            return;
                        }
                        if (typeof openTaskDetail === 'function') {
                            try {
                                // 确保传递正确的事件对象
                                const eventObj = e || (typeof event !== 'undefined' ? event : undefined);
                                const fallbackTitle = String(resolveCurrentTaskName() || '').trim();
                                const opened = await openTaskDetail(detailId, eventObj, {
                                    source: 'quickbar-detail-open',
                                    forceFresh: true,
                                    fallbackTitle,
                                    fallbackContent: fallbackTitle,
                                });
                                if (opened) {
                                    hideFloatBar();
                                    return;
                                }
                            } catch (err) {
                                console.error('打开任务详情出错:', err);
                            }
                        } else {
                            console.warn('[Quickbar] tmOpenTaskDetail函数未找到，请确保任务管理器插件已加载');
                        }
                        showMessage('打开任务详情失败', true, 1800);
                    }
                    return;
                }
                const propEl = e.target.closest('.sy-custom-props-floatbar__prop');
                if (!propEl) return;

                const attrKey = propEl.dataset.attr;
                const propType = propEl.dataset.type;
                const propName = propEl.dataset.name;
                const currentValue = propEl.dataset.value;

                // 找到对应的属性配置
                const allProps = [...customPropsConfig.firstRow, ...customPropsConfig.secondRow];
                activePropConfig = allProps.find(p => p.attrKey === attrKey) || getQuickbarCustomFieldConfigByAttrKey(attrKey);
                if (!activePropConfig) return;
                if (activePropConfig.readonly || propType === 'completed-time') return;

                // 如果是状态属性，每次打开前重新加载选项
                if (attrKey === 'custom-status') {
                    loadStatusOptions();
                }

                if (propType === 'select' || propType === 'multi-select') {
                    // 显示选择菜单
                    showSelectMenu(propEl, activePropConfig, currentValue);
                } else if (propType === 'date') {
                    // 显示日期选择器
                    showDateEditor(propEl, activePropConfig, currentValue);
                } else if (propType === 'focus-summary') {
                    showFocusSummaryEditor(propEl, activePropConfig);
                } else {
                    // 显示文本输入框
                    showTextEditor(propEl, activePropConfig, currentValue);
                }
            };
        }

        // 显示选择菜单
        function showSelectMenu(anchorEl, config, currentValue) {
            const options = config.options;
            if (!Array.isArray(options) || options.length === 0) return;
            const blockIdAtOpen = String(currentBlockId || '').trim();
            const isStatusSelect = String(config?.attrKey || '').trim() === 'custom-status';
            const isPrioritySelect = String(config?.attrKey || '').trim() === 'custom-priority';
            const isCustomFieldSelect = !!config?.customFieldId;
            const isCustomFieldMulti = isCustomFieldSelect
                && (String(config?.customFieldType || '').trim() === 'multi' || String(config?.type || '').trim() === 'multi-select');
            let selectedCustomValues = new Set();
            const currentCustomValue = isCustomFieldSelect ? normalizeQuickbarCustomFieldValue(config, currentValue) : '';
            if (isCustomFieldSelect) {
                selectedCustomValues = new Set(Array.isArray(currentCustomValue)
                    ? currentCustomValue.map((item) => String(item || '').trim()).filter(Boolean)
                    : (String(currentCustomValue || '').trim() ? [String(currentCustomValue || '').trim()] : []));
            }

            // 更新菜单内容
            const optionHtml = options.map(opt => {
                const value = String(opt?.value || '').trim();
                const isActive = isCustomFieldSelect
                    ? (selectedCustomValues.has(value) ? 'is-active' : '')
                    : (opt.value === currentValue ? 'is-active' : '');
                const escapedValue = String(opt.label).replace(/"/g, '&quot;');
                const optionCls = isPrioritySelect
                    ? `sy-custom-props-floatbar__option is-priority ${isActive}`
                    : (isStatusSelect
                    ? `sy-custom-props-floatbar__option is-status ${isActive}`
                    : (isCustomFieldSelect
                    ? `sy-custom-props-floatbar__option is-status is-custom-field ${isActive}`
                    : `sy-custom-props-floatbar__option ${isActive}`));
                const labelHtml = isPrioritySelect
                    ? renderPriorityChip(opt.value, 'option')
                    : (isStatusSelect
                    ? `<span class="sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--status" style="${buildStatusChipStyle(opt.color)}">${opt.label}</span>`
                    : (isCustomFieldSelect
                    ? `<span class="sy-custom-props-floatbar__option-label sy-custom-props-floatbar__option-label--status" style="${buildStatusChipStyle(opt.color || '#9ca3af')}">${esc(String(opt.label || value || '').trim() || '未命名')}${isCustomFieldMulti && selectedCustomValues.has(value) ? '  ✓' : ''}</span>`
                    : `<span class="sy-custom-props-floatbar__option-label">${opt.label}</span>`));
                return `
                    <button class="${optionCls}"
                            data-value="${esc(value).replace(/"/g, '&quot;')}"
                            data-label="${escapedValue}">
                        ${labelHtml}
                    </button>
                `.trim();
            }).join('');
            const actionsHtml = isCustomFieldSelect
                ? `
                    <div class="sy-custom-props-floatbar__select-actions">
                        <button type="button" class="sy-custom-props-floatbar__option is-clear"
                                data-value=""
                                data-label=""
                                data-clear="1">清空</button>
                        ${isCustomFieldMulti ? `<button type="button" class="sy-custom-props-floatbar__option is-done" data-done="1">完成</button>` : ''}
                    </div>
                `.trim()
                : '';
            selectMenu.innerHTML = isCustomFieldSelect
                ? `<div class="sy-custom-props-floatbar__select-list">${optionHtml}</div>${actionsHtml}`
                : optionHtml;

            // 计算位置
            const anchorRect = anchorEl.getBoundingClientRect();
            const maxLen = options.reduce((m, o) => Math.max(m, String(o?.label || '').length), 0);
            const customFieldMinWidth = isCustomFieldMulti ? 92 : 88;
            const menuWidth = isPrioritySelect
                ? Math.min(140, Math.max(84, maxLen * 10 + 18))
                : (isStatusSelect
                ? Math.min(170, Math.max(96, maxLen * 12 + 24))
                : (isCustomFieldSelect
                ? Math.min(220, Math.max(customFieldMinWidth, maxLen * 12 + 32))
                : Math.min(200, Math.max(120, maxLen * 14 + 32))));

            if (isPrioritySelect) {
                selectMenu.style.minWidth = '84px';
                selectMenu.style.maxWidth = '140px';
            } else if (isStatusSelect) {
                selectMenu.style.minWidth = '96px';
                selectMenu.style.maxWidth = '170px';
            } else if (isCustomFieldSelect) {
                selectMenu.style.minWidth = `${customFieldMinWidth}px`;
                selectMenu.style.maxWidth = '220px';
            } else {
                selectMenu.style.minWidth = '120px';
                selectMenu.style.maxWidth = '200px';
            }
            selectMenu.style.width = `${menuWidth}px`;
            selectMenu.style.left = `${window.scrollX + anchorRect.left}px`;
            selectMenu.style.top = `${window.scrollY + anchorRect.bottom + 4}px`;
            selectMenu.classList.add('is-visible');

            // 绑定选择事件
            selectMenu.onclick = async (e) => {
                const doneEl = e.target.closest('[data-done="1"]');
                if (doneEl) {
                    selectMenu.classList.remove('is-visible');
                    return;
                }
                const clearEl = e.target.closest('[data-clear="1"]');
                const optionEl = clearEl || e.target.closest('.sy-custom-props-floatbar__option');
                if (!optionEl) {
                    selectMenu.classList.remove('is-visible');
                    return;
                }

                const selectedToken = String(optionEl.dataset.value || '').trim();
                const isClearClick = optionEl.dataset.clear === '1';
                const shouldClearCustomSingle = isCustomFieldSelect
                    && !isCustomFieldMulti
                    && !isClearClick
                    && !!selectedToken
                    && selectedCustomValues.has(selectedToken);
                const didClearCustomValue = isCustomFieldSelect && (isClearClick || shouldClearCustomSingle);
                const saveValue = isCustomFieldSelect
                    ? (didClearCustomValue
                        ? ''
                        : serializeQuickbarCustomFieldValueForSave(config, isCustomFieldMulti
                            ? (() => {
                                const next = new Set(selectedCustomValues);
                                if (next.has(selectedToken)) next.delete(selectedToken);
                                else if (selectedToken) next.add(selectedToken);
                                return Array.from(next);
                            })()
                            : selectedToken))
                    : selectedToken;

                const result = await saveTaskAttrWithUndo(blockIdAtOpen || currentBlockId, config.attrKey, saveValue, {
                    label: config.name,
                    skipNoopCheck: isCustomFieldSelect && saveValue === '',
                });

                if (result.success) {
                    const targetBlockId = blockIdAtOpen || currentBlockId;
                    const dispatchTaskId = String(result?.taskId || result?.id || targetBlockId).trim() || targetBlockId;
                    const dispatchRequestedTaskId = String(result?.requestedTaskId || targetBlockId).trim() || targetBlockId;
                    if (isCustomFieldMulti) {
                        const nextValues = optionEl.dataset.clear === '1' ? new Set() : new Set(selectedCustomValues);
                        if (optionEl.dataset.clear !== '1') {
                            if (nextValues.has(selectedToken)) nextValues.delete(selectedToken);
                            else if (selectedToken) nextValues.add(selectedToken);
                        }
                        selectedCustomValues = nextValues;
                        selectMenu.querySelectorAll('.sy-custom-props-floatbar__option.is-custom-field').forEach((button) => {
                            const value = String(button?.dataset?.value || '').trim();
                            const active = !!value && selectedCustomValues.has(value);
                            button.classList.toggle('is-active', active);
                            const chip = button.querySelector('.sy-custom-props-floatbar__option-label--status');
                            if (chip) chip.textContent = `${String(button?.dataset?.label || value || '').trim()}${active ? '  ✓' : ''}`;
                        });
                    }
                    if (!isCustomFieldMulti && isCustomFieldSelect) {
                        selectedCustomValues = selectedToken && !didClearCustomValue ? new Set([selectedToken]) : new Set();
                    }
                    if (String(currentBlockId || '').trim() === String(targetBlockId || '').trim()) {
                        currentProps[config.attrKey] = saveValue;
                        if (String(config?.attrKey || '').trim() === 'custom-status'
                            && result?.patch && typeof result.patch === 'object'
                            && Object.prototype.hasOwnProperty.call(result.patch, 'taskCompleteAt')) {
                            currentProps.taskCompleteAt = String(result.patch.taskCompleteAt || '').trim();
                        }
                        renderFloatBar();
                    }
                    const inlinePatch = { [config.attrKey]: saveValue };
                    if (String(config?.attrKey || '').trim() === 'custom-status'
                        && result?.patch && typeof result.patch === 'object'
                        && Object.prototype.hasOwnProperty.call(result.patch, 'taskCompleteAt')) {
                        inlinePatch.taskCompleteAt = String(result.patch.taskCompleteAt || '').trim();
                    }
                    try {
                        const optimisticIds = [targetBlockId, dispatchTaskId, dispatchRequestedTaskId];
                        const binding = resolveQuickbarAttrBindingFromBlockId(targetBlockId);
                        optimisticIds.push(binding?.taskId, binding?.attrHostId);
                        setInlineMetaOptimisticPatch(optimisticIds, inlinePatch);
                    } catch (e) {}
                    patchInlineMetaCache(targetBlockId, inlinePatch);
                    refreshInlineMetaByTaskId(targetBlockId, false);
                    showMessage(didClearCustomValue ? `已清空${config.name}` : `已更新${config.name}`, false, 1500);
                    dispatchTaskAttrUpdated(targetBlockId, config.attrKey, saveValue, {
                        taskId: dispatchTaskId,
                        requestedTaskId: dispatchRequestedTaskId,
                    });
                } else {
                    showMessage('更新失败', true, 2000);
                }

                if (!isCustomFieldMulti) selectMenu.classList.remove('is-visible');
            };
        }

        // 显示日期编辑器
        function showDateEditor(anchorEl, config, currentValue) {
            const blockIdAtOpen = String(currentBlockId || '').trim();
            if (!blockIdAtOpen) {
                showMessage('无法获取任务ID', true, 1800);
                return;
            }
            const attrKey = String(config?.attrKey || '').trim();
            if ((attrKey === 'custom-start-date' || attrKey === 'custom-completion-time') && typeof window.tmOpenTaskTimeHub === 'function') {
                try { inputEditor.classList.remove('is-visible'); } catch (e) {}
                const activeField = attrKey === 'custom-start-date' ? 'startDate' : 'completionTime';
                Promise.resolve(window.tmOpenTaskTimeHub(blockIdAtOpen, anchorEl, {
                    activeField,
                    source: 'quickbar',
                    refresh: false,
                    broadcast: false,
                    onChange: async (payload = {}) => {
                        const patch = (payload?.patch && typeof payload.patch === 'object') ? payload.patch : {};
                        const nextProps = {};
                        const addChangedDateProp = (key, value) => {
                            const nextValue = String(value || '').trim();
                            const prevValue = String(currentProps?.[key] || '').trim();
                            if (nextValue !== prevValue) nextProps[key] = nextValue;
                        };
                        if (Object.prototype.hasOwnProperty.call(patch, 'startDate')) addChangedDateProp('custom-start-date', patch.startDate);
                        if (Object.prototype.hasOwnProperty.call(patch, 'completionTime')) addChangedDateProp('custom-completion-time', patch.completionTime);
                        if (!Object.keys(nextProps).length) return;
                        if (String(currentBlockId || '').trim() === blockIdAtOpen) {
                            currentProps = { ...currentProps, ...nextProps };
                            renderFloatBar();
                        }
                        patchInlineMetaCache(blockIdAtOpen, nextProps);
                        refreshInlineMetaByTaskId(blockIdAtOpen, false);
                        const dispatchTaskId = String(payload?.taskId || blockIdAtOpen).trim() || blockIdAtOpen;
                        const requestedTaskId = String(payload?.requestedTaskId || blockIdAtOpen).trim() || blockIdAtOpen;
                        Object.entries(nextProps).forEach(([key, value]) => {
                            dispatchTaskAttrUpdated(blockIdAtOpen, key, value, {
                                taskId: dispatchTaskId,
                                requestedTaskId,
                            });
                        });
                    },
                })).catch((err) => {
                    showMessage(String(err?.message || err || '打开时间设置失败'), true, 1800);
                });
                return;
            }
            const isCompletionDate = String(config?.attrKey || '').trim() === 'custom-completion-time';
            const extraPanel = inputEditor.querySelector('[data-input-extra]');
            const saveDateValue = async (rawDateValue) => {
                const newValue = rawDateValue ? parseDate(rawDateValue) : '';
                const result = await saveTaskAttrWithUndo(blockIdAtOpen, config.attrKey, newValue, {
                    label: config.name,
                });
                if (result.success) {
                    const dispatchTaskId = String(result?.taskId || result?.id || blockIdAtOpen).trim() || blockIdAtOpen;
                    const dispatchRequestedTaskId = String(result?.requestedTaskId || blockIdAtOpen).trim() || blockIdAtOpen;
                    if (String(currentBlockId || '').trim() === blockIdAtOpen) {
                        currentProps[config.attrKey] = newValue;
                        renderFloatBar();
                    }
                    patchInlineMetaCache(blockIdAtOpen, { [config.attrKey]: newValue });
                    refreshInlineMetaByTaskId(blockIdAtOpen, false);
                    showMessage(`已更新${config.name}`, false, 1500);
                    dispatchTaskAttrUpdated(blockIdAtOpen, config.attrKey, newValue, {
                        taskId: dispatchTaskId,
                        requestedTaskId: dispatchRequestedTaskId,
                    });
                } else {
                    showMessage('更新失败', true, 2000);
                }
            };
            const renderRepeatExtras = async () => {
                if (!isCompletionDate || !(extraPanel instanceof HTMLElement)) return;
                const repeatRule = await getRepeatRuleForTask(blockIdAtOpen);
                const repeatSummary = String(repeatRule?.summary || '').trim() || '不重复';
                const untilSummary = (repeatRule && repeatRule.enabled)
                    ? (String(repeatRule.until || '').trim() ? `结束于 ${String(repeatRule.until || '').trim()}` : '永不结束')
                    : '未设置';
                extraPanel.innerHTML = `
                    <button type="button" class="sy-custom-props-floatbar__input-extra-row" data-repeat-row="rule">
                        <span class="sy-custom-props-floatbar__input-extra-main">
                            <span class="sy-custom-props-floatbar__input-extra-icon">${renderPhosphorBoldIcon('repeat', 14)}</span>
                            <span class="sy-custom-props-floatbar__input-extra-text">
                                <span class="sy-custom-props-floatbar__input-extra-title">循环</span>
                                <span class="sy-custom-props-floatbar__input-extra-desc">${esc(repeatSummary)}</span>
                            </span>
                        </span>
                        <span class="sy-custom-props-floatbar__input-extra-tail">${renderPhosphorBoldIcon('caret-right', 12)}</span>
                    </button>
                    <button type="button" class="sy-custom-props-floatbar__input-extra-row" data-repeat-row="until">
                        <span class="sy-custom-props-floatbar__input-extra-main">
                            <span class="sy-custom-props-floatbar__input-extra-icon">${renderPhosphorBoldIcon('calendar-check', 14)}</span>
                            <span class="sy-custom-props-floatbar__input-extra-text">
                                <span class="sy-custom-props-floatbar__input-extra-title">结束方式</span>
                                <span class="sy-custom-props-floatbar__input-extra-desc">${esc(untilSummary)}</span>
                            </span>
                        </span>
                        <span class="sy-custom-props-floatbar__input-extra-tail">${renderPhosphorBoldIcon('caret-right', 12)}</span>
                    </button>
                `.trim();
                extraPanel.classList.add('is-visible');
                const handleOpenRepeat = async () => {
                    const opened = await openRepeatDialogForCurrentTask();
                    if (!opened) return;
                    try {
                        const props = await getTaskCustomProps(blockIdAtOpen, true);
                        if (String(currentBlockId || '').trim() === blockIdAtOpen) {
                            currentProps = props;
                            renderFloatBar();
                        }
                        patchInlineMetaCache(blockIdAtOpen, props);
                        refreshInlineMetaByTaskId(blockIdAtOpen, true);
                    } catch (e) {}
                    await renderRepeatExtras();
                    positionPopupNearAnchor(inputEditor, anchorEl, { gap: 4, viewportMargin: 6 });
                };
                extraPanel.querySelectorAll('[data-repeat-row]').forEach((btn) => {
                    btn.onclick = async (ev) => {
                        try { ev.preventDefault(); } catch (e) {}
                        try { ev.stopPropagation(); } catch (e) {}
                        await handleOpenRepeat();
                    };
                });
            };
            const isTouchLike = isMobileDevice();
            if (isTouchLike) {
                // 移动端/触屏：直接系统日期选择器，避免中间输入框导致第一次交互丢失
                inputEditor.classList.remove('is-visible');
                const anchorRect = anchorEl.getBoundingClientRect();
                const tempInput = document.createElement('input');
                tempInput.type = 'date';
                tempInput.value = currentValue ? formatTaskTimeLikeManager(currentValue) : '';
                tempInput.setAttribute('aria-hidden', 'true');
                tempInput.style.cssText = `position:fixed;left:${Math.max(0, Math.round(anchorRect.left))}px;top:${Math.max(0, Math.round(anchorRect.bottom))}px;width:1px;height:1px;opacity:0;pointer-events:none;`;
                document.body.appendChild(tempInput);

                let cleaned = false;
                let committed = false;
                const cleanup = () => {
                    if (cleaned) return;
                    cleaned = true;
                    try { tempInput.oninput = null; } catch (e) {}
                    try { tempInput.onchange = null; } catch (e) {}
                    try { tempInput.remove(); } catch (e) {}
                };
                const commitIfAny = async () => {
                    if (committed) return;
                    const picked = String(tempInput.value || '').trim();
                    const oldDate = currentValue ? formatTaskTimeLikeManager(currentValue) : '';
                    if (!picked && !oldDate) return;
                    if (picked === oldDate) return;
                    committed = true;
                    await saveDateValue(picked);
                    cleanup();
                };

                tempInput.oninput = () => { commitIfAny(); };
                tempInput.onchange = () => { commitIfAny(); };

                // 只做超时清理，不用 blur 结束，避免选择器未完成就被提前清理
                setTimeout(() => cleanup(), 20000);

                try { tempInput.focus({ preventScroll: true }); } catch (e) {}
                // 延迟一帧再弹起，规避首次点击事件竞争
                setTimeout(() => {
                    try { tempInput.showPicker?.(); } catch (e) {
                        try { tempInput.click(); } catch (e2) {}
                    }
                }, 60);
                return;
            }

            // 桌面端：保留输入框弹层，并支持“清除日期”
            const input = setInputEditorMode('input');
            if (!(input instanceof HTMLInputElement)) return;
            const oldValue = currentValue ? formatTaskTimeLikeManager(currentValue) : '';
            input.type = 'date';
            input.value = oldValue;
            input.placeholder = '';

            inputEditor.classList.add('is-visible');
            positionPopupNearAnchor(inputEditor, anchorEl, { gap: 4, viewportMargin: 6 });
            Promise.resolve(renderRepeatExtras()).catch(() => null);

            input.focus();
            try { input.showPicker?.(); } catch (e) {}
            input.onclick = () => {
                try { input.showPicker?.(); } catch (e) {}
            };

            const saveDate = async () => {
                await saveDateValue(input.value);
                inputEditor.classList.remove('is-visible');
            };

            input.onchange = () => saveDate();
            input.onkeydown = (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    saveDate();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    inputEditor.classList.remove('is-visible');
                }
            };

            inputEditor.querySelector('[data-action="save"]').onclick = saveDate;
            inputEditor.querySelector('[data-action="cancel"]').onclick = () => {
                inputEditor.classList.remove('is-visible');
            };
            return;
        }

        // 显示文本编辑器
        async function saveFocusSummaryWithUndo(blockId, patch = {}, options = {}) {
            const id = String(blockId || '').trim();
            if (!id) return { success: false, viaSharedApi: false };
            const nextDuration = String(patch?.duration || '').trim();
            const nextEstimate = normalizeTomatoCountValue(patch?.tomatoEstimateCount || '');
            const sharedApi = getTaskHorizonSharedApi();
            const metaApplier = sharedApi?.applyTaskMetaPatchWithUndo;
            if (typeof metaApplier === 'function') {
                try {
                    suppressTaskHorizonMobileTopbarOpen();
                    const result = await metaApplier(id, {
                        duration: nextDuration,
                        tomatoEstimateCount: nextEstimate,
                    }, {
                        source: 'quickbar-focus-summary',
                        label: String(options?.label || '时长与番茄'),
                        refresh: false,
                        silent: true,
                    });
                    if (result !== false) {
                        return {
                            success: true,
                            viaSharedApi: true,
                            taskId: String(result?.taskId || result?.id || id).trim() || id,
                            requestedTaskId: String(result?.requestedTaskId || id).trim() || id,
                        };
                    }
                } catch (e) {}
            }
            const durationResult = await saveRawTaskAttrWithUndo(id, 'custom-duration', nextDuration, { label: '时长' });
            const estimateResult = await saveTaskAttrWithUndo(id, 'custom-tomato-estimate-count', nextEstimate, { label: '预计番茄' });
            return {
                success: durationResult?.success === true && estimateResult?.success === true,
                viaSharedApi: !!(durationResult?.viaSharedApi || estimateResult?.viaSharedApi),
                taskId: String(estimateResult?.taskId || durationResult?.taskId || id).trim() || id,
                requestedTaskId: String(estimateResult?.requestedTaskId || durationResult?.requestedTaskId || id).trim() || id,
            };
        }

        function applyFocusSummarySaveResult(blockId, patch = {}, result = {}) {
            const id = String(blockId || '').trim();
            const nextProps = {
                'custom-duration': String(patch?.duration || '').trim(),
                'custom-tomato-estimate-count': normalizeTomatoCountValue(patch?.tomatoEstimateCount || ''),
            };
            currentProps = normalizeCustomProps({ ...currentProps, ...nextProps });
            renderFloatBar();
            patchInlineMetaCache(id, {
                ...nextProps,
                'custom-focus-summary': formatFocusSummaryDisplay(currentProps),
            });
            refreshInlineMetaByTaskId(id, false);
            const dispatchTaskId = String(result?.taskId || result?.id || id).trim() || id;
            const requestedTaskId = String(result?.requestedTaskId || id).trim() || id;
            Object.entries(nextProps).forEach(([key, value]) => {
                dispatchTaskAttrUpdated(id, key, value, {
                    taskId: dispatchTaskId,
                    requestedTaskId,
                });
            });
        }

        function showFocusSummaryEditor(anchorEl, config) {
            const blockIdAtOpen = String(currentBlockId || '').trim();
            if (!blockIdAtOpen) {
                showMessage('无法获取任务ID', true, 1800);
                return;
            }
            if (anchorEl.closest?.('.sy-custom-props-inline-host')) {
                const detailId = String(resolveCurrentTaskId() || blockIdAtOpen).trim() || blockIdAtOpen;
                if (typeof window.tmEditFocusSummaryInline === 'function') {
                    try {
                        inputEditor.classList.remove('is-visible');
                        window.tmEditFocusSummaryInline(detailId, anchorEl);
                        return;
                    } catch (e) {}
                }
            }
            selectMenu.classList.remove('is-visible');
            inputEditor.classList.remove('is-visible', 'is-duration', 'is-remark', 'is-focus-summary');
            cleanupFocusSummaryEditorScaffold();
            noteQuickbarActivity();
            const durationPresetOptions = getQuickbarDurationPresetOptions();
            const editorControl = setInputEditorMode('input');
            const input = editorControl instanceof HTMLInputElement ? editorControl : null;
            const extraPanel = inputEditor.querySelector('[data-input-extra]');
            const cancelBtn = inputEditor.querySelector('[data-action="cancel"]');
            const saveBtn = inputEditor.querySelector('[data-action="save"]');
            if (!(input instanceof HTMLInputElement)) return;
            inputEditor.classList.remove('is-duration', 'is-remark');
            inputEditor.classList.add('is-focus-summary');
            input.type = 'text';
            input.value = String(currentProps['custom-duration'] || '');
            input.placeholder = '例如：30 或 30m';
            input.removeAttribute('min');
            input.removeAttribute('step');
            input.removeAttribute('inputmode');
            input.classList.add('sy-custom-props-floatbar__input--duration');

            const currentDurationValue = String(currentProps['custom-duration'] || '').trim();
            const currentEstimateValue = normalizeTomatoCountValue(currentProps['custom-tomato-estimate-count'] || '');
            let focusSummaryMode = currentDurationValue ? 'duration' : (currentEstimateValue ? 'tomato' : 'duration');

            let tabs = inputEditor.querySelector('[data-focus-summary-tabs]');
            if (tabs instanceof HTMLElement) tabs.remove();
            tabs = document.createElement('div');
            tabs.className = 'sy-custom-props-floatbar__focus-tabs';
            tabs.setAttribute('data-focus-summary-tabs', 'true');
            tabs.setAttribute('role', 'tablist');
            tabs.setAttribute('aria-label', '时长与番茄');
            tabs.innerHTML = `
                <button type="button" data-focus-summary-tab="duration" role="tab">预计时长</button>
                <button type="button" data-focus-summary-tab="tomato" role="tab">预计番茄</button>
            `;
            inputEditor.insertBefore(tabs, input);

            let durationPanel = inputEditor.querySelector('[data-focus-summary-duration-panel]');
            if (durationPanel instanceof HTMLElement) durationPanel.remove();
            durationPanel = document.createElement('div');
            durationPanel.className = 'sy-custom-props-floatbar__focus-panel';
            durationPanel.setAttribute('data-focus-summary-duration-panel', 'true');
            inputEditor.insertBefore(durationPanel, input);
            durationPanel.appendChild(input);

            let estimateInput = inputEditor.querySelector('[data-focus-summary-estimate]');
            if (!(estimateInput instanceof HTMLInputElement)) {
                estimateInput = document.createElement('input');
                estimateInput.className = 'sy-custom-props-floatbar__input';
                estimateInput.setAttribute('data-focus-summary-estimate', 'true');
            }
            estimateInput.type = 'number';
            estimateInput.min = '0';
            estimateInput.step = '1';
            estimateInput.inputMode = 'numeric';
            estimateInput.value = currentEstimateValue;
            estimateInput.placeholder = '空或整数';

            if (extraPanel instanceof HTMLElement) {
                extraPanel.innerHTML = durationPresetOptions.length
                    ? durationPresetOptions.map((value) => `
                        <button type="button" class="sy-custom-props-floatbar__input-extra-row ${normalizeDurationPresetValue(input.value) === value ? 'is-active' : ''}" data-duration-preset-value="${esc(value)}">
                            <span class="sy-custom-props-floatbar__input-extra-main">
                                <span class="sy-custom-props-floatbar__input-extra-text"><span class="sy-custom-props-floatbar__input-extra-title">${esc(value)}</span></span>
                            </span>
                            <span class="sy-custom-props-floatbar__input-extra-tail">${renderPhosphorBoldIcon('check', 12)}</span>
                        </button>
                    `).join('')
                    : '';
                extraPanel.classList.toggle('is-visible', durationPresetOptions.length > 0);
                durationPanel.appendChild(extraPanel);
            }

            const oldField = inputEditor.querySelector('[data-focus-summary-estimate-field]');
            if (oldField instanceof HTMLElement) oldField.remove();
            const estimateField = document.createElement('label');
            estimateField.className = 'sy-custom-props-floatbar__focus-field';
            estimateField.setAttribute('data-focus-summary-estimate-field', 'true');
            estimateField.innerHTML = '<span>预计番茄</span>';
            estimateField.appendChild(estimateInput);
            const actions = inputEditor.querySelector('.sy-custom-props-floatbar__input-actions');
            if (actions instanceof HTMLElement) inputEditor.insertBefore(estimateField, actions);
            else inputEditor.appendChild(estimateField);

            const oldReadonly = inputEditor.querySelector('[data-focus-summary-readonly]');
            if (oldReadonly instanceof HTMLElement) oldReadonly.remove();
            const readonly = document.createElement('div');
            readonly.className = 'sy-custom-props-floatbar__focus-readonly';
            readonly.setAttribute('data-focus-summary-readonly', 'true');
            readonly.innerHTML = `
                <span>实际 <b class="sy-custom-props-focus-actual">${esc(currentProps['custom-tomato-count'] || '0')}</b></span>
                <span>耗时 <b>${esc(currentProps['custom-focus-spent-display'] || '0m')}</b></span>
            `;
            if (actions instanceof HTMLElement) inputEditor.insertBefore(readonly, actions);
            else inputEditor.appendChild(readonly);

            if (cancelBtn instanceof HTMLButtonElement) cancelBtn.textContent = '清空';
            const repositionEditor = () => positionPopupNearAnchor(inputEditor, anchorEl, { gap: 4, viewportMargin: 6 });
            const setFocusSummaryMode = (nextMode, options = {}) => {
                focusSummaryMode = nextMode === 'tomato' ? 'tomato' : 'duration';
                tabs.querySelectorAll('[data-focus-summary-tab]').forEach((button) => {
                    if (!(button instanceof HTMLButtonElement)) return;
                    const selected = String(button.dataset.focusSummaryTab || '').trim() === focusSummaryMode;
                    button.classList.toggle('is-active', selected);
                    button.setAttribute('aria-selected', selected ? 'true' : 'false');
                });
                durationPanel.hidden = focusSummaryMode !== 'duration';
                estimateField.hidden = focusSummaryMode !== 'tomato';
                repositionEditor();
                if (options?.focus === true) {
                    try {
                        requestAnimationFrame(() => {
                            const target = focusSummaryMode === 'tomato' ? estimateInput : input;
                            target.focus();
                            target.select();
                        });
                    } catch (e) {}
                }
            };
            tabs.querySelectorAll('[data-focus-summary-tab]').forEach((button) => {
                if (!(button instanceof HTMLButtonElement)) return;
                button.onmousedown = (e) => e.preventDefault();
                button.onclick = (e) => {
                    e.preventDefault();
                    setFocusSummaryMode(button.dataset.focusSummaryTab || 'duration', { focus: true });
                };
            });
            setFocusSummaryMode(focusSummaryMode);
            inputEditor.classList.add('is-visible');
            noteQuickbarActivity();
            repositionEditor();
            try {
                const target = focusSummaryMode === 'tomato' ? estimateInput : input;
                target.focus();
                target.select();
            } catch (e) {}

            const saveFocusSummary = async (patch) => {
                const nextPatch = {
                    duration: String(patch?.duration || '').trim(),
                    tomatoEstimateCount: normalizeTomatoCountValue(patch?.tomatoEstimateCount || ''),
                };
                const result = await saveFocusSummaryWithUndo(blockIdAtOpen, nextPatch, { label: config?.name || '专注/耗时' });
                if (!result.success) {
                    showMessage('更新失败', true, 2000);
                    return;
                }
                applyFocusSummarySaveResult(blockIdAtOpen, nextPatch, result);
                inputEditor.classList.remove('is-visible');
                showMessage(nextPatch.duration || nextPatch.tomatoEstimateCount ? '已更新专注/耗时' : '已清除专注/耗时', false, 1500);
            };
            const submit = () => {
                const durationDraft = String(input.value || '').trim();
                const tomatoDraft = normalizeTomatoCountValue(estimateInput.value);
                return saveFocusSummary({
                    duration: focusSummaryMode === 'duration'
                        ? (durationDraft ? durationDraft : '')
                        : (tomatoDraft ? '' : durationDraft),
                    tomatoEstimateCount: focusSummaryMode === 'tomato'
                        ? (tomatoDraft ? tomatoDraft : '')
                        : (durationDraft ? '' : tomatoDraft),
                });
            };
            input.oninput = () => {
                if (String(input.value || '').trim()) estimateInput.value = '';
            };
            estimateInput.oninput = () => {
                if (!normalizeTomatoCountValue(estimateInput.value)) return;
                input.value = '';
                if (extraPanel instanceof HTMLElement) {
                    extraPanel.querySelectorAll('[data-duration-preset-value]').forEach((btn) => btn.classList.remove('is-active'));
                }
            };
            input.onkeydown = (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submit();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    inputEditor.classList.remove('is-visible');
                }
            };
            estimateInput.onkeydown = input.onkeydown;
            if (extraPanel instanceof HTMLElement && durationPresetOptions.length) {
                extraPanel.querySelectorAll('[data-duration-preset-value]').forEach((button) => {
                    if (!(button instanceof HTMLButtonElement)) return;
                    button.onmousedown = (e) => e.preventDefault();
                    button.onclick = (e) => {
                        e.preventDefault();
                        const nextValue = normalizeDurationPresetValue(button.dataset.durationPresetValue || '');
                        if (!nextValue) return;
                        input.value = nextValue;
                        estimateInput.value = '';
                        extraPanel.querySelectorAll('[data-duration-preset-value]').forEach((btn) => btn.classList.toggle('is-active', btn === button));
                        try { input.focus(); input.select(); } catch (err) {}
                    };
                });
            }
            if (saveBtn instanceof HTMLButtonElement) saveBtn.onclick = submit;
            if (cancelBtn instanceof HTMLButtonElement) cancelBtn.onclick = () => saveFocusSummary({ duration: '', tomatoEstimateCount: '' });
        }

        function showTextEditor(anchorEl, config, currentValue) {
            const isRemark = String(config?.attrKey || '').trim() === 'custom-remark';
            const isDuration = String(config?.attrKey || '').trim() === 'custom-duration';
            const isTomatoCount = String(config?.attrKey || '').trim() === 'custom-tomato-estimate-count'
                || String(config?.attrKey || '').trim() === 'custom-tomato-count';
            const durationPresetOptions = isDuration ? getQuickbarDurationPresetOptions() : [];
            const remarkTools = getRemarkMarkdownTools();
            const editorControl = setInputEditorMode(isRemark ? 'textarea' : 'input');
            const input = editorControl instanceof HTMLInputElement ? editorControl : null;
            const textarea = editorControl instanceof HTMLTextAreaElement ? editorControl : null;
            const valueSource = isRemark ? textarea : input;
            const remarkToolbar = inputEditor.querySelector('[data-remark-toolbar]');
            const remarkToolsBtn = inputEditor.querySelector('[data-action="remark-tools"]');
            const extraPanel = inputEditor.querySelector('[data-input-extra]');
            const cancelBtn = inputEditor.querySelector('[data-action="cancel"]');
            const saveBtn = inputEditor.querySelector('[data-action="save"]');
            if (!valueSource) return;
            inputEditor.classList.remove('is-focus-summary');
            cleanupFocusSummaryEditorScaffold();
            if (isDuration) inputEditor.classList.add('is-duration');
            if (cancelBtn instanceof HTMLButtonElement) {
                cancelBtn.textContent = isDuration ? '清空' : '取消';
            }
            if (input instanceof HTMLInputElement) {
                input.type = isTomatoCount ? 'number' : 'text';
                input.value = isTomatoCount ? normalizeTomatoCountValue(currentValue) : (currentValue || '');
                input.placeholder = config.placeholder || '输入内容...';
                if (isTomatoCount) {
                    input.min = '0';
                    input.step = '1';
                    input.inputMode = 'numeric';
                } else {
                    input.removeAttribute('min');
                    input.removeAttribute('step');
                    input.removeAttribute('inputmode');
                }
                input.classList.toggle('sy-custom-props-floatbar__input--duration', isDuration);
            }
            if (textarea instanceof HTMLTextAreaElement) {
                textarea.value = currentValue || '';
                textarea.placeholder = config.placeholder || '输入内容...';
                try { textarea.dataset.savedValue = isRemark ? normalizeRemarkMarkdown(currentValue || '') : ''; } catch (e) {}
                try { delete textarea.dataset.dirty; } catch (e) {}
                try { delete textarea.dataset.composing; } catch (e) {}
                try { delete textarea.dataset.saving; } catch (e) {}
                if (isRemark && remarkTools && typeof remarkTools.bindUndoHistory === 'function') {
                    try { remarkTools.bindUndoHistory(textarea); } catch (e) {}
                    try { remarkTools.resetUndoHistory?.(textarea); } catch (e) {}
                }
            }
            const blockIdAtOpen = String(currentBlockId || '').trim();

            const applySaveResult = (newValue, result) => {
                if (result.success) {
                    const dispatchTaskId = String(result?.taskId || result?.id || blockIdAtOpen).trim() || blockIdAtOpen;
                    const dispatchRequestedTaskId = String(result?.requestedTaskId || blockIdAtOpen).trim() || blockIdAtOpen;
                    currentProps[config.attrKey] = newValue;
                    renderFloatBar();
                    patchInlineMetaCache(blockIdAtOpen, { [config.attrKey]: newValue });
                    refreshInlineMetaByTaskId(blockIdAtOpen, false);
                    if (newValue) showMessage(`已更新${config.name}`, false, 1500);
                    else showMessage(`已清除${config.name}`, false, 1500);
                    dispatchTaskAttrUpdated(blockIdAtOpen, config.attrKey, newValue, {
                        taskId: dispatchTaskId,
                        requestedTaskId: dispatchRequestedTaskId,
                    });
                    return true;
                }
                showMessage('更新失败', true, 2000);
                return false;
            };

            const saveDurationPreset = async (rawValue) => {
                const newValue = String(rawValue || '').trim();
                const result = await saveTaskAttrWithUndo(blockIdAtOpen, config.attrKey, newValue, {
                    label: config.name,
                });
                if (applySaveResult(newValue, result)) {
                    inputEditor.classList.remove('is-visible');
                }
            };

            if (extraPanel instanceof HTMLElement) {
                if (isDuration && durationPresetOptions.length) {
                    extraPanel.innerHTML = `
                        <div class="sy-custom-props-floatbar__duration-helper">选预设或直接输入</div>
                        ${durationPresetOptions.map((value) => `
                            <button type="button" class="sy-custom-props-floatbar__input-extra-row ${normalizeDurationPresetValue(currentValue) === value ? 'is-active' : ''}" data-duration-preset-value="${esc(value)}">
                                <span class="sy-custom-props-floatbar__input-extra-main">
                                    <span class="sy-custom-props-floatbar__input-extra-icon">${renderPhosphorBoldIcon('timer', 14)}</span>
                                    <span class="sy-custom-props-floatbar__input-extra-text">
                                        <span class="sy-custom-props-floatbar__input-extra-title">${esc(value)}</span>
                                    </span>
                                </span>
                                <span class="sy-custom-props-floatbar__input-extra-tail">${renderPhosphorBoldIcon('check', 12)}</span>
                            </button>
                        `).join('')}
                    `.trim();
                    extraPanel.classList.add('is-visible');
                } else {
                    extraPanel.classList.remove('is-visible');
                    extraPanel.innerHTML = '';
                }
            }

            // 计算位置
            inputEditor.classList.add('is-visible');
            const repositionEditor = () => positionPopupNearAnchor(inputEditor, anchorEl, { gap: 4, viewportMargin: 6 });
            repositionEditor();
            if (textarea instanceof HTMLTextAreaElement) {
                syncInputEditorTextareaHeight(textarea, 76);
                try {
                    requestAnimationFrame(() => {
                        syncInputEditorTextareaHeight(textarea, 76);
                        repositionEditor();
                    });
                } catch (e) {}
            }

            valueSource.focus();
            if (input instanceof HTMLInputElement) {
                input.select();
            } else if (textarea instanceof HTMLTextAreaElement) {
                try { textarea.setSelectionRange(textarea.value.length, textarea.value.length); } catch (e) {}
            }

            // 绑定事件
            const saveText = async () => {
                const newValue = isRemark
                    ? normalizeRemarkMarkdown(valueSource.value || '')
                    : isTomatoCount
                    ? normalizeTomatoCountValue(valueSource.value || '')
                    : String(valueSource.value || '').trim();

                if (isRemark && textarea instanceof HTMLTextAreaElement) {
                    try { textarea.dataset.saving = 'true'; } catch (e) {}
                }

                let result = { success: false };
                try {
                    result = await saveTaskAttrWithUndo(blockIdAtOpen, config.attrKey, newValue, {
                        label: config.name,
                    });
                } catch (e) {
                    result = { success: false };
                } finally {
                    if (isRemark && textarea instanceof HTMLTextAreaElement) {
                        try { delete textarea.dataset.saving; } catch (e) {}
                    }
                }

                if (!applySaveResult(newValue, result)) {
                    return;
                }

                inputEditor.classList.remove('is-visible');
                if (isRemark && textarea instanceof HTMLTextAreaElement) {
                    try { textarea.dataset.savedValue = newValue; } catch (e) {}
                    try { delete textarea.dataset.dirty; } catch (e) {}
                    clearQuickbarRemarkDraftState('saved');
                }
            };

            if (textarea instanceof HTMLTextAreaElement) {
                textarea.oninput = () => {
                    if (isRemark) {
                        try { textarea.dataset.dirty = 'true'; } catch (e) {}
                    }
                    syncInputEditorTextareaHeight(textarea, 76);
                    repositionEditor();
                };
                textarea.oncompositionstart = () => {
                    if (!isRemark) return;
                    try { textarea.dataset.composing = 'true'; } catch (e) {}
                    try { textarea.dataset.dirty = 'true'; } catch (e) {}
                };
                textarea.oncompositionend = () => {
                    if (!isRemark) return;
                    try { delete textarea.dataset.composing; } catch (e) {}
                    try { textarea.dataset.dirty = 'true'; } catch (e) {}
                };
                textarea.onkeydown = (e) => {
                    if (isRemark && remarkTools && typeof remarkTools.handleTextareaKeydown === 'function') {
                        const handled = remarkTools.handleTextareaKeydown(textarea, e);
                        if (handled) {
                            try { textarea.dataset.dirty = 'true'; } catch (err) {}
                            syncInputEditorTextareaHeight(textarea, 76);
                            repositionEditor();
                            return;
                        }
                    }
                    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                        e.preventDefault();
                        saveText();
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        if (remarkToolbar instanceof HTMLElement && remarkToolbar.classList.contains('is-open')) {
                            remarkToolbar.classList.remove('is-open');
                            remarkToolbar.hidden = true;
                            return;
                        }
                        inputEditor.classList.remove('is-visible');
                    }
                };
            }
            if (input instanceof HTMLInputElement) {
                input.onkeydown = (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        saveText();
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        inputEditor.classList.remove('is-visible');
                    }
                };
            }

            if (isRemark && textarea instanceof HTMLTextAreaElement && remarkToolbar instanceof HTMLElement) {
                remarkToolbar.querySelectorAll('[data-remark-tool]').forEach((button) => {
                    if (!(button instanceof HTMLButtonElement)) return;
                    button.onmousedown = (e) => {
                        e.preventDefault();
                    };
                    button.onclick = (e) => {
                        e.preventDefault();
                        const action = String(button.dataset.remarkTool || '').trim();
                        if (!action || !remarkTools) return;
                        if (action === 'bold' && typeof remarkTools.wrapSelection === 'function') remarkTools.wrapSelection(textarea, '**');
                        else if (action === 'italic' && typeof remarkTools.wrapSelection === 'function') remarkTools.wrapSelection(textarea, '*');
                        else if (action === 'code' && typeof remarkTools.wrapSelection === 'function') remarkTools.wrapSelection(textarea, '`');
                        else if (action === 'link' && typeof remarkTools.insertLinkTemplate === 'function') remarkTools.insertLinkTemplate(textarea);
                        else if (action === 'quote' && typeof remarkTools.toggleLinePrefix === 'function') remarkTools.toggleLinePrefix(textarea, '> ');
                        else if (action === 'bullet' && typeof remarkTools.toggleLinePrefix === 'function') remarkTools.toggleLinePrefix(textarea, '- ');
                        else if (action === 'ordered' && typeof remarkTools.toggleOrderedList === 'function') remarkTools.toggleOrderedList(textarea);
                        try { textarea.dataset.dirty = 'true'; } catch (err) {}
                        syncInputEditorTextareaHeight(textarea, 76);
                        repositionEditor();
                    };
                });
                if (remarkToolsBtn instanceof HTMLButtonElement) {
                    remarkToolsBtn.onmousedown = (e) => {
                        e.preventDefault();
                    };
                    remarkToolsBtn.onclick = (e) => {
                        e.preventDefault();
                        const nextOpen = !remarkToolbar.classList.contains('is-open');
                        remarkToolbar.classList.toggle('is-open', nextOpen);
                        remarkToolbar.hidden = !nextOpen;
                        syncInputEditorTextareaHeight(textarea, 76);
                        try {
                            requestAnimationFrame(() => {
                                syncInputEditorTextareaHeight(textarea, 76);
                                repositionEditor();
                            });
                        } catch (e2) {}
                        try { textarea.focus({ preventScroll: true }); } catch (e2) { try { textarea.focus(); } catch (e3) {} }
                        repositionEditor();
                    };
                }
            } else if (remarkToolsBtn instanceof HTMLButtonElement) {
                remarkToolsBtn.onclick = null;
                remarkToolsBtn.onmousedown = null;
            }

            if (extraPanel instanceof HTMLElement && isDuration && durationPresetOptions.length) {
                extraPanel.querySelectorAll('[data-duration-preset-value]').forEach((button) => {
                    if (!(button instanceof HTMLButtonElement)) return;
                    button.onmousedown = (e) => {
                        e.preventDefault();
                    };
                    button.onclick = async (e) => {
                        e.preventDefault();
                        const nextValue = normalizeDurationPresetValue(button.dataset.durationPresetValue || '');
                        if (!nextValue) return;
                        if (input instanceof HTMLInputElement) input.value = nextValue;
                        await saveDurationPreset(nextValue);
                    };
                });
            }

            if (saveBtn instanceof HTMLButtonElement) saveBtn.onclick = saveText;
            if (cancelBtn instanceof HTMLButtonElement) cancelBtn.onclick = async () => {
                if (isDuration) {
                    await saveDurationPreset('');
                    return;
                }
                if (remarkToolbar instanceof HTMLElement) {
                    remarkToolbar.classList.remove('is-open');
                    remarkToolbar.hidden = true;
                }
                inputEditor.classList.remove('is-visible');
            };
        }

        // 隐藏所有弹出层
        function hideAllPopups() {
            selectMenu.classList.remove('is-visible');
            inputEditor.classList.remove('is-visible');
            inputEditor.classList.remove('is-focus-summary');
            cleanupFocusSummaryEditorScaffold();
        }

        // 更新悬浮条位置
        let updatePositionRafId = 0;
        function updatePosition() {
            if (updatePositionRafId) return;
            updatePositionRafId = requestAnimationFrame(() => {
                updatePositionRafId = 0;
                if (!currentBlockEl || floatBar.style.display === 'none') return;
                if (!currentBlockEl.isConnected) {
                    hideFloatBar();
                    return;
                }

                const rect = currentBlockEl.getBoundingClientRect();
                const barRect = floatBar.getBoundingClientRect();
                const barHeight = barRect.height || 40;
                const barWidth = barRect.width || 240;
                const gap = 0;

                let top = window.scrollY + rect.top - gap - barHeight;
                if (top < window.scrollY + 4) {
                    top = window.scrollY + rect.bottom + gap;
                }

                const desiredLeft = window.scrollX + rect.left + 30;
                const viewportW = document.documentElement?.clientWidth || window.innerWidth || 0;
                const minLeft = window.scrollX + 4;
                const maxLeft = window.scrollX + Math.max(0, viewportW - barWidth - 4);
                const left = Math.max(minLeft, Math.min(desiredLeft, maxLeft));
                floatBar.style.top = `${Math.max(0, top)}px`;
                floatBar.style.left = `${Math.max(0, left)}px`;
            });
        }

        // 显示悬浮条
        async function showFloatBar(blockEl) {
            updateCurrentTaskContext(blockEl);
            const blockIdAtOpen = String(currentBlockId || '').trim();
            const taskIdAtOpen = String(resolveCurrentTaskId() || '').trim();
            const loadToken = ++currentFloatBarLoadToken;

            // 先用缓存/默认值立即显示，避免被异步属性或提醒查询阻塞。
            currentProps = getInlineCachedProps(blockIdAtOpen);
            currentReminderSnapshot = null;
            currentReminderRefreshToken += 1;

            // 渲染悬浮条
            renderFloatBar();

            // 显示并定位
            floatBar.style.display = 'flex';
            hideAllPopups();
            updatePosition();
            scheduleQuickbarAutoHide();

            if (!blockIdAtOpen) return;

            const hasCachedPropsAtOpen = inlineMetaCache.has(blockIdAtOpen);
            Promise.resolve(refreshBlockAttrs(blockIdAtOpen, !hasCachedPropsAtOpen))
                .then((props) => {
                    if (!props || !isCurrentFloatBarContext(blockIdAtOpen, taskIdAtOpen, loadToken)) return;
                    currentProps = normalizeCustomProps(props);
                    rerenderFloatBarIfCurrent(blockIdAtOpen, taskIdAtOpen, loadToken);
                })
                .catch(() => null);

            Promise.resolve(refreshCurrentReminderSnapshot(true))
                .then(() => {
                    rerenderFloatBarIfCurrent(blockIdAtOpen, taskIdAtOpen, loadToken);
                })
                .catch(() => null);
        }

        // 隐藏悬浮条
        function hideFloatBar() {
            clearQuickbarAutoHideTimer();
            currentFloatBarLoadToken += 1;
            if (updatePositionRafId) {
                try { cancelAnimationFrame(updatePositionRafId); } catch (e) {}
                updatePositionRafId = 0;
            }
            floatBar.style.display = 'none';
            hideAllPopups();
            currentBlockEl = null;
            currentBlockId = '';
            currentTaskId = '';
            currentTaskName = '';
            currentProps = {};
            currentReminderSnapshot = null;
            currentReminderRefreshToken += 1;
        }

        function removeInlineMetaNodes() {
            try { document.querySelectorAll('.sy-custom-props-inline-layer').forEach((el) => el.remove()); } catch (e) {}
            try { document.querySelectorAll('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((el) => removeInlineMetaHostNode(el, true)); } catch (e) {}
            try { document.querySelectorAll('.sy-custom-props-inline-parent').forEach((el) => el.classList.remove('sy-custom-props-inline-parent')); } catch (e) {}
            inlineMetaLayer = null;
            inlineMetaMissingHostSeenAt.clear();
            invalidateInlineMetaActiveTargetsCache();
        }

        function ensureInlineMetaLayer(blockEl) {
            if (blockEl?.closest?.('.tm-task-detail-note-mount')) return null;
            const root = blockEl?.closest?.('.protyle');
            if (root?.closest?.('.tm-task-detail-note-mount')) return null;
            const container = root?.querySelector?.('.protyle-content') || root?.querySelector?.('.protyle-wysiwyg') || root;
            if (!container) return null;
            let layer = container.querySelector?.(':scope > .sy-custom-props-inline-layer[data-inline-layer="true"]') || null;
            const duplicateLayers = Array.from(container.querySelectorAll?.(':scope > .sy-custom-props-inline-layer[data-inline-layer="true"]') || []);
            if (!layer && duplicateLayers.length) layer = duplicateLayers[0];
            duplicateLayers.slice(layer ? 1 : 0).forEach((node) => {
                try { node.remove(); } catch (e) {}
            });
            if (layer && layer.isConnected) {
                inlineMetaLayer = layer;
                try { layer.setAttribute('contenteditable', 'false'); } catch (e) {}
                try { layer.setAttribute('aria-hidden', 'true'); } catch (e) {}
                return layer;
            }
            try {
                if (window.getComputedStyle(container).position === 'static') {
                    container.style.position = 'relative';
                }
            } catch (e) {}
            layer = document.createElement('div');
            layer.className = 'sy-custom-props-inline-layer';
            layer.setAttribute('data-inline-layer', 'true');
            layer.setAttribute('contenteditable', 'false');
            layer.setAttribute('aria-hidden', 'true');
            container.appendChild(layer);
            inlineMetaLayer = layer;
            return layer;
        }

        function getInlineHostParent(blockEl) {
            if (!blockEl) return null;
            return blockEl;
        }

        function getInlineViewportBounds(blockEl) {
            if (!blockEl) return null;
            try {
                const root = blockEl.closest?.('.protyle');
                const content = root?.querySelector?.('.protyle-content') || root?.querySelector?.('.protyle-wysiwyg') || root;
                const rect = content?.getBoundingClientRect?.();
                if (!rect) return null;
                if (rect.width <= 0 || rect.height <= 0) return null;
                const topOcclusionBottom = getInlineTopOcclusionBottom(blockEl, rect);
                return {
                    ...rect,
                    top: Math.max(Math.round(rect.top), Math.round(topOcclusionBottom)),
                };
            } catch (e) {
                return null;
            }
        }

        function getInlineTopOcclusionBottom(blockEl, contentRect = null) {
            const baseTop = Math.max(0, Math.round(contentRect?.top ?? 0));
            if (!blockEl) return baseTop;
            try {
                const root = blockEl.closest?.('.protyle');
                if (!root) return baseTop;
                let occlusionBottom = baseTop;
                const blockers = Array.from(root.querySelectorAll('.protyle-title, .protyle-breadcrumb'));
                blockers.forEach((el) => {
                    if (!(el instanceof HTMLElement)) return;
                    const rect = el.getBoundingClientRect?.();
                    if (!rect || rect.width <= 0 || rect.height <= 0) return;
                    if (rect.bottom <= baseTop) return;
                    const style = window.getComputedStyle?.(el);
                    const position = String(style?.position || '').toLowerCase();
                    const stickyLike = position === 'sticky' || position === 'fixed' || rect.top <= (baseTop + rect.height + 24);
                    if (!stickyLike) return;
                    occlusionBottom = Math.max(occlusionBottom, Math.round(rect.bottom));
                });
                return occlusionBottom;
            } catch (e) {
                return baseTop;
            }
        }

        function getInlineTextAnchor(blockEl) {
            if (!blockEl) return null;
            const paragraph = blockEl.querySelector?.(':scope > .p') || blockEl.querySelector?.('.p') || null;
            if (!paragraph) return null;
            // 只把真正可编辑的正文区当作定位锚点，避免把其他插件插入的 contenteditable=false 信息区算进正文尾部。
            return paragraph.querySelector?.(':scope > [contenteditable="true"]')
                || paragraph.querySelector?.('[contenteditable="true"]')
                || paragraph;
        }

        function rectsOverlap(a, b, gap = 4) {
            if (!a || !b) return false;
            return !(
                (a.right + gap) <= b.left ||
                (b.right + gap) <= a.left ||
                (a.bottom + gap) <= b.top ||
                (b.bottom + gap) <= a.top
            );
        }

        function isInlineRectVisibleInBounds(rect, bounds, buffer = 0) {
            if (!rect) return false;
            const viewportWidth = window.innerWidth || document.documentElement?.clientWidth || 0;
            const viewportHeight = window.innerHeight || document.documentElement?.clientHeight || 0;
            const leftBound = Math.max(0, Math.round(bounds?.left ?? 0));
            const rightBound = Math.min(viewportWidth, Math.round(bounds?.right ?? viewportWidth));
            const topBound = Math.max(0, Math.round(bounds?.top ?? 0));
            const bottomBound = Math.min(viewportHeight, Math.round(bounds?.bottom ?? viewportHeight));
            if (rightBound <= leftBound || bottomBound <= topBound) return false;
            if ((rect.right + buffer) < leftBound) return false;
            if ((rect.left - buffer) > rightBound) return false;
            if ((rect.bottom + buffer) < topBound) return false;
            if ((rect.top - buffer) > bottomBound) return false;
            return true;
        }

        function estimateInlineMetaHostSize(html) {
            const source = String(html || '');
            const chipCount = Math.max(1, (source.match(/sy-custom-props-inline-chip/g) || []).length);
            const text = source
                .replace(/<style[\s\S]*?<\/style>/gi, ' ')
                .replace(/<script[\s\S]*?<\/script>/gi, ' ')
                .replace(/<[^>]+>/g, ' ')
                .replace(/&nbsp;/g, ' ')
                .replace(/&[a-z0-9#]+;/gi, 'x')
                .replace(/\s+/g, ' ')
                .trim();
            const textWidth = Math.min(260, Math.max(0, text.length * 6));
            const chipChromeWidth = chipCount * 18 + Math.max(0, chipCount - 1) * 4;
            return {
                width: Math.max(56, Math.min(420, Math.ceil(textWidth + chipChromeWidth))),
                height: 22,
            };
        }

        function getInlineTextTailRect(textAnchor) {
            if (!textAnchor) return null;
            try {
                const walker = document.createTreeWalker(textAnchor, NodeFilter.SHOW_TEXT, {
                    acceptNode(node) {
                        const text = String(node?.nodeValue || '').replace(/\u200b/g, '').trim();
                        if (!text) return NodeFilter.FILTER_REJECT;
                        const parent = node.parentElement;
                        if (shouldRejectInlineTextParent(parent, textAnchor)) return NodeFilter.FILTER_REJECT;
                        return NodeFilter.FILTER_ACCEPT;
                    }
                });
                let lastTextNode = null;
                while (walker.nextNode()) lastTextNode = walker.currentNode;
                if (lastTextNode) {
                    const raw = String(lastTextNode.nodeValue || '');
                    const endOffset = raw.length;
                    if (endOffset > 0) {
                        const range = document.createRange();
                        range.setStart(lastTextNode, 0);
                        range.setEnd(lastTextNode, endOffset);
                        const rects = Array.from(range.getClientRects()).filter((rect) => rect && (rect.width || rect.height));
                        let tailRect = rects.length ? rects[rects.length - 1] : null;
                        if (!tailRect) {
                            const rect = range.getBoundingClientRect();
                            if (rect && (rect.width || rect.height)) tailRect = rect;
                        }
                        let inlineRect = null;
                        let probe = lastTextNode.parentElement;
                        while (probe && probe !== textAnchor) {
                            const style = window.getComputedStyle?.(probe);
                            const display = String(style?.display || '').toLowerCase();
                            if (display.startsWith('inline')) {
                                const rect = probe.getBoundingClientRect?.();
                                if (rect && (rect.width || rect.height)) {
                                    const sameLine = !tailRect || (
                                        rect.bottom >= (tailRect.top - 1)
                                        && rect.top <= (tailRect.bottom + 1)
                                    );
                                    if (sameLine && (!tailRect || rect.right >= (tailRect.right - 1))) {
                                        inlineRect = rect;
                                    }
                                }
                            }
                            probe = probe.parentElement;
                        }
                        if (inlineRect) return inlineRect;
                        if (tailRect) return tailRect;
                    }
                }
            } catch (e) {}
            return null;
        }

        function getInlinePlainText(textAnchor) {
            if (!textAnchor) return '';
            try {
                const walker = document.createTreeWalker(textAnchor, NodeFilter.SHOW_TEXT, {
                    acceptNode(node) {
                        const parent = node?.parentElement;
                        if (shouldRejectInlineTextParent(parent, textAnchor)) return NodeFilter.FILTER_REJECT;
                        return NodeFilter.FILTER_ACCEPT;
                    }
                });
                let out = '';
                while (walker.nextNode()) out += String(walker.currentNode?.nodeValue || '');
                return out.replace(/\u200b/g, '').trim();
            } catch (e) {
                return String(textAnchor.textContent || '').replace(/\u200b/g, '').trim();
            }
        }

        function getInlineTextFastSignature(textAnchor) {
            return getInlinePlainText(textAnchor);
        }

        function isInlineMetaEditingBlock(blockEl) {
            if (!blockEl) return false;
            try {
                const selection = window.getSelection?.();
                const anchorNode = selection?.anchorNode || null;
                const focusNode = selection?.focusNode || null;
                const anchorEl = anchorNode?.nodeType === Node.ELEMENT_NODE ? anchorNode : anchorNode?.parentElement;
                const focusEl = focusNode?.nodeType === Node.ELEMENT_NODE ? focusNode : focusNode?.parentElement;
                if (anchorEl && blockEl.contains(anchorEl)) return true;
                if (focusEl && blockEl.contains(focusEl)) return true;
            } catch (e) {}
            try {
                const active = document.activeElement;
                if (active && blockEl.contains(active)) return true;
            } catch (e) {}
            return false;
        }

        function isInlineMetaNativeHostUnsafeBlock(blockEl) {
            if (!blockEl || !QUICKBAR_INLINE_USE_NATIVE_HOST) return false;
            try {
                if (blockEl.matches?.('[data-editing="true"]')) return true;
                if (blockEl.closest?.('.list[data-editing="true"],[data-type="NodeList"][data-editing="true"]')) return true;
                if (blockEl.querySelector?.(':scope > .p[data-editing="true"], .p[data-editing="true"]')) return true;
            } catch (e) {}
            return inlineMetaIsComposing && isInlineMetaEditingBlock(blockEl);
        }

        async function handleInlineHostPointerDown(host, chip, event, fallbackBlockEl = null) {
            if (!host || !chip) return;
            event?.preventDefault?.();
            event?.stopPropagation?.();
            try { event?.stopImmediatePropagation?.(); } catch (err) {}
            inlineMetaInteractUntil = Date.now() + 500;
            const blockId = String(host.dataset.blockId || '').trim();
            const taskId = String(host.dataset.taskId || '').trim();
            const attrHostId = String(host.dataset.attrHostId || blockId).trim();
            const blockRef = getBlockElById(taskId) || getBlockElById(attrHostId) || getBlockElById(blockId) || host.__tmQuickbarInlineBlockEl || fallbackBlockEl;
            const attrKey = String(chip.dataset.inlineAttr || '').trim();
            const config = getInlineFieldConfig(attrKey);
            if (!blockRef || !config) {
                pushQuickbarInlineSyncLog('inline-chip-click-skip', {
                    reason: !blockRef ? 'missing-block-ref' : 'missing-config',
                    blockId,
                    sourceTaskId: taskId,
                    attrHostId,
                    attrKey,
                });
                return;
            }
            if (config.readonly || String(config.type || '').trim() === 'completed-time') {
                pushQuickbarInlineSyncLog('inline-chip-click-skip', {
                    reason: 'readonly',
                    blockId,
                    sourceTaskId: taskId,
                    attrHostId,
                    attrKey,
                    type: String(config.type || '').trim(),
                });
                return;
            }
            updateCurrentTaskContext(blockRef, attrHostId || blockId || String(blockRef.dataset.nodeId || '').trim());
            currentProps = await getTaskCustomProps(currentBlockId, false, { blockEl: blockRef });
            activePropConfig = config;
            const currentValue = String(chip.dataset.inlineValue || currentProps[attrKey] || '').trim();
            if (config.type === 'select' || config.type === 'multi-select') showSelectMenu(chip, config, currentValue);
            else if (config.type === 'date') showDateEditor(chip, config, currentValue);
            else if (config.type === 'focus-summary') showFocusSummaryEditor(chip, config);
            else showTextEditor(chip, config, currentValue);
        }
        inlineMetaHostPointerDownHandler = handleInlineHostPointerDown;

        function bindInlineHostPointerHandler(host, blockEl) {
            if (!host) return;
            host.__tmQuickbarInlineBlockEl = blockEl || null;
            if (host.__tmQuickbarInlineBound) return;
            host.__tmQuickbarInlineBound = true;
            host.addEventListener('pointerdown', (e) => {
                const rawTarget = e.target;
                const targetEl = rawTarget instanceof Element ? rawTarget : rawTarget?.parentElement;
                const chip = targetEl?.closest?.('.sy-custom-props-inline-chip');
                if (!chip) return;
                handleInlineHostPointerDown(host, chip, e, blockEl);
            }, true);
        }

        function getInlineNativeHostMount(blockEl) {
            if (!blockEl || blockEl.closest?.('.tm-task-detail-note-mount')) return null;
            const paragraph = blockEl.querySelector?.(':scope > .p') || blockEl.querySelector?.('.p') || null;
            if (!(paragraph instanceof Element)) return null;
            const attrHost = paragraph.querySelector?.(':scope > .protyle-attr') || null;
            if (!(attrHost instanceof Element)) return null;
            return { parent: attrHost, before: null, layoutParent: paragraph };
        }

        function ensureInlineHost(blockEl, options = {}) {
            const preferOverlay = !!(options && options.preferOverlay);
            const blockId = String(options?.blockId || resolveTaskAttrNodeIdForDetail(blockEl) || blockEl?.dataset?.nodeId || '').trim();
            if (!blockId) return null;
            const nativeMount = QUICKBAR_INLINE_USE_NATIVE_HOST ? getInlineNativeHostMount(blockEl) : null;
            if (QUICKBAR_INLINE_USE_NATIVE_HOST && !preferOverlay && nativeMount?.parent) {
                let host = null;
                let removedLegacyHosts = 0;
                try {
                    const escapedBlockId = CSS.escape(blockId);
                    blockEl.querySelectorAll?.(`.sy-custom-props-inline-host[data-inline-placement="in-block"][data-block-id="${escapedBlockId}"]`).forEach((node) => {
                        if (node?.parentElement === nativeMount.parent) return;
                        if (removeInlineMetaHostNode(node, true)) removedLegacyHosts += 1;
                    });
                } catch (e) {}
                const layoutParent = nativeMount.layoutParent || nativeMount.parent;
                try {
                    blockEl.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((node) => {
                        if (node === layoutParent) return;
                        if (!hasInlineMetaInBlockHost(node)) {
                            node.classList.remove('sy-custom-props-inline-parent');
                        }
                    });
                } catch (e) {}
                try { layoutParent.classList.add('sy-custom-props-inline-parent'); } catch (e) {}
                try {
                    host = nativeMount.parent.querySelector(`:scope > .sy-custom-props-inline-host[data-inline-placement="in-block"][data-block-id="${CSS.escape(blockId)}"]`);
                } catch (e) {
                    host = Array.from(nativeMount.parent.querySelectorAll?.(':scope > .sy-custom-props-inline-host[data-inline-placement="in-block"][data-block-id]') || [])
                        .find((el) => String(el?.dataset?.blockId || '').trim() === blockId) || null;
                }
                const createdHost = !host;
                const previousParentId = String(host?.parentElement?.dataset?.nodeId || '').trim();
                if (!host) {
                    host = document.createElement('span');
                    host.className = 'sy-custom-props-inline-host';
                    host.setAttribute('contenteditable', 'false');
                    host.setAttribute('data-inline-meta-host', 'true');
                    host.setAttribute('data-inline-placement', 'in-block');
                    host.setAttribute('data-block-id', blockId);
                    invalidateInlineMetaActiveTargetsCache();
                }
                bindInlineHostPointerHandler(host, blockEl);
                touchInlineMetaHost(host);
                host.__tmQuickbarInlineLayoutParent = layoutParent;
                const movedHost = host.parentElement !== nativeMount.parent || (nativeMount.before && host.nextSibling !== nativeMount.before);
                if (nativeMount.before && host.nextSibling !== nativeMount.before) nativeMount.parent.insertBefore(host, nativeMount.before);
                else if (!host.parentElement) nativeMount.parent.appendChild(host);
                if (createdHost || movedHost || removedLegacyHosts > 0) {
                    pushQuickbarInlineSyncLog('native-host-mount', {
                        taskId: String(blockEl?.dataset?.nodeId || '').trim(),
                        blockId,
                        created: createdHost,
                        moved: movedHost,
                        previousParentId,
                        parentTag: String(nativeMount.parent?.tagName || '').toLowerCase(),
                        parentClass: String(nativeMount.parent?.className || '').trim(),
                        parentType: String(nativeMount.parent?.getAttribute?.('data-type') || '').trim(),
                        parentId: String(nativeMount.parent?.dataset?.nodeId || '').trim(),
                        layoutParentClass: String(layoutParent?.className || '').trim(),
                        layoutParentType: String(layoutParent?.getAttribute?.('data-type') || '').trim(),
                        layoutParentId: String(layoutParent?.dataset?.nodeId || '').trim(),
                        beforeClass: String(nativeMount.before?.className || '').trim(),
                        removedLegacyHosts,
                    });
                }
                try {
                    document.querySelectorAll(`.sy-custom-props-inline-layer .sy-custom-props-inline-host[data-block-id="${CSS.escape(blockId)}"]`).forEach((node) => removeInlineMetaHostNode(node, true));
                } catch (e) {}
                return host;
            }
            removeInlineMetaHostByTaskId(blockId, 'in-block');
            try {
                blockEl.querySelectorAll?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((node) => removeInlineMetaHostNode(node, true));
                blockEl.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((node) => {
                    if (!hasInlineMetaInBlockHost(node)) {
                        node.classList.remove('sy-custom-props-inline-parent');
                    }
                });
            } catch (e) {}
            const layer = ensureInlineMetaLayer(blockEl);
            if (!layer) return null;
            let host = layer.querySelector(`.sy-custom-props-inline-host[data-block-id="${blockId}"]`);
            if (!host) {
                host = document.createElement('span');
                host.className = 'sy-custom-props-inline-host';
                host.setAttribute('contenteditable', 'false');
                host.setAttribute('data-inline-meta-host', 'true');
                host.setAttribute('data-inline-placement', 'overlay');
                host.setAttribute('data-block-id', blockId);
                invalidateInlineMetaActiveTargetsCache();
                layer.appendChild(host);
            }
            bindInlineHostPointerHandler(host, blockEl);
            touchInlineMetaHost(host);
            return host;
        }

        function getInlineVisibleTaskBlocks(buffer = 360, maxCount = 96) {
            return getInlineDirectionalTaskBlocks(buffer, buffer, maxCount);
        }

        function scheduleInlineMetaQueueDrain(delayMs = 0) {
            if (inlineMetaRenderQueueTimer) return;
            const delay = Math.max(0, Number(delayMs) || 0);
            // delayMs === 0 → align to the next animation frame; this lets
            // a frame's worth of cache-hit renders drain together instead
            // of crawling through one setTimeout(16) hop per batch. Any
            // explicit delay still uses setTimeout (used by the in-flight
            // re-schedule that lets fetches resolve between batches).
            if (delay === 0 && typeof requestAnimationFrame === 'function') {
                inlineMetaRenderQueueIsRaf = true;
                inlineMetaRenderQueueTimer = requestAnimationFrame(() => {
                    inlineMetaRenderQueueTimer = 0;
                    inlineMetaRenderQueueIsRaf = false;
                    drainInlineMetaRenderQueue();
                });
                return;
            }
            inlineMetaRenderQueueIsRaf = false;
            inlineMetaRenderQueueTimer = setTimeout(() => {
                inlineMetaRenderQueueTimer = 0;
                drainInlineMetaRenderQueue();
            }, delay);
        }

        function queueInlineMetaRenderBlock(blockEl, forceRefresh = false, visibilityBuffer = 0) {
            const taskId = String(resolveTaskAttrNodeIdForDetail(blockEl) || blockEl?.dataset?.nodeId || '').trim();
            if (!taskId || inlineMetaRenderQueueIds.has(taskId) || inlineMetaRenderActiveIds.has(taskId)) return false;
            inlineMetaRenderQueueIds.add(taskId);
            inlineMetaRenderQueue.push({ blockEl, taskId, forceRefresh: !!forceRefresh, visibilityBuffer });
            scheduleInlineMetaQueueDrain(0);
            return true;
        }

        function drainInlineMetaRenderQueue() {
            if (!inlineMetaStarted || !isInlineMetaEnabled()) {
                inlineMetaRenderQueue = [];
                inlineMetaRenderQueueIds.clear();
                inlineMetaRenderActiveIds.clear();
                return;
            }
            // Process at least BATCH_LIMIT items unconditionally to keep
            // small bursts (e.g. attr-updated for a handful of tasks)
            // single-frame. Beyond that, drain until ~4 ms of synchronous
            // work has elapsed — cache-hit-only renders (~0.1 ms each)
            // can clear a queue of dozens within a single frame, while
            // slow-path renders still respect the frame budget.
            const now = () => ((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now());
            const startTs = now();
            const frameBudgetMs = 4;
            const lightDrain = isInlineMetaScrollSettling() || Date.now() < Number(inlineMetaRecentStructuralUntil || 0);
            const batchLimit = lightDrain
                ? Math.min(4, QUICKBAR_INLINE_RENDER_BATCH_LIMIT)
                : QUICKBAR_INLINE_RENDER_BATCH_LIMIT;
            let count = 0;
            const initialQueueLength = inlineMetaRenderQueue.length;
            while (inlineMetaRenderQueue.length) {
                if (count >= batchLimit && (now() - startTs) >= frameBudgetMs) break;
                const item = inlineMetaRenderQueue.shift();
                inlineMetaRenderQueueIds.delete(item.taskId);
                if (!item.blockEl?.isConnected || inlineMetaRenderActiveIds.has(item.taskId)) continue;
                inlineMetaRenderActiveIds.add(item.taskId);
                count += 1;
                Promise.resolve(renderInlineMetaForBlock(item.blockEl, item.forceRefresh, item.visibilityBuffer))
                    .catch(() => null)
                    .finally(() => {
                        inlineMetaRenderActiveIds.delete(item.taskId);
                        if (inlineMetaRenderQueue.length) scheduleInlineMetaQueueDrain(0);
                    });
            }
            if (inlineMetaRenderQueue.length) scheduleInlineMetaQueueDrain(0);
            const duration = now() - startTs;
            if (duration > 16 || initialQueueLength > 80 || inlineMetaRenderQueue.length > 80) {
                pushQuickbarPerfProbe('render-queue', {
                    durationMs: Math.round(duration),
                    processed: count,
                    initialQueueLength,
                    remainingQueueLength: inlineMetaRenderQueue.length,
                    activeCount: inlineMetaRenderActiveIds.size,
                    scrolling: !!inlineMetaScrolling,
                }, { throttleMs: 800 });
            }
        }

        function getInlineDirectionalTaskBlocks(upBuffer = 360, downBuffer = 360, maxCount = 96, preferVisible = false) {
            const viewportTop = 0 - Math.max(0, Number(upBuffer) || 0);
            const viewportBottom = (window.innerHeight || document.documentElement?.clientHeight || 0) + Math.max(0, Number(downBuffer) || 0);
            // Always source from the observed set. The IO-driven visible
            // set lags behind reality on tab switches (IO entries are
            // delivered async; the newly-activated tab's blocks aren't
            // in visible yet, while the previously-active tab's blocks
            // may still linger). Driving keepBlocks/coreBlocks from the
            // lagged visible set caused prune to evict hosts of the
            // active tab right after a switch, and the user only saw
            // them reappear once a mouseover re-triggered render. The
            // observed set is updated synchronously by sync, so it
            // always reflects the currently-active protyles. The rect
            // filter below caps the work to blocks near the viewport.
            const sourceMap = preferVisible && inlineMetaVisibleTaskBlocks.size
                ? inlineMetaVisibleTaskBlocks
                : inlineMetaObservedTaskBlocks;
            const sourceBlocks = Array.from(sourceMap.values());
            const out = [];
            const seen = new Set();
            for (let i = 0; i < sourceBlocks.length; i += 1) {
                const blockEl = sourceBlocks[i];
                const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                if (!blockId || seen.has(blockId)) continue;
                seen.add(blockId);
                if (!isTaskBlockElement(blockEl)) continue;
                try {
                    const rect = blockEl.getBoundingClientRect();
                    if (!rect) continue;
                    if (rect.bottom < viewportTop) continue;
                    if (rect.top > viewportBottom) continue;
                    out.push(blockEl);
                    if (out.length >= maxCount) return sortInlineMetaBlocksByViewportPriority(out);
                } catch (e) {}
            }
            return sortInlineMetaBlocksByViewportPriority(out);
        }

        function getInlineTaskBlockBuckets(dir) {
            const viewportHeight = window.innerHeight || document.documentElement?.clientHeight || 0;
            const coreUp = dir > 0 ? 320 : (dir < 0 ? 900 : 520);
            const coreDown = dir > 0 ? 900 : (dir < 0 ? 320 : 520);
            const preUp = dir > 0 ? 900 : (dir < 0 ? 3200 : 2200);
            const preDown = dir > 0 ? 3200 : (dir < 0 ? 900 : 2200);
            const keepUp = dir > 0 ? 1400 : (dir < 0 ? 4200 : 3200);
            const keepDown = dir > 0 ? 4200 : (dir < 0 ? 1400 : 3200);
            // Always source from observed (see getInlineDirectionalTaskBlocks
            // for rationale). Prune and keep decisions need a synchronously-
            // accurate picture of the active tab's blocks; the IO-driven
            // visible set lags on tab switches.
            const sourceBlocks = Array.from(inlineMetaObservedTaskBlocks.values());
            const buckets = { viewportBlocks: [], coreBlocks: [], preRenderBlocks: [], keepBlocks: [] };
            const seen = new Set();
            for (let i = 0; i < sourceBlocks.length; i += 1) {
                const blockEl = sourceBlocks[i];
                const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                if (!blockId || seen.has(blockId)) continue;
                seen.add(blockId);
                if (!isTaskBlockElement(blockEl)) continue;
                try {
                    const rect = blockEl.getBoundingClientRect();
                    if (!rect) continue;
                    if (rect.bottom >= -keepUp && rect.top <= viewportHeight + keepDown) {
                        if (buckets.keepBlocks.length < 420) buckets.keepBlocks.push(blockEl);
                    }
                    if (rect.bottom >= -preUp && rect.top <= viewportHeight + preDown) {
                        if (buckets.preRenderBlocks.length < 220) buckets.preRenderBlocks.push(blockEl);
                    }
                    if (rect.bottom >= -coreUp && rect.top <= viewportHeight + coreDown) {
                        if (buckets.coreBlocks.length < 160) buckets.coreBlocks.push(blockEl);
                    }
                    if (rect.bottom >= 0 && rect.top <= viewportHeight) {
                        if (buckets.viewportBlocks.length < 96) buckets.viewportBlocks.push(blockEl);
                    }
                } catch (e) {}
            }
            sortInlineMetaBlocksByViewportPriority(buckets.viewportBlocks);
            sortInlineMetaBlocksByViewportPriority(buckets.coreBlocks);
            sortInlineMetaBlocksByViewportPriority(buckets.preRenderBlocks);
            sortInlineMetaBlocksByViewportPriority(buckets.keepBlocks);
            return buckets;
        }

        function getInlineScrollPositionFromEventTarget(target) {
            try {
                if (target === window || target === document || target === document.body || target === document.documentElement) {
                    return Number(window.scrollY || document.documentElement?.scrollTop || document.body?.scrollTop || 0);
                }
                const el = target instanceof Element ? target : null;
                if (!el) return Number(window.scrollY || document.documentElement?.scrollTop || 0);
                if (typeof el.scrollTop === 'number' && el.scrollHeight > el.clientHeight) return Number(el.scrollTop || 0);
            } catch (e) {}
            return Number(window.scrollY || document.documentElement?.scrollTop || 0);
        }

        function getInlineMetaViewportPriority(blockEl) {
            if (!(blockEl instanceof Element)) return Number.MAX_SAFE_INTEGER;
            try {
                const viewportHeight = window.innerHeight || document.documentElement?.clientHeight || 0;
                const rect = blockEl.getBoundingClientRect?.();
                if (!rect) return Number.MAX_SAFE_INTEGER;
                const intersectsViewport = rect.bottom >= 0 && rect.top <= viewportHeight;
                const edgeDistance = rect.bottom < 0
                    ? Math.abs(rect.bottom)
                    : (rect.top > viewportHeight ? rect.top - viewportHeight : 0);
                const centerDistance = Math.abs(((rect.top + rect.bottom) / 2) - (viewportHeight / 2));
                return (intersectsViewport ? 0 : 100000) + edgeDistance + (centerDistance / 1000);
            } catch (e) {
                return Number.MAX_SAFE_INTEGER;
            }
        }

        function sortInlineMetaBlocksByViewportPriority(blocks) {
            if (!Array.isArray(blocks) || blocks.length < 2) return blocks;
            try {
                blocks.sort((a, b) => getInlineMetaViewportPriority(a) - getInlineMetaViewportPriority(b));
            } catch (e) {}
            return blocks;
        }

        function collectInlineMetaOwnerIds(blockEl) {
            const ids = new Set();
            if (!(blockEl instanceof Element)) return ids;
            try {
                const binding = resolveTaskBindingFromBlockEl(blockEl);
                const taskId = String(binding?.taskId || '').trim();
                const attrHostId = String(binding?.attrHostId || '').trim();
                if (taskId) ids.add(taskId);
                if (attrHostId) ids.add(attrHostId);
            } catch (e) {}
            try {
                const directId = String(blockEl?.dataset?.nodeId || blockEl?.getAttribute?.('data-node-id') || '').trim();
                if (directId) ids.add(directId);
            } catch (e) {}
            return ids;
        }

        function collectInlineMetaRetainIds(extraBlocks = []) {
            const ids = new Set();
            const pushId = (value) => {
                const id = String(value || '').trim();
                if (id) ids.add(id);
            };
            pushId(currentBlockId);
            pushId(currentTaskId);
            try { inlineMetaRenderQueueIds.forEach(pushId); } catch (e) {}
            try { inlineMetaRenderActiveIds.forEach(pushId); } catch (e) {}
            try {
                (Array.isArray(extraBlocks) ? extraBlocks : []).forEach((blockEl) => {
                    collectInlineMetaOwnerIds(blockEl).forEach(pushId);
                });
            } catch (e) {}
            try {
                inlineMetaVisibleTaskBlocks.forEach((blockEl, blockId) => {
                    pushId(blockId);
                    collectInlineMetaOwnerIds(blockEl).forEach(pushId);
                });
            } catch (e) {}
            try {
                document.querySelectorAll('.sy-custom-props-inline-host[data-block-id]').forEach((host) => {
                    pushId(host?.dataset?.blockId);
                    pushId(host?.dataset?.taskId);
                    pushId(host?.dataset?.attrHostId);
                });
            } catch (e) {}
            return ids;
        }

        function pruneInlineMetaPropsCache(now, retainIds) {
            try {
                Array.from(inlineMetaCache.keys()).forEach((id) => {
                    const key = String(id || '').trim();
                    if (!key) {
                        inlineMetaCache.delete(id);
                        return;
                    }
                    if (retainIds?.has(key)) return;
                    const ts = Number(inlineMetaCacheTs.get(key) || 0);
                    if (!ts || (now - ts) > QUICKBAR_INLINE_CACHE_TTL_MS) {
                        inlineMetaCache.delete(key);
                        inlineMetaCacheTs.delete(key);
                    }
                });
                inlineMetaCacheTs.forEach((_, id) => {
                    if (!inlineMetaCache.has(id)) inlineMetaCacheTs.delete(id);
                });
                if (inlineMetaCache.size <= QUICKBAR_INLINE_CACHE_SOFT_LIMIT) return;
                const entries = Array.from(inlineMetaCache.keys())
                    .map((id) => String(id || '').trim())
                    .filter((id) => id && !retainIds?.has(id))
                    .map((id) => ({ id, ts: Number(inlineMetaCacheTs.get(id) || 0) || 0 }))
                    .sort((a, b) => a.ts - b.ts);
                for (let i = 0; inlineMetaCache.size > QUICKBAR_INLINE_CACHE_SOFT_LIMIT && i < entries.length; i += 1) {
                    inlineMetaCache.delete(entries[i].id);
                    inlineMetaCacheTs.delete(entries[i].id);
                }
            } catch (e) {}
        }

        function pruneInlineMetaLayoutRuntimeCache(now, retainIds) {
            try {
                inlineMetaLayoutCache.forEach((entry, id) => {
                    const key = String(id || '').trim();
                    if (!key) {
                        inlineMetaLayoutCache.delete(id);
                        return;
                    }
                    if (retainIds?.has(key)) return;
                    const ts = Number(entry?.ts || 0);
                    if (!ts || (now - ts) > QUICKBAR_INLINE_CACHE_TTL_MS) {
                        inlineMetaLayoutCache.delete(key);
                    }
                });
                if (inlineMetaLayoutCache.size <= QUICKBAR_INLINE_LAYOUT_CACHE_SOFT_LIMIT) return;
                const entries = Array.from(inlineMetaLayoutCache.entries())
                    .map(([id, entry]) => ({ id: String(id || '').trim(), ts: Number(entry?.ts || 0) || 0 }))
                    .filter((entry) => entry.id && !retainIds?.has(entry.id))
                    .sort((a, b) => a.ts - b.ts);
                for (let i = 0; inlineMetaLayoutCache.size > QUICKBAR_INLINE_LAYOUT_CACHE_SOFT_LIMIT && i < entries.length; i += 1) {
                    inlineMetaLayoutCache.delete(entries[i].id);
                }
            } catch (e) {}
        }

        function pruneInlineMetaTimestampMap(map, now, maxAgeMs, limit, retainIds = null) {
            if (!(map instanceof Map)) return;
            try {
                map.forEach((value, id) => {
                    const key = String(id || '').trim();
                    if (!key) {
                        map.delete(id);
                        return;
                    }
                    if (retainIds?.has(key)) return;
                    const ts = Number(value || 0);
                    if (!ts || (now - ts) > maxAgeMs) map.delete(key);
                });
                if (map.size <= limit) return;
                const entries = Array.from(map.entries())
                    .map(([id, value]) => ({ id: String(id || '').trim(), ts: Number(value || 0) || 0 }))
                    .filter((entry) => entry.id && !retainIds?.has(entry.id))
                    .sort((a, b) => a.ts - b.ts);
                for (let i = 0; map.size > limit && i < entries.length; i += 1) {
                    map.delete(entries[i].id);
                }
            } catch (e) {}
        }

        function pruneInlineMetaOptimisticPatches(now, retainIds) {
            try {
                inlineMetaOptimisticPatches.forEach((entry, id) => {
                    const key = String(id || '').trim();
                    if (!key) {
                        inlineMetaOptimisticPatches.delete(id);
                        return;
                    }
                    const expiresAt = Number(entry?.expiresAt || 0);
                    if (!expiresAt || expiresAt <= now) inlineMetaOptimisticPatches.delete(key);
                });
                if (inlineMetaOptimisticPatches.size <= QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT) return;
                const entries = Array.from(inlineMetaOptimisticPatches.entries())
                    .map(([id, entry]) => ({ id: String(id || '').trim(), ts: Number(entry?.expiresAt || 0) || 0 }))
                    .filter((entry) => entry.id && !retainIds?.has(entry.id))
                    .sort((a, b) => a.ts - b.ts);
                for (let i = 0; inlineMetaOptimisticPatches.size > QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT && i < entries.length; i += 1) {
                    inlineMetaOptimisticPatches.delete(entries[i].id);
                }
            } catch (e) {}
        }

        function pruneInlineMetaNativeHostSuppression(now, retainIds) {
            try {
                inlineMetaNativeHostSuppressedUntil.forEach((until, id) => {
                    const key = String(id || '').trim();
                    if (!key) {
                        inlineMetaNativeHostSuppressedUntil.delete(id);
                        return;
                    }
                    if (Number(until || 0) <= now) inlineMetaNativeHostSuppressedUntil.delete(key);
                });
                if (inlineMetaNativeHostSuppressedUntil.size <= QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT) return;
                const entries = Array.from(inlineMetaNativeHostSuppressedUntil.entries())
                    .map(([id, until]) => ({ id: String(id || '').trim(), ts: Number(until || 0) || 0 }))
                    .filter((entry) => entry.id && !retainIds?.has(entry.id))
                    .sort((a, b) => a.ts - b.ts);
                for (let i = 0; inlineMetaNativeHostSuppressedUntil.size > QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT && i < entries.length; i += 1) {
                    inlineMetaNativeHostSuppressedUntil.delete(entries[i].id);
                }
            } catch (e) {}
        }

        function pruneInlineMetaRuntimeCaches(force = false, extraRetainBlocks = []) {
            const now = Date.now();
            if (!force && (now - Number(inlineMetaLastRuntimePruneAt || 0)) < QUICKBAR_INLINE_RUNTIME_PRUNE_INTERVAL_MS) return;
            inlineMetaLastRuntimePruneAt = now;
            const retainIds = collectInlineMetaRetainIds(extraRetainBlocks);
            pruneInlineMetaPropsCache(now, retainIds);
            pruneInlineMetaLayoutRuntimeCache(now, retainIds);
            pruneInlineMetaOptimisticPatches(now, retainIds);
            pruneInlineMetaNativeHostSuppression(now, retainIds);
            pruneInlineMetaTimestampMap(inlineMetaMissingHostSeenAt, now, QUICKBAR_INLINE_MISC_CACHE_TTL_MS, QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT, retainIds);
            pruneInlineMetaTimestampMap(quickbarAttrHostMigrationSeenAt, now, QUICKBAR_INLINE_MISC_CACHE_TTL_MS, QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT, retainIds);
            pruneInlineMetaTimestampMap(quickbarAttrHostMirrorSyncSeenAt, now, QUICKBAR_INLINE_MISC_CACHE_TTL_MS, QUICKBAR_INLINE_MISC_CACHE_SOFT_LIMIT, retainIds);
        }

        function clearInlineMetaRuntimeCaches() {
            try { inlineMetaCache.clear(); } catch (e) {}
            try { inlineMetaCacheTs.clear(); } catch (e) {}
            try { inlineMetaOptimisticPatches.clear(); } catch (e) {}
            try { inlineMetaLayoutCache.clear(); } catch (e) {}
            try { inlineMetaPropsInflight.clear(); } catch (e) {}
            try { inlineMetaMissingHostSeenAt.clear(); } catch (e) {}
            try { inlineMetaNativeHostSuppressedUntil.clear(); } catch (e) {}
            try { inlineMetaSourceHostDedupeSeenAt.clear(); } catch (e) {}
            try { quickbarAttrHostMigrationSeenAt.clear(); } catch (e) {}
            try { quickbarAttrHostMirrorSyncSeenAt.clear(); } catch (e) {}
            try { quickbarAttrHostDragSnapshots.clear(); } catch (e) {}
            inlineMetaPrefetchQueue = [];
            inlineMetaPrefetchQueuedIds.clear();
            inlineMetaPrefetchActiveCount = 0;
            inlineMetaLastRuntimePruneAt = 0;
            inlineMetaScopeDocIds = null;
            inlineMetaScopeDocIdsTs = 0;
            inlineMetaScopeDocIdsPromise = null;
            inlineMetaActiveTargetsCacheTs = 0;
            inlineMetaActiveTargetsCacheValue = false;
        }

        function getQuickbarInlineStats() {
            let hosts = [];
            let layers = [];
            let parents = [];
            let protyles = [];
            try { hosts = Array.from(document.querySelectorAll('.sy-custom-props-inline-host')); } catch (e) { hosts = []; }
            try { layers = Array.from(document.querySelectorAll('.sy-custom-props-inline-layer')); } catch (e) { layers = []; }
            try { parents = Array.from(document.querySelectorAll('.sy-custom-props-inline-parent')); } catch (e) { parents = []; }
            try { protyles = Array.from(document.querySelectorAll('.protyle')); } catch (e) { protyles = []; }
            const inBlockHosts = hosts.filter((host) => String(host?.dataset?.inlinePlacement || '').trim() === 'in-block');
            const overlayHosts = hosts.filter((host) => String(host?.dataset?.inlinePlacement || '').trim() === 'overlay' || host?.closest?.('.sy-custom-props-inline-layer'));
            const readyHosts = hosts.filter((host) => host?.classList?.contains('is-ready'));
            const activeRoots = new Set(inlineMetaObservedRoots);
            const activeHostCount = hosts.filter((host) => {
                const protyle = host?.closest?.('.protyle');
                return !!(protyle && activeRoots.has(protyle));
            }).length;
            return {
                enabled: isInlineMetaEnabled(),
                started: !!inlineMetaStarted,
                hosts: hosts.length,
                inBlockHosts: inBlockHosts.length,
                overlayHosts: overlayHosts.length,
                readyHosts: readyHosts.length,
                activeHostCount,
                layers: layers.length,
                inlineParents: parents.length,
                protyles: protyles.length,
                observedRoots: inlineMetaObservedRoots.length,
                observedBlocks: inlineMetaObservedTaskBlocks.size,
                visibleBlocks: inlineMetaVisibleTaskBlocks.size,
                renderQueue: inlineMetaRenderQueue.length,
                renderQueueIds: inlineMetaRenderQueueIds.size,
                renderActiveIds: inlineMetaRenderActiveIds.size,
                propsCache: inlineMetaCache.size,
                propsCacheTs: inlineMetaCacheTs.size,
                layoutCache: inlineMetaLayoutCache.size,
                propsInflight: inlineMetaPropsInflight.size,
                optimisticPatches: inlineMetaOptimisticPatches.size,
                missingHostSeen: inlineMetaMissingHostSeenAt.size,
                nativeHostSuppressed: inlineMetaNativeHostSuppressedUntil.size,
                migrationSeen: quickbarAttrHostMigrationSeenAt.size,
                dragSnapshots: quickbarAttrHostDragSnapshots.size,
            };
        }

        function applyInlineMetaStructuralInvalidation(topmostAffected = null) {
            if (topmostAffected instanceof Element) {
                try {
                    const stale = [];
                    inlineMetaLayoutCache.forEach((_, taskId) => {
                        const blockEl = inlineMetaObservedTaskBlocks.get(taskId);
                        if (!(blockEl instanceof Element) || !blockEl.isConnected) {
                            stale.push(taskId);
                            return;
                        }
                        if (blockEl === topmostAffected || topmostAffected.contains(blockEl) || blockEl.contains(topmostAffected)) {
                            stale.push(taskId);
                        }
                    });
                    stale.forEach((taskId) => inlineMetaLayoutCache.delete(taskId));
                    return;
                } catch (e) {}
            }
        }

        function rememberInlineMetaDeferredStructuralAnchor(topmostAffected = null) {
            inlineMetaDeferredStructural = true;
            if (!(topmostAffected instanceof Element) || !topmostAffected.isConnected) {
                inlineMetaDeferredStructuralAnchor = null;
                return;
            }
            if (!(inlineMetaDeferredStructuralAnchor instanceof Element) || !inlineMetaDeferredStructuralAnchor.isConnected) {
                inlineMetaDeferredStructuralAnchor = topmostAffected;
                return;
            }
            try {
                if (topmostAffected.compareDocumentPosition(inlineMetaDeferredStructuralAnchor) & Node.DOCUMENT_POSITION_FOLLOWING) {
                    inlineMetaDeferredStructuralAnchor = topmostAffected;
                }
            } catch (e) {
                inlineMetaDeferredStructuralAnchor = null;
            }
        }

        function scheduleInlineMetaDeferredPrune() {
            if (inlineMetaDeferredPruneTimer || !inlineMetaStarted) return;
            const delay = Math.max(24, inlineMetaRecentScrollUntil - Date.now() + 24);
            inlineMetaDeferredPruneTimer = setTimeout(() => {
                inlineMetaDeferredPruneTimer = 0;
                if (!inlineMetaStarted || !isInlineMetaEnabled()) return;
                if (Date.now() < inlineMetaRecentScrollUntil) {
                    scheduleInlineMetaDeferredPrune();
                    return;
                }
                const hadDeferredStructural = !!inlineMetaDeferredStructural;
                if (inlineMetaDeferredStructural) {
                    applyInlineMetaStructuralInvalidation(inlineMetaDeferredStructuralAnchor);
                    inlineMetaDeferredStructural = false;
                    inlineMetaDeferredStructuralAnchor = null;
                }
                let shouldCompactHosts = false;
                try {
                    shouldCompactHosts = document.querySelectorAll('.sy-custom-props-inline-host').length > QUICKBAR_INLINE_DOM_HOST_SOFT_LIMIT;
                } catch (e) {}
                if (!hadDeferredStructural && !shouldCompactHosts) return;
                inlineMetaNeedSyncBlocks = true;
                requestInlineMetaRender(false);
            }, delay);
        }

        function pruneInlineMetaOutsideViewport(keepBlocks) {
            // Defer pruning during active scroll. Removing a host here and
            // recreating it on the next render frame leaves a one-frame
            // gap where the freshly-created host has no is-ready class —
            // that's the chip flicker the user sees. SiYuan transiently
            // detaches blocks during lazy-render scrolling, which
            // shrinks keepBlocks below its true size; pruning on that
            // shrunken set would evict hosts we're about to need again.
            // The scroll-idle render pass runs this same prune with a
            // stable keep set.
            if (inlineMetaScrolling) return;
            // Also defer for a grace window after the most recent scroll
            // event. Back-and-forth scrolling typically pauses 200–500ms
            // at the direction reversal — that crosses the 150ms
            // scroll-idle threshold and would fire prune mid-pause. The
            // reverse scroll then has to rebuild any chip whose owner
            // sat just outside the keep zone. Extending the prune
            // deferral past the layout-idle threshold lets the user
            // oscillate freely without losing edge hosts.
            if (Date.now() < inlineMetaRecentScrollUntil) {
                scheduleInlineMetaDeferredPrune();
                return;
            }
            const keepIds = new Set();
            (keepBlocks || []).forEach((blockEl) => {
                collectInlineMetaOwnerIds(blockEl).forEach((id) => keepIds.add(id));
            });
            // Evict hosts outside the keep zone in active protyles. Hidden
            // tabs get a short grace window, then participate once the DOM
            // budget is exceeded so long browsing sessions don't retain one
            // chip node for every task the user has ever scrolled past.
            const activeProtyles = new Set(inlineMetaObservedRoots);
            try {
                const now = Date.now();
                let removed = 0;
                const hosts = Array.from(document.querySelectorAll('.sy-custom-props-inline-host'));
                const shouldPruneInactiveHosts = hosts.length > QUICKBAR_INLINE_DOM_HOST_SOFT_LIMIT;
                const removeHost = (host) => {
                    if (removeInlineMetaHostNode(host, true)) removed += 1;
                };
                hosts.forEach((host) => {
                    if (!(host instanceof HTMLElement)) return;
                    const owner = String(host?.dataset?.blockId || '').trim();
                    if (!owner || keepIds.has(owner)) return;
                    const protyleEl = host.closest?.('.protyle');
                    const activeProtyleHost = !!(protyleEl && activeProtyles.has(protyleEl));
                    const touchedAt = Number(host?.dataset?.inlineTouchedAt || 0);
                    const hostAgeMs = touchedAt ? (now - touchedAt) : Number.POSITIVE_INFINITY;
                    if (!activeProtyleHost) {
                        if (!shouldPruneInactiveHosts) return;
                        if (hostAgeMs < QUICKBAR_INLINE_INACTIVE_HOST_TTL_MS && hosts.length <= QUICKBAR_INLINE_DOM_HOST_HARD_LIMIT) return;
                    }
                    if (String(host?.dataset?.inlinePlacement || '').trim() === 'in-block') {
                        const blockEl = host.__tmQuickbarInlineBlockEl
                            || getTaskBlockElementFromTarget(host)
                            || host.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                        if (blockEl && isInlineMetaEditingBlock(blockEl)) return;
                    }
                    removeHost(host);
                });
                let liveHostCount = hosts.length - removed;
                if (liveHostCount > QUICKBAR_INLINE_DOM_HOST_HARD_LIMIT) {
                    const candidates = Array.from(document.querySelectorAll('.sy-custom-props-inline-host[data-block-id]'))
                        .filter((host) => {
                            if (!(host instanceof HTMLElement)) return false;
                            const owner = String(host?.dataset?.blockId || '').trim();
                            if (!owner || keepIds.has(owner)) return false;
                            const blockEl = host.__tmQuickbarInlineBlockEl
                                || getTaskBlockElementFromTarget(host)
                                || host.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                            if (String(host?.dataset?.inlinePlacement || '').trim() === 'in-block' && blockEl && isInlineMetaEditingBlock(blockEl)) return false;
                            return true;
                        })
                        .sort((a, b) => (Number(a?.dataset?.inlineTouchedAt || 0) || 0) - (Number(b?.dataset?.inlineTouchedAt || 0) || 0));
                    for (let i = 0; liveHostCount > QUICKBAR_INLINE_DOM_HOST_SOFT_LIMIT && i < candidates.length; i += 1) {
                        const beforeRemoved = removed;
                        removeHost(candidates[i]);
                        if (removed > beforeRemoved) liveHostCount -= 1;
                    }
                }
                if (removed > 0) invalidateInlineMetaActiveTargetsCache();
            } catch (e) {}
            pruneInlineMetaRuntimeCaches(false, keepBlocks);
        }

        function getInlineMetaNow() {
            try {
                if (typeof performance !== 'undefined' && typeof performance.now === 'function') return performance.now();
            } catch (e) {}
            return Date.now();
        }

        function isInlineMetaNativeHostLocallyAnchored(host, owner, hostTaskId) {
            if (!(host instanceof HTMLElement)) return false;
            if (String(host?.dataset?.inlinePlacement || '').trim() !== 'in-block') return false;
            const parent = host.parentElement;
            if (!(parent instanceof Element) || !parent.classList?.contains('protyle-attr')) return false;
            const blockEl = host.closest?.('.li[data-node-id], [data-type="NodeListItem"][data-node-id]');
            if (!(blockEl instanceof Element) || !blockEl.contains(host)) return false;
            const blockId = String(blockEl?.dataset?.nodeId || blockEl?.getAttribute?.('data-node-id') || '').trim();
            if (!blockId) return false;
            return blockId === owner || blockId === hostTaskId;
        }

        function pruneInlineMetaInvalidHosts(reason = '') {
            if (isInlineMetaScrollSettling()) return 0;
            const now = Date.now();
            const reasonKey = String(reason || '').trim();
            const hasRecentStructuralChange = quickbarAttrHostDragActive
                || (now - Number(quickbarAttrHostLastStructuralAt || 0)) < 5000
                || (now - Number(quickbarAttrHostLastDragAt || 0)) < 2500;
            const shouldDeepValidateNativeHosts = hasRecentStructuralChange
                || reasonKey === 'structural-change'
                || reasonKey === 'attr-write'
                || reasonKey === 'drag-end';
            const minInterval = shouldDeepValidateNativeHosts
                ? QUICKBAR_INLINE_INVALID_HOST_PRUNE_DEEP_INTERVAL_MS
                : (reasonKey === 'render-force'
                    ? QUICKBAR_INLINE_INVALID_HOST_PRUNE_FORCE_INTERVAL_MS
                    : QUICKBAR_INLINE_INVALID_HOST_PRUNE_INTERVAL_MS);
            if ((now - Number(inlineMetaLastInvalidHostPruneAt || 0)) < minInterval) return 0;
            inlineMetaLastInvalidHostPruneAt = now;
            const activeProtyles = new Set(inlineMetaObservedRoots);
            let removed = 0;
            try {
                const hosts = Array.from(document.querySelectorAll('.sy-custom-props-inline-host[data-block-id]'));
                const total = hosts.length;
                if (!total) {
                    inlineMetaInvalidHostPruneCursor = 0;
                    return 0;
                }
                const startIndex = inlineMetaInvalidHostPruneCursor >= 0 && inlineMetaInvalidHostPruneCursor < total
                    ? inlineMetaInvalidHostPruneCursor
                    : 0;
                const deadline = getInlineMetaNow() + QUICKBAR_INLINE_INVALID_HOST_PRUNE_TIME_BUDGET_MS;
                let visited = 0;
                let slowChecks = 0;
                let reachedBudget = false;
                for (let offset = 0; offset < total; offset += 1) {
                    const index = (startIndex + offset) % total;
                    const host = hosts[index];
                    visited += 1;
                    if (visited > QUICKBAR_INLINE_INVALID_HOST_PRUNE_VISIT_LIMIT
                        || (visited > 1 && (visited % 64) === 0 && getInlineMetaNow() >= deadline)) {
                        reachedBudget = true;
                        break;
                    }
                    if (!(host instanceof HTMLElement)) continue;
                    const owner = String(host.dataset.blockId || '').trim();
                    if (!owner) continue;
                    const protyleEl = host.closest?.('.protyle');
                    if (protyleEl && inlineMetaProtyleVisibility.get(protyleEl) === false) continue;
                    if (protyleEl && activeProtyles.size && !activeProtyles.has(protyleEl)) continue;
                    const hostTaskId = String(host.dataset.taskId || '').trim();
                    const hostAttrHostId = String(host.dataset.attrHostId || '').trim();
                    const expectedHostId = hostAttrHostId || owner;
                    if (!shouldDeepValidateNativeHosts && isInlineMetaNativeHostLocallyAnchored(host, owner, hostTaskId)) {
                        inlineMetaMissingHostSeenAt.delete(owner);
                        continue;
                    }
                    if (slowChecks >= QUICKBAR_INLINE_INVALID_HOST_PRUNE_SLOW_LIMIT || getInlineMetaNow() >= deadline) {
                        reachedBudget = true;
                        break;
                    }
                    slowChecks += 1;
                    const liveResolved = resolveQuickbarBindingForHostIds(hostTaskId, expectedHostId, owner);
                    const blockEl = liveResolved?.blockEl || null;
                    if (!blockEl) {
                        const firstSeenAt = Number(inlineMetaMissingHostSeenAt.get(owner) || 0);
                        if (!firstSeenAt) {
                            inlineMetaMissingHostSeenAt.set(owner, now);
                            continue;
                        }
                        if ((now - firstSeenAt) < 900) continue;
                        removeInlineMetaHostNode(host, true);
                        inlineMetaVisibleTaskBlocks.delete(owner);
                        inlineMetaObservedTaskBlocks.delete(owner);
                        if (hostTaskId) {
                            inlineMetaVisibleTaskBlocks.delete(hostTaskId);
                            inlineMetaObservedTaskBlocks.delete(hostTaskId);
                        }
                        removed += 1;
                        pushQuickbarInlineSyncLog('stale-host-prune', {
                            reason: String(reason || '').trim() || 'missing-block',
                            blockId: owner,
                            sourceTaskId: hostTaskId,
                            attrHostId: hostAttrHostId,
                            missingForMs: now - firstSeenAt,
                        });
                        continue;
                    }
                    inlineMetaMissingHostSeenAt.delete(owner);
                    const liveTaskId = String(liveResolved?.taskId || liveResolved?.binding?.taskId || '').trim();
                    const liveAttrHostId = String(liveResolved?.attrHostId || liveResolved?.binding?.attrHostId || liveResolved?.binding?.taskId || '').trim();
                    const bindingChanged = !!liveAttrHostId && liveAttrHostId !== expectedHostId;
                    const sourceChanged = !!(hostTaskId && liveTaskId && hostTaskId !== liveTaskId);
                    if (!bindingChanged && sourceChanged) {
                        host.dataset.taskId = liveTaskId;
                        if (liveAttrHostId) host.dataset.attrHostId = liveAttrHostId;
                        pushQuickbarInlineSyncLog('stale-host-retarget', {
                            reason: String(reason || '').trim() || 'source-changed',
                            blockId: owner,
                            sourceTaskId: hostTaskId,
                            attrHostId: hostAttrHostId,
                            liveTaskId,
                            liveAttrHostId,
                        });
                        continue;
                    }
                    if (!bindingChanged && !sourceChanged) continue;
                    removeInlineMetaHostNode(host, true);
                    inlineMetaVisibleTaskBlocks.delete(owner);
                    removed += 1;
                    pushQuickbarInlineSyncLog('stale-host-prune', {
                        reason: String(reason || '').trim() || 'binding-changed',
                        blockId: owner,
                        sourceTaskId: hostTaskId,
                        attrHostId: hostAttrHostId,
                        liveTaskId,
                        liveAttrHostId,
                        bindingChanged,
                        sourceChanged,
                    });
                }
                inlineMetaInvalidHostPruneCursor = reachedBudget && total
                    ? (startIndex + visited) % total
                    : 0;
            } catch (e) {}
            if (removed > 0) invalidateInlineMetaActiveTargetsCache();
            return removed;
        }

        function isInlineMetaStructuralSettling() {
            return !!inlineMetaStructuralRenderTimer || Date.now() < Number(inlineMetaStructuralSettleUntil || 0);
        }

        function scheduleInlineMetaStructuralQuietRender(forceRefresh = false) {
            if (!inlineMetaStarted || !isInlineMetaEnabled()) return;
            if (inlineMetaStructuralRenderTimer) {
                try { clearTimeout(inlineMetaStructuralRenderTimer); } catch (e) {}
            }
            const now = Date.now();
            const quietDelay = 180;
            inlineMetaStructuralSettleUntil = now + quietDelay;
            inlineMetaRecentStructuralUntil = Math.max(Number(inlineMetaRecentStructuralUntil || 0), now + 1800);
            inlineMetaStructuralRenderTimer = setTimeout(() => {
                inlineMetaStructuralRenderTimer = 0;
                inlineMetaStructuralSettleUntil = 0;
                requestInlineMetaRender(!!forceRefresh);
            }, quietDelay);
        }

        function requestInlineMetaRender(forceRefresh = false) {
            if (!forceRefresh && isInlineMetaStructuralSettling()) return;
            if (forceRefresh) inlineMetaPendingForceRefresh = true;
            if (inlineMetaRafId) return;
            inlineMetaRafId = requestAnimationFrame(() => {
                const nextForceRefresh = inlineMetaPendingForceRefresh;
                inlineMetaPendingForceRefresh = false;
                inlineMetaRafId = 0;
                try { scheduleInlineMetaRender(nextForceRefresh, true); } catch (e) {}
            });
        }

        function setInlineMetaScrolling(active) {
            if (inlineMetaScrolling === !!active) return;
            inlineMetaScrolling = !!active;
            if (!inlineMetaScrolling) inlineMetaRenderCursor = 0;
            try {
                document.querySelectorAll('.sy-custom-props-inline-layer').forEach((layer) => {
                    if (active) layer.classList.add('is-scrolling');
                    else layer.classList.remove('is-scrolling');
                });
            } catch (e) {}
        }

        function isInlineMetaScrollSettling() {
            return inlineMetaScrolling || Date.now() < inlineMetaRecentScrollUntil;
        }

        function updateInlineMetaSelectionVisibility() {
            let shouldHide = false;
            try {
                const selection = window.getSelection?.();
                const selectedText = String(selection?.toString?.() || '');
                if (selectedText.trim()) {
                    const anchorNode = selection?.anchorNode || null;
                    const focusNode = selection?.focusNode || null;
                    const anchorEl = anchorNode?.nodeType === Node.ELEMENT_NODE ? anchorNode : anchorNode?.parentElement;
                    const focusEl = focusNode?.nodeType === Node.ELEMENT_NODE ? focusNode : focusNode?.parentElement;
                    shouldHide = !!(
                        anchorEl?.closest?.('.protyle,.protyle-content,.protyle-wysiwyg')
                        || focusEl?.closest?.('.protyle,.protyle-content,.protyle-wysiwyg')
                    );
                }
            } catch (e) {
                shouldHide = false;
            }
            try {
                document.querySelectorAll('.sy-custom-props-inline-layer').forEach((layer) => {
                    if (shouldHide) layer.classList.add('is-selection-active');
                    else layer.classList.remove('is-selection-active');
                });
            } catch (e) {}
        }

        function shouldHandleInlineMetaViewportEvent(target) {
            const el = target instanceof Element
                ? target
                : (target?.nodeType === Node.DOCUMENT_NODE ? document.documentElement : null);
            if (!el) return false;
            if (el === document || el === document.body || el === document.documentElement || el === window) return true;
            return !!el.closest?.('.protyle,.protyle-content,.protyle-wysiwyg,.layout-tab-container');
        }

        function hasInlineMetaActiveTargets() {
            if (inlineMetaObservedTaskBlocks.size > 0 || inlineMetaVisibleTaskBlocks.size > 0) {
                inlineMetaActiveTargetsCacheValue = true;
                inlineMetaActiveTargetsCacheTs = Date.now();
                return true;
            }
            const now = Date.now();
            if ((now - inlineMetaActiveTargetsCacheTs) < 120) {
                return inlineMetaActiveTargetsCacheValue;
            }
            const layer = inlineMetaLayer && inlineMetaLayer.isConnected
                ? inlineMetaLayer
                : document.querySelector('.sy-custom-props-inline-layer');
            const nextValue = !!(layer && layer.querySelector('.sy-custom-props-inline-host'));
            inlineMetaActiveTargetsCacheValue = nextValue;
            inlineMetaActiveTargetsCacheTs = now;
            return nextValue;
        }

        function hasInlineMetaOverlayHosts() {
            try {
                return !!document.querySelector('.sy-custom-props-inline-layer .sy-custom-props-inline-host[data-block-id]');
            } catch (e) {
                return false;
            }
        }

        function isInlineMetaNativeHostSuppressed(taskId) {
            const id = String(taskId || '').trim();
            if (!id) return false;
            const until = Number(inlineMetaNativeHostSuppressedUntil.get(id) || 0);
            if (until && Date.now() < until) return true;
            if (until) inlineMetaNativeHostSuppressedUntil.delete(id);
            return false;
        }

        function suppressInlineMetaNativeHostForBlock(blockEl, reason = '', durationMs = 1800) {
            if (!blockEl) return;
            let binding = null;
            try { binding = resolveTaskBindingFromBlockEl(blockEl); } catch (e) { binding = null; }
            const hostId = String(binding?.attrHostId || binding?.taskId || resolveTaskAttrNodeIdForDetail(blockEl) || blockEl?.dataset?.nodeId || '').trim();
            if (!hostId) return;
            const safeDurationMs = Math.max(300, Math.min(30000, Number(durationMs) || 1800));
            const until = Date.now() + safeDurationMs;
            inlineMetaNativeHostSuppressedUntil.set(hostId, until);
            removeInlineMetaHostByTaskId(hostId, 'in-block');
            try {
                const taskList = blockEl.parentElement?.matches?.('.list,[data-type="NodeList"]')
                    ? blockEl.parentElement
                    : blockEl.closest?.('.list,[data-type="NodeList"]');
                taskList?.querySelectorAll?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((node) => {
                    removeInlineMetaHostNode(node, true);
                });
                taskList?.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((node) => {
                    if (!hasInlineMetaInBlockHost(node)) {
                        node.classList.remove('sy-custom-props-inline-parent');
                    }
                });
                blockEl.querySelectorAll?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((node) => {
                    const hostBlock = getTaskBlockElementFromTarget(node) || node.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                    if (hostBlock && hostBlock !== blockEl) return;
                    removeInlineMetaHostNode(node, true);
                });
            } catch (e) {}
            try { queueInlineMetaRenderBlock(blockEl, false, 420); } catch (e) {}
            setTimeout(() => {
                try {
                    if (Number(inlineMetaNativeHostSuppressedUntil.get(hostId) || 0) <= Date.now()) {
                        inlineMetaNativeHostSuppressedUntil.delete(hostId);
                        queueInlineMetaRenderBlock(blockEl, false, 420);
                    }
                } catch (e) {}
            }, safeDurationMs + 100);
            pushQuickbarInlineSyncLog('native-host-suppress', {
                reason: String(reason || '').trim() || 'unknown',
                taskId: String(binding?.taskId || '').trim(),
                attrHostId: hostId,
                durationMs: safeDurationMs,
            });
        }

        function hasTaskBlockInRoot(root) {
            if (!(root instanceof Element)) return false;
            const taskSelector = '.li[data-node-id] input[type="checkbox"],.li[data-node-id] .protyle-action__task,.li[data-node-id] .protyle-action--task,.li[data-node-id] .protyle-task--checkbox,.li[data-node-id] .protyle-task,.li[data-node-id] .b3-checkbox,.li[data-node-id][data-marker*="[ ]"],.li[data-node-id][data-marker*="[x]"],.li[data-node-id][data-marker*="[X]"],.li[data-node-id] [data-marker*="[ ]"],.li[data-node-id] [data-marker*="[x]"],.li[data-node-id] [data-marker*="[X]"]';
            const candidates = root.querySelectorAll(taskSelector);
            const candidateLimit = Math.min(candidates.length, 180);
            for (let i = 0; i < candidateLimit; i += 1) {
                const li = candidates[i]?.closest?.('.li[data-node-id], [data-type="NodeListItem"][data-node-id]');
                if (li && isTaskBlockElement(li)) return true;
            }
            const items = root.querySelectorAll('.li[data-node-id], [data-type="NodeListItem"][data-node-id]');
            const limit = Math.min(items.length, 180);
            for (let i = 0; i < limit; i += 1) {
                if (isTaskBlockElement(items[i])) return true;
            }
            return false;
        }

        function pruneInlineMetaProtyleHints() {
            inlineMetaProtyleHints.forEach((hint) => {
                if (!(hint instanceof Element) || !hint.isConnected) {
                    inlineMetaProtyleHints.delete(hint);
                    return;
                }
                // A hint exists to bypass the rect>0 filter for a freshly
                // mounted protyle whose layout hasn't stabilized. A
                // display:none protyle is a switched-away tab — the
                // visibility filter correctly excludes it, and keeping it
                // hinted would pull its blocks into the active tab's render
                // and cause global prune to evict its hosts.
                try {
                    const style = window.getComputedStyle(hint);
                    if (style && style.display === 'none') {
                        inlineMetaProtyleHints.delete(hint);
                    }
                } catch (e) {}
            });
        }

        function registerInlineMetaProtyleHint(el) {
            // Pin a freshly mounted/switched protyle so it survives the
            // visibility filter in getInlineMetaObserveRoots while its layout
            // is still 0×0 right after loaded-protyle-static / switch-protyle.
            if (!(el instanceof Element)) return;
            const protyleEl = el.matches?.('.protyle') ? el : el.closest?.('.protyle');
            if (!(protyleEl instanceof Element)) return;
            if (protyleEl.closest?.('.tm-task-detail-note-mount')) return;
            inlineMetaProtyleHints.add(protyleEl);
            pruneInlineMetaProtyleHints();
        }

        function getInlineMetaObserveRoots() {
            try {
                pruneInlineMetaProtyleHints();
                const seen = new Set();
                const result = [];
                inlineMetaProtyleHints.forEach((hint) => {
                    if (!seen.has(hint)) {
                        seen.add(hint);
                        result.push(hint);
                    }
                });
                Array.from(document.querySelectorAll('.protyle'))
                    .filter((el) => {
                        if (!(el instanceof Element)) return false;
                        if (seen.has(el)) return false;
                        if (el.closest?.('.tm-task-detail-note-mount')) return false;
                        const rect = el.getBoundingClientRect?.();
                        if (!rect) return false;
                        if (rect.width <= 0 || rect.height <= 0) return false;
                        const style = window.getComputedStyle(el);
                        if (!style || style.display === 'none' || style.visibility === 'hidden') return false;
                        if (!hasTaskBlockInRoot(el)) return false;
                        return true;
                    })
                    .forEach((el) => {
                        seen.add(el);
                        result.push(el);
                    });
                if (result.length) return result;
                const fallback = document.querySelector('.protyle--focus');
                if (fallback instanceof Element) {
                    if (fallback.closest?.('.tm-task-detail-note-mount')) return [];
                    const rect = fallback.getBoundingClientRect?.();
                    if (rect && rect.width > 0 && rect.height > 0) return [fallback];
                }
                return result;
            } catch (e) {
                return [];
            }
        }

        function ensureInlineMetaProtyleVisibilityObserver() {
            if (inlineMetaProtyleVisibilityObserver) return inlineMetaProtyleVisibilityObserver;
            if (typeof IntersectionObserver !== 'function') return null;
            inlineMetaProtyleVisibilityObserver = new IntersectionObserver((entries) => {
                let revealed = false;
                entries.forEach((entry) => {
                    const target = entry.target;
                    if (!(target instanceof Element)) return;
                    const wasIntersecting = inlineMetaProtyleVisibility.get(target) === true;
                    const nowIntersecting = entry.isIntersecting === true && entry.intersectionRatio > 0;
                    inlineMetaProtyleVisibility.set(target, nowIntersecting);
                    if (!wasIntersecting && nowIntersecting) revealed = true;
                });
                if (!revealed || !inlineMetaStarted || !isInlineMetaEnabled()) return;
                // A protyle just transitioned from hidden to visible. We want
                // to re-trigger rendering, but NOT force-refresh every chip:
                //
                // - `forceRefresh: true` would stampede /api/attr/getBlockAttrs
                //   for every visible task (the cached props are wiped from
                //   the render path's POV). While those fetches are
                //   in-flight `renderInlineMetaHtml` paints default chips
                //   (status=todo, priority=none) and any slow/failing fetch
                //   leaves the chip looking like a freshly-created task.
                //   Stale entries that genuinely changed are already
                //   invalidated by `syncInlineMetaCacheFromAttrUpdate`.
                //
                // - `clearLayout: true` was originally added on the theory
                //   that geometry was stale because the protyle was 0×0,
                //   but `layoutInlineMetaHost` skips writing the cache when
                //   rects are zero — so the cached positions all come from
                //   the previously visible state and are still relative to
                //   the per-protyle layer, which doesn't move when the tab
                //   hides/shows. Trust the cached layout's textSig/widthSig
                //   signatures to invalidate per-host when content shifted.
                scheduleInlineMetaWake(false, {
                    delayMs: 16,
                    includeBootstrap: true,
                    clearLayout: false,
                });
            }, { root: null, threshold: 0 });
            return inlineMetaProtyleVisibilityObserver;
        }

        function rebindInlineMetaProtyleVisibility() {
            const observer = ensureInlineMetaProtyleVisibilityObserver();
            if (!observer) return;
            // Re-observe every protyle in the DOM, not just visible ones, so
            // a hidden tab's protyle can fire on reveal. Cheap because IO is
            // O(observed elements) and protyles per workspace are small.
            try { observer.disconnect(); } catch (e) {}
            inlineMetaProtyleVisibility = new WeakMap();
            try {
                document.querySelectorAll('.protyle').forEach((el) => {
                    if (!(el instanceof Element)) return;
                    let rect = null;
                    try { rect = el.getBoundingClientRect(); } catch (e2) {}
                    const initiallyVisible = !!(rect && rect.width > 0 && rect.height > 0);
                    inlineMetaProtyleVisibility.set(el, initiallyVisible);
                    try { observer.observe(el); } catch (e2) {}
                });
            } catch (e) {}
        }

        function ensureInlineMetaBlockObserver() {
            if (inlineMetaBlockObserver) return inlineMetaBlockObserver;
            if (typeof IntersectionObserver !== 'function') return null;
            inlineMetaBlockObserver = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    const blockEl = entry?.target;
                    const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                    if (!blockId) return;
                    if (entry.isIntersecting) {
                        const wasVisible = inlineMetaVisibleTaskBlocks.has(blockId);
                        inlineMetaVisibleTaskBlocks.set(blockId, blockEl);
                        // A block just entered the 2400px IO margin. Pre-render
                        // its chip now so a fast scroll that brings several
                        // rows into the viewport at once doesn't reveal blank
                        // rows — the host is built and populated while the
                        // row is still off-screen, and layoutInlineMetaHost's
                        // bounds check leaves is-ready off until the row
                        // actually crosses into protyle viewport. By then
                        // there's no async work left to do, so the chip just
                        // toggles visible. Without this hook, blocks beyond
                        // the scroll-core zone (240–720px) wait until the
                        // next scroll-driven render pass even gets to them,
                        // which during fast scroll is too late.
                        let renderTaskId = blockId;
                        try { renderTaskId = String(resolveTaskAttrNodeIdForDetail(blockEl) || blockId).trim() || blockId; } catch (e) {}
                        const hasCachedRenderProps = !!renderTaskId && inlineMetaCache.has(renderTaskId);
                        if (!wasVisible && (!isInlineMetaScrollSettling() || hasCachedRenderProps) && blockEl instanceof Element && blockEl.isConnected) {
                            try { queueInlineMetaRenderBlock(blockEl, false, 2400); } catch (e) {}
                        }
                    } else {
                        inlineMetaVisibleTaskBlocks.delete(blockId);
                    }
                });
            }, {
                root: null,
                rootMargin: '2400px 0px 2400px 0px',
                threshold: 0
            });
            return inlineMetaBlockObserver;
        }

        function syncInlineMetaTaskBlocks(force = false) {
            if (!inlineMetaStarted) return;
            if (!force && !inlineMetaNeedSyncBlocks) return;
            const perfStartTs = quickbarPerfNow();
            inlineMetaNeedSyncBlocks = false;
            const roots = inlineMetaObservedRoots.length ? inlineMetaObservedRoots : getInlineMetaObserveRoots();
            const nextBlocks = new Map();
            let scannedCount = 0;
            let taskCount = 0;
            let hiddenDoneSkipped = 0;
            let nearQueued = 0;
            roots.forEach((root) => {
                if (root?.closest?.('.tm-task-detail-note-mount')) return;
                const blocks = root?.querySelectorAll?.('.li[data-node-id], [data-type="NodeListItem"][data-node-id]') || [];
                for (let i = 0; i < blocks.length; i += 1) {
                    scannedCount += 1;
                    const blockEl = blocks[i];
                    const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                    if (!blockId || nextBlocks.has(blockId)) continue;
                    if (!isTaskBlockElement(blockEl)) continue;
                    taskCount += 1;
                    if (isInlineMetaHiddenDoneTaskBlock(blockEl)) {
                        hiddenDoneSkipped += 1;
                        try { removeInlineMetaHostByTaskId(blockId); } catch (e) {}
                        inlineMetaLayoutCache.delete(blockId);
                        continue;
                    }
                    nextBlocks.set(blockId, blockEl);
                }
            });
            const io = ensureInlineMetaBlockObserver();
            const isScrolling = inlineMetaScrolling;
            inlineMetaObservedTaskBlocks.forEach((prevEl, blockId) => {
                if (nextBlocks.has(blockId)) return;
                // During scroll, SiYuan transiently detaches and re-attaches
                // task rows for lazy-render. A detached pass leaves the
                // block missing from this scan, so without the guard we'd
                // wipe the layout cache and visible-set entry for a block
                // that's about to come back. The next frame's layout would
                // see prevLayout=undefined, fail my preserve guards in
                // layoutInlineMetaHost, and strip is-ready — that's the
                // flicker. Defer evict to the next scroll-idle sync.
                if (isScrolling) return;
                if (io) {
                    try { io.unobserve(prevEl); } catch (e) {}
                }
                inlineMetaVisibleTaskBlocks.delete(blockId);
                // Intentionally NOT deleting inlineMetaLayoutCache here.
                // The cache stays alive even when the block leaves the
                // observed scan. Scroll-back-and-forth past SiYuan's
                // virtualization boundary fires this eviction at the 150ms
                // scroll-idle threshold (a brief reversal pause is enough),
                // and wiping the cache here would leave prevLayout=undefined
                // for the re-materialized block — the preserve guards in
                // layoutInlineMetaHost then fail and a transient measurement
                // failure strips is-ready, flickering the chip. The cache
                // is reclaimed via pruneInlineMetaOutsideViewport once
                // the block is genuinely far from the viewport.
            });
            const viewportHeight = window.innerHeight || document.documentElement?.clientHeight || 0;
            const syncLightMode = !force && (isScrolling || isInlineMetaScrollSettling() || Date.now() < Number(inlineMetaRecentStructuralUntil || 0));
            const nearQueueLimit = syncLightMode ? 12 : 48;
            const nearRenderCandidates = [];
            nextBlocks.forEach((nextEl, blockId) => {
                const prevEl = inlineMetaObservedTaskBlocks.get(blockId);
                if (prevEl === nextEl) return;
                if (io && prevEl) {
                    try { io.unobserve(prevEl); } catch (e) {}
                }
                if (io) {
                    try { io.observe(nextEl); } catch (e) {}
                }
                // Queue a pre-render now for blocks near the viewport.
                // IO's first entry is delivered async — by the time it
                // fires, a fast scroll may have already revealed the
                // row, so the chip lags behind. Inspecting the rect
                // synchronously here lets us queue the build during
                // the same mutation-driven render cycle that surfaced
                // the block.
                let renderTaskId = blockId;
                try { renderTaskId = String(resolveTaskAttrNodeIdForDetail(nextEl) || blockId).trim() || blockId; } catch (e) {}
                const hasCachedRenderProps = !!renderTaskId && inlineMetaCache.has(renderTaskId);
                const canQueueNearRender = !syncLightMode || !inlineMetaScrolling || hasCachedRenderProps;
                if (canQueueNearRender && nearQueued < nearQueueLimit && nextEl instanceof Element && nextEl.isConnected) {
                    try {
                        const rect = nextEl.getBoundingClientRect();
                        if (rect && rect.bottom > -2400 && rect.top < (viewportHeight + 2400)) {
                            nearRenderCandidates.push(nextEl);
                        }
                    } catch (e) {}
                }
            });
            sortInlineMetaBlocksByViewportPriority(nearRenderCandidates);
            for (let i = 0; i < nearRenderCandidates.length && nearQueued < nearQueueLimit; i += 1) {
                if (queueInlineMetaRenderBlock(nearRenderCandidates[i], false, 2400)) nearQueued += 1;
            }
            if (isScrolling) {
                // Merge mode: keep stale (possibly-still-detached) entries
                // alongside fresh ones, so their cache survives. Schedule
                // a clean resync at scroll-idle to drop entries that
                // really did leave.
                nextBlocks.forEach((nextEl, blockId) => {
                    inlineMetaObservedTaskBlocks.set(blockId, nextEl);
                });
                inlineMetaNeedSyncBlocks = true;
            } else {
                inlineMetaObservedTaskBlocks = nextBlocks;
                inlineMetaRenderCursor = 0;
            }
            if (!io) {
                if (isScrolling) {
                    nextBlocks.forEach((nextEl, blockId) => {
                        inlineMetaVisibleTaskBlocks.set(blockId, nextEl);
                    });
                } else {
                    inlineMetaVisibleTaskBlocks = new Map(nextBlocks);
                }
            }
            invalidateInlineMetaActiveTargetsCache();
            const perfDuration = quickbarPerfNow() - perfStartTs;
            if (perfDuration > 24 || scannedCount > 300 || hiddenDoneSkipped > 0) {
                pushQuickbarPerfProbe('sync-blocks', {
                    durationMs: Math.round(perfDuration),
                    force: !!force,
                    scrolling: !!isScrolling,
                    roots: roots.length,
                    scannedCount,
                    taskCount,
                    hiddenDoneSkipped,
                    observedCount: inlineMetaObservedTaskBlocks.size,
                    visibleCount: inlineMetaVisibleTaskBlocks.size,
                    nearQueued,
                    queueLength: inlineMetaRenderQueue.length,
                }, { throttleMs: hiddenDoneSkipped > 0 ? 1600 : 900 });
            }
        }

        function cleanupInlineMetaTaskBlocks() {
            if (inlineMetaMutationTimer) clearTimeout(inlineMetaMutationTimer);
            inlineMetaMutationTimer = null;
            if (inlineMetaStructuralRenderTimer) clearTimeout(inlineMetaStructuralRenderTimer);
            inlineMetaStructuralRenderTimer = 0;
            inlineMetaStructuralSettleUntil = 0;
            inlineMetaRecentStructuralUntil = 0;
            inlineMetaPropsInflight = new Map();
            if (inlineMetaBlockObserver) {
                try { inlineMetaBlockObserver.disconnect(); } catch (e) {}
            }
            inlineMetaBlockObserver = null;
            inlineMetaObservedTaskBlocks = new Map();
            inlineMetaVisibleTaskBlocks = new Map();
            inlineMetaMissingHostSeenAt = new Map();
            inlineMetaNeedSyncBlocks = true;
            invalidateInlineMetaActiveTargetsCache();
        }

        function rebindInlineMetaResizeObserver(roots) {
            try { inlineMetaResizeObserver?.disconnect?.(); } catch (e) {}
            inlineMetaResizeObserver = null;
            inlineMetaResizeObservedWidths = new WeakMap();
            if (typeof ResizeObserver !== 'function') return;
            const targetRoots = Array.isArray(roots) ? roots : [];
            if (!targetRoots.length) return;
            try {
                inlineMetaResizeObserver = new ResizeObserver((entries) => {
                    let widthChanged = false;
                    (Array.isArray(entries) ? entries : []).forEach((entry) => {
                        const target = entry?.target;
                        if (!(target instanceof Element) || !target.isConnected) return;
                        const width = Math.round(Number(entry?.contentRect?.width || target.getBoundingClientRect?.().width || 0));
                        if (width <= 0) return;
                        const prevWidth = Number(inlineMetaResizeObservedWidths.get(target) || 0);
                        inlineMetaResizeObservedWidths.set(target, width);
                        if (prevWidth && prevWidth !== width) widthChanged = true;
                    });
                    if (widthChanged) scheduleInlineMetaResizeLayoutRefresh();
                });
                const seen = new WeakSet();
                const observeTarget = (target) => {
                    if (!(target instanceof Element) || seen.has(target)) return;
                    seen.add(target);
                    try {
                        const rect = target.getBoundingClientRect?.();
                        const width = Math.round(Number(rect?.width || 0));
                        if (width > 0) inlineMetaResizeObservedWidths.set(target, width);
                    } catch (e) {}
                    try { inlineMetaResizeObserver.observe(target); } catch (e) {}
                };
                targetRoots.forEach((root) => {
                    observeTarget(root);
                    observeTarget(root?.querySelector?.('.protyle-content'));
                    observeTarget(root?.querySelector?.('.protyle-wysiwyg'));
                });
            } catch (e) {
                try { inlineMetaResizeObserver?.disconnect?.(); } catch (e2) {}
                inlineMetaResizeObserver = null;
            }
        }

        function rebindInlineMetaObservers() {
            try { inlineMetaObserver?.disconnect?.(); } catch (e) {}
            inlineMetaObservedRoots = [];
            if (!inlineMetaStarted) return;
            inlineMetaObserver = new MutationObserver((mutations) => {
                const perfStartTs = quickbarPerfNow();
                let structuralMutationCount = 0;
                let addedElementCount = 0;
                let removedElementCount = 0;
                let addedBlockLikeCount = 0;
                let removedBlockLikeCount = 0;
                let attributeMutationCount = 0;
                let sampleTarget = null;
                const attributeNameCounts = new Map();
                try {
                    mutations.forEach((m) => {
                        if (m.type !== 'attributes' || m.attributeName !== 'data-editing') return;
                        const target = m.target instanceof Element ? m.target : null;
                        if (!target || target.getAttribute?.('data-editing') !== 'true') return;
                        const scope = target.matches?.('.list,[data-type="NodeList"]')
                            ? target
                            : (target.closest?.('.list,[data-type="NodeList"]') || target.closest?.('.li,[data-type="NodeListItem"]') || target);
                        scope.querySelectorAll?.('.sy-custom-props-inline-host[data-inline-placement="in-block"]').forEach((node) => {
                            removeInlineMetaHostNode(node, true);
                        });
                        scope.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((node) => {
                            if (!hasInlineMetaInBlockHost(node)) {
                                node.classList.remove('sy-custom-props-inline-parent');
                            }
                        });
                    });
                } catch (e) {}
                // Ignore mutations originating from the inline meta layer itself
                // to prevent a feedback loop where our own DOM writes trigger re-renders.
                const isInlineMetaOwnNode = (node) => {
                    if (!(node instanceof Element)) return false;
                    if (node.closest?.('.sy-custom-props-inline-layer,.sy-custom-props-inline-host')) return true;
                    return node.matches?.('.sy-custom-props-inline-layer,.sy-custom-props-inline-host');
                };
                try {
                    mutations.forEach((m) => {
                        const target = m.target instanceof Element ? m.target : null;
                        if (target && !sampleTarget && !isInlineMetaOwnNode(target)) {
                            sampleTarget = describeQuickbarPerfElement(target);
                        }
                        if (m.type !== 'attributes') return;
                        if (target && isInlineMetaOwnNode(target)) return;
                        attributeMutationCount += 1;
                        const attrName = String(m.attributeName || 'unknown');
                        attributeNameCounts.set(attrName, Number(attributeNameCounts.get(attrName) || 0) + 1);
                    });
                } catch (e) {}
                const hasRelevantMutation = mutations.some((m) => {
                    const target = m.target;
                    if (target instanceof Element) {
                        if (isInlineMetaOwnNode(target)) return false;
                    } else if (target?.parentElement?.closest('.sy-custom-props-inline-layer')) {
                        return false;
                    }
                    const nodes = [...m.addedNodes, ...m.removedNodes];
                    if (nodes.length && nodes.every((node) => isInlineMetaOwnNode(node))) return false;
                    return true;
                });
                if (!hasRelevantMutation) return;
                let topmostAffected = null;
                const addedTaskOwnerIds = new Set();
                const removedTaskOwnerIds = new Set();
                const countBlockLikeNode = (node) => {
                    if (!(node instanceof Element)) return 0;
                    let count = node.hasAttribute?.('data-node-id') ? 1 : 0;
                    try { count += node.querySelectorAll?.('[data-node-id]')?.length || 0; } catch (e) {}
                    return count;
                };
                const stripInlineMetaArtifactsFromAddedNode = (node) => {
                    if (!(node instanceof Element)) return;
                    try {
                        if (node.matches?.('.sy-custom-props-inline-host,[data-inline-meta-host="true"]')) {
                            const isLivePluginHost = !!node.closest?.('.sy-custom-props-inline-layer')
                                || node.parentElement?.classList?.contains('protyle-attr');
                            if (!isLivePluginHost) removeInlineMetaHostNode(node, true);
                            return;
                        }
                        if (!node.hasAttribute?.('data-node-id') && !node.querySelector?.('[data-node-id]')) return;
                        node.querySelectorAll?.('.sy-custom-props-inline-host,[data-inline-meta-host="true"]').forEach((host) => {
                            removeInlineMetaHostNode(host, true);
                        });
                        node.querySelectorAll?.('.sy-custom-props-inline-parent').forEach((parent) => {
                            if (!hasInlineMetaInBlockHost(parent)) parent.classList.remove('sy-custom-props-inline-parent');
                        });
                        if (node.classList?.contains('sy-custom-props-inline-parent') && !hasInlineMetaInBlockHost(node)) {
                            node.classList.remove('sy-custom-props-inline-parent');
                        }
                    } catch (e) {}
                };
                const collectTaskOwnerIdsFromNode = (node, out) => {
                    if (!(node instanceof Element) || !(out instanceof Set)) return;
                    const collectFromBlock = (blockEl) => {
                        if (!(blockEl instanceof Element)) return;
                        try {
                            collectInlineMetaOwnerIds(blockEl).forEach((id) => out.add(id));
                        } catch (e) {
                            const id = String(blockEl?.dataset?.nodeId || blockEl?.getAttribute?.('data-node-id') || '').trim();
                            if (id) out.add(id);
                        }
                    };
                    try {
                        if (node.matches?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]')) {
                            collectFromBlock(node);
                        }
                        node.querySelectorAll?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]').forEach(collectFromBlock);
                    } catch (e) {}
                };
                const hasLiveTaskOwnerId = (id) => {
                    const ownerId = String(id || '').trim();
                    if (!ownerId) return false;
                    try {
                        if (document.querySelector(`.protyle-wysiwyg [data-node-id="${CSS.escape(ownerId)}"]`)) return true;
                    } catch (e) {}
                    try {
                        const blocks = document.querySelectorAll('.protyle-wysiwyg .li[data-node-id], .protyle-wysiwyg [data-type="NodeListItem"][data-node-id]');
                        for (let i = 0; i < blocks.length; i += 1) {
                            if (collectInlineMetaOwnerIds(blocks[i]).has(ownerId)) return true;
                        }
                    } catch (e) {}
                    return false;
                };
                const hasStructuralChange = mutations.some((m) => {
                    if (m.type !== 'childList') return false;
                    if (m.target instanceof Element && isInlineMetaOwnNode(m.target)) return false;
                    const nodes = [...m.addedNodes, ...m.removedNodes];
                    if (nodes.length && nodes.every((node) => isInlineMetaOwnNode(node))) return false;
                    Array.from(m.addedNodes || []).forEach(stripInlineMetaArtifactsFromAddedNode);
                    Array.from(m.addedNodes || []).forEach((node) => collectTaskOwnerIdsFromNode(node, addedTaskOwnerIds));
                    Array.from(m.removedNodes || []).forEach((node) => collectTaskOwnerIdsFromNode(node, removedTaskOwnerIds));
                    addedElementCount += Array.from(m.addedNodes || []).filter((node) => node instanceof Element).length;
                    removedElementCount += Array.from(m.removedNodes || []).filter((node) => node instanceof Element).length;
                    addedBlockLikeCount += Array.from(m.addedNodes || []).reduce((sum, node) => sum + countBlockLikeNode(node), 0);
                    removedBlockLikeCount += Array.from(m.removedNodes || []).reduce((sum, node) => sum + countBlockLikeNode(node), 0);
                    const structural = nodes.some((n) => n.nodeType === Node.ELEMENT_NODE && (n.hasAttribute?.('data-node-id') || n.querySelector?.('[data-node-id]')));
                    if (structural) {
                        structuralMutationCount += 1;
                        // Find the topmost-in-DOM-order anchor for the mutation,
                        // so we can invalidate only entries at or after it.
                        // Removed nodes are no longer in the tree — use the
                        // mutation target's nearest block ancestor instead.
                        let anchor = null;
                        try {
                            for (let i = 0; i < m.addedNodes.length; i += 1) {
                                const node = m.addedNodes[i];
                                if (!(node instanceof Element)) continue;
                                anchor = node.closest?.('[data-node-id]') || node;
                                if (anchor) break;
                            }
                            if (!anchor && m.target instanceof Element) {
                                anchor = m.target.closest?.('[data-node-id]') || m.target;
                            }
                        } catch (e) {}
                        if (anchor instanceof Element && anchor.isConnected) {
                            if (!topmostAffected) topmostAffected = anchor;
                            else try {
                                // anchor PRECEDES topmostAffected → use anchor instead.
                                if (anchor.compareDocumentPosition(topmostAffected) & Node.DOCUMENT_POSITION_FOLLOWING) {
                                    topmostAffected = anchor;
                                }
                            } catch (e) {}
                        }
                    }
                    return structural;
                });
                if (removedTaskOwnerIds.size > 0) {
                    removedTaskOwnerIds.forEach((id) => {
                        if (!id || addedTaskOwnerIds.has(id)) return;
                        if (hasLiveTaskOwnerId(id)) return;
                        try { removeInlineMetaHostByTaskId(id); } catch (e) {}
                        try { removeInlineMetaHostsBySourceTaskId(id); } catch (e) {}
                        try { inlineMetaObservedTaskBlocks.delete(id); } catch (e) {}
                        try { inlineMetaVisibleTaskBlocks.delete(id); } catch (e) {}
                        try { inlineMetaLayoutCache.delete(id); } catch (e) {}
                    });
                }
                inlineMetaNeedSyncBlocks = true;
                const inScrollGrace = inlineMetaScrolling || Date.now() < Number(inlineMetaRecentScrollUntil || 0);
                const deferStructuralForScroll = !!(hasStructuralChange
                    && inScrollGrace
                    && !quickbarAttrHostDragActive
                    && !hasRecentQuickbarAttrHostDragChange(2500));
                if (hasStructuralChange && !inScrollGrace) {
                    try { clearQuickbarTaskBindingCaches(); } catch (e) {}
                    quickbarAttrHostLastStructuralAt = Date.now();
                    try { quickbarAttrHostMigrationScheduler?.('structural-change'); } catch (e) {}
                    inlineMetaMutationHasStructural = true;
                    applyInlineMetaStructuralInvalidation(topmostAffected);
                } else if (deferStructuralForScroll) {
                    rememberInlineMetaDeferredStructuralAnchor(topmostAffected);
                    scheduleInlineMetaDeferredPrune();
                }
                if (!deferStructuralForScroll) {
                    if (inlineMetaMutationTimer) clearTimeout(inlineMetaMutationTimer);
                    const now = Date.now();
                    const elapsed = now - inlineMetaMutationLastFireTs;
                    const fireNow = elapsed >= 80;
                    const fireMutation = () => {
                        inlineMetaMutationTimer = null;
                        inlineMetaMutationLastFireTs = Date.now();
                        const structural = inlineMetaMutationHasStructural;
                        inlineMetaMutationHasStructural = false;
                        const forceForDragOrMigration = !!(structural && (
                            quickbarAttrHostDragActive
                            || hasRecentQuickbarAttrHostDragChange(2500)
                            || hasQuickbarAttrHostDragSnapshots(QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS)
                        ));
                        if (structural && !forceForDragOrMigration) {
                            scheduleInlineMetaStructuralQuietRender(false);
                            return;
                        }
                        requestInlineMetaRender(forceForDragOrMigration);
                    };
                    if (fireNow) {
                        fireMutation();
                    } else {
                        inlineMetaMutationTimer = setTimeout(fireMutation, 80 - elapsed);
                    }
                }
                const perfDuration = quickbarPerfNow() - perfStartTs;
                const topAttributeNames = Array.from(attributeNameCounts.entries())
                    .sort((a, b) => Number(b[1] || 0) - Number(a[1] || 0))
                    .slice(0, 6)
                    .map(([name, count]) => `${name}:${count}`);
                if (perfDuration > 24 || structuralMutationCount > 3 || (addedBlockLikeCount + removedBlockLikeCount) > 30 || attributeMutationCount > 120) {
                    pushQuickbarPerfProbe('mutation', {
                        durationMs: Math.round(perfDuration),
                        mutationCount: Array.isArray(mutations) ? mutations.length : 0,
                        hasStructuralChange,
                        structuralMutationCount,
                        attributeMutationCount,
                        attributeNames: topAttributeNames,
                        addedElementCount,
                        removedElementCount,
                        addedBlockLikeCount,
                        removedBlockLikeCount,
                        sampleTarget,
                        dragActive: !!quickbarAttrHostDragActive,
                        recentDragSnapshots: hasQuickbarAttrHostDragSnapshots(QUICKBAR_ATTR_HOST_DRAG_RECENT_TTL_MS),
                        structuralAgeMs: quickbarAttrHostLastStructuralAt ? Math.max(0, Date.now() - quickbarAttrHostLastStructuralAt) : 0,
                        scrolling: !!inlineMetaScrolling,
                        recentScroll: Date.now() < inlineMetaRecentScrollUntil,
                        queuedRender: !!inlineMetaMutationTimer,
                    }, { throttleMs: 800 });
                }
            });
            const roots = getInlineMetaObserveRoots();
            inlineMetaObservedRoots = roots;
            roots.forEach((root) => {
                try { inlineMetaObserver.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-editing'] }); } catch (e) {}
            });
            rebindInlineMetaResizeObserver(roots);
            // Watch every .protyle for hidden→visible transitions so a tab
            // switch back to a document tab triggers a wake even when SiYuan
            // does not fire switch-protyle / loaded-protyle-* for it.
            try { rebindInlineMetaProtyleVisibility(); } catch (e) {}
            inlineMetaNeedSyncBlocks = true;
            syncInlineMetaTaskBlocks(true);
        }

        function syncInlineMetaObserveRoots() {
            if (!inlineMetaStarted) return;
            const nextRoots = getInlineMetaObserveRoots();
            if (nextRoots.length === inlineMetaObservedRoots.length && nextRoots.every((root, index) => root === inlineMetaObservedRoots[index])) {
                syncInlineMetaTaskBlocks(false);
                return;
            }
            rebindInlineMetaObservers();
        }

        function unbindInlineMetaWakeEvents() {
            inlineMetaEbHandlers.forEach(({ eb, event, handler }) => {
                try { eb.off(event, handler); } catch (e) {}
            });
            inlineMetaEbHandlers = [];
            try { if (inlineMetaVisibilityHandler) document.removeEventListener('visibilitychange', inlineMetaVisibilityHandler, true); } catch (e) {}
            try { if (inlineMetaFocusHandler) window.removeEventListener('focus', inlineMetaFocusHandler, true); } catch (e) {}
            try { if (inlineMetaPageShowHandler) window.removeEventListener('pageshow', inlineMetaPageShowHandler, true); } catch (e) {}
            inlineMetaVisibilityHandler = null;
            inlineMetaFocusHandler = null;
            inlineMetaPageShowHandler = null;
        }

        function bindInlineMetaWakeEvents() {
            unbindInlineMetaWakeEvents();
            try {
                const eb = globalThis.__taskHorizonPluginInstance?.eventBus || window.siyuan?.eventBus;
                if (eb && typeof eb.on === 'function') {
                    // mode='mount' → newly loaded protyle. Force a fresh
                    //   geometry read for ITS blocks, but do NOT wipe the
                    //   global layout cache — other tabs' cached entries
                    //   are keyed by their own block IDs and stay valid.
                    //   The previous clearLayout:true behavior was the
                    //   trigger for the "open new tab → chips vanish in
                    //   other tabs" bug: after a global clear, a single
                    //   scroll event would let FAST PATH 0 strip is-ready
                    //   from every hidden tab's hosts.
                    // mode='switch' → tab brought to front by Wnd.switchTab:
                    //   the protyle is now display:block and cached layouts
                    //   are still valid relative to the per-protyle layer.
                    //   Trust the textSig/widthSig signatures to invalidate
                    //   per-host when content shifted.
                    const wakeFromProtyleEvent = (delayMs = 40, e = null, mode = 'mount') => {
                        // Bump the prune-defer window for tab switches /
                        // protyle loads. Without this, a switch back to
                        // a doc that hasn't been scrolled in >2.5s would
                        // let pruneInlineMetaOutsideViewport fire on the
                        // first post-wake render, evicting hosts before
                        // the new render pass had a chance to lay them
                        // out. The chip would disappear and only reappear
                        // after the next mouseover-induced re-render.
                        inlineMetaRecentScrollUntil = Math.max(inlineMetaRecentScrollUntil, Date.now() + 2500);
                        const protyle = e?.protyle || e?.detail?.protyle || null;
                        const wysiwygEl = protyle?.wysiwyg?.element || null;
                        const hint = wysiwygEl?.closest?.('.protyle') || wysiwygEl || null;
                        if (hint) {
                            registerInlineMetaProtyleHint(hint);
                            // IntersectionObserver delivers entries async, so
                            // the visibility map can still hold a stale
                            // `false` for the just-revealed protyle when our
                            // wake fires. layoutInlineMetaHost's FAST PATH 0
                            // would then bail out — chips vanish until any
                            // later mutation (e.g. a hover-triggered DOM
                            // change) gives IO a chance to catch up. The
                            // event reaches us only after Wnd.switchTab has
                            // made the protyle visible, so we know the
                            // truthful state synchronously.
                            try { inlineMetaProtyleVisibility.set(hint, true); } catch (e2) {}
                            try { inlineMetaProtyleVisibilityObserver?.observe?.(hint); } catch (e2) {}
                            try { syncInlineMetaObserveRoots(); } catch (e2) {}
                        }
                        const isMount = mode === 'mount';
                        scheduleInlineMetaWake(isMount, {
                            delayMs,
                            includeBootstrap: true,
                            clearLayout: false,
                        });
                    };
                    const onStatic = (e) => wakeFromProtyleEvent(24, e, 'mount');
                    const onDynamic = (e) => wakeFromProtyleEvent(40, e, 'mount');
                    const onSwitch = (e) => wakeFromProtyleEvent(32, e, 'switch');
                    const onSwitchMode = (e) => wakeFromProtyleEvent(32, e, 'switch');
                    eb.on('loaded-protyle-static', onStatic);
                    eb.on('loaded-protyle-dynamic', onDynamic);
                    eb.on('switch-protyle', onSwitch);
                    eb.on('switch-protyle-mode', onSwitchMode);
                    inlineMetaEbHandlers.push({ eb, event: 'loaded-protyle-static', handler: onStatic });
                    inlineMetaEbHandlers.push({ eb, event: 'loaded-protyle-dynamic', handler: onDynamic });
                    inlineMetaEbHandlers.push({ eb, event: 'switch-protyle', handler: onSwitch });
                    inlineMetaEbHandlers.push({ eb, event: 'switch-protyle-mode', handler: onSwitchMode });
                }
            } catch (e) {}
            inlineMetaVisibilityHandler = () => {
                try {
                    if (document.visibilityState !== 'visible') return;
                } catch (e) {}
                scheduleInlineMetaWake(true, {
                    delayMs: 48,
                    includeBootstrap: true,
                    clearLayout: true,
                });
            };
            inlineMetaFocusHandler = () => {
                scheduleInlineMetaWake(true, {
                    delayMs: 48,
                    includeBootstrap: true,
                    clearLayout: true,
                });
            };
            inlineMetaPageShowHandler = () => {
                scheduleInlineMetaWake(true, {
                    delayMs: 48,
                    includeBootstrap: true,
                    clearLayout: true,
                });
            };
            try { document.addEventListener('visibilitychange', inlineMetaVisibilityHandler, true); } catch (e) {}
            try { window.addEventListener('focus', inlineMetaFocusHandler, true); } catch (e) {}
            try { window.addEventListener('pageshow', inlineMetaPageShowHandler, true); } catch (e) {}
        }

        function layoutInlineMetaHost(blockEl, host, taskId, textAnchor, html, forceRefresh = false, visibilityBuffer = 0) {
            if (!blockEl || !host || !taskId || !textAnchor) return false;
            const isInBlockHost = String(host?.dataset?.inlinePlacement || '').trim() === 'in-block';
            if (inlineMetaIsComposing && isInlineMetaEditingBlock(blockEl)) {
                if (!isInBlockHost) host.classList.remove('is-ready');
                return isInBlockHost;
            }
            const textSig = getInlineTextFastSignature(textAnchor);
            const prevLayout = inlineMetaLayoutCache.get(taskId);
            // Prefer the source string we last wrote over host.innerHTML,
            // which can differ after browser serialization.
            const layoutHtml = String(html ?? prevLayout?.html ?? host._inlineMetaHtml ?? host.innerHTML ?? '');
            const layoutRevision = Number(inlineMetaLayoutRevision || 0);
            if (isInBlockHost) {
                if (!forceRefresh && prevLayout?.inBlock && prevLayout.layoutRevision === layoutRevision && prevLayout.textSig === textSig && prevLayout.html === layoutHtml) {
                    host.classList.toggle('is-wrap', !!prevLayout.wrapMode);
                    host.style.left = prevLayout.left || '0px';
                    host.style.top = prevLayout.top || '0px';
                    host.style.maxWidth = prevLayout.maxWidth || '';
                    host.classList.add('is-ready');
                    return true;
                }
                const parent = (host.__tmQuickbarInlineLayoutParent instanceof Element && host.__tmQuickbarInlineLayoutParent.isConnected)
                    ? host.__tmQuickbarInlineLayoutParent
                    : (host.closest?.('.sy-custom-props-inline-parent') || host.parentElement);
                const parentRect = parent?.getBoundingClientRect?.();
                const containingParent = (host.offsetParent instanceof Element) ? host.offsetParent : parent;
                const containingRect = containingParent?.getBoundingClientRect?.();
                const textRect = getInlineTextTailRect(textAnchor);
                const estimatedHost = estimateInlineMetaHostSize(layoutHtml);
                const hostWidth = Math.max(72, Math.round(Number(estimatedHost?.width) || 72));
                const hostHeight = Math.max(20, Math.round(Number(estimatedHost?.height) || 20));
                let left = 6;
                let top = 2;
                let maxWidth = '';
                let wrapMode = false;
                let widthSig = 0;
                let viewportSig = '';
                if (parentRect && containingRect && textRect) {
                    const parentWidth = Math.max(0, Math.round(Number(parentRect.width) || 0));
                    const parentRightLocal = Math.round(parentRect.right - containingRect.left);
                    const parentLeftLocal = Math.round(parentRect.left - containingRect.left);
                    const localTextRect = {
                        left: Math.round(textRect.left - containingRect.left),
                        top: Math.round(textRect.top - containingRect.top),
                        right: Math.round(textRect.right - containingRect.left),
                        bottom: Math.round(textRect.bottom - containingRect.top),
                        height: Math.max(1, Math.round(Number(textRect.height) || 20)),
                    };
                    widthSig = parentWidth;
                    viewportSig = `${localTextRect.right}:${localTextRect.top}:${localTextRect.height}`;
                    left = Math.round(localTextRect.right + 6);
                    top = Math.round(localTextRect.top + ((localTextRect.height - hostHeight) / 2));
                    const remaining = parentWidth ? Math.max(0, parentRightLocal - left - 8) : hostWidth;
                    wrapMode = !!(parentWidth && remaining < Math.max(96, Math.min(hostWidth + 12, 180)));
                    if (wrapMode) {
                        left = Math.max(parentLeftLocal, Math.min(Math.round(localTextRect.left), Math.max(parentLeftLocal, parentRightLocal - 180)));
                        top = Math.round(localTextRect.bottom + 4);
                        const wrapRemaining = parentWidth ? Math.max(96, parentRightLocal - left - 8) : hostWidth;
                        maxWidth = `${Math.max(96, Math.min(wrapRemaining, 420))}px`;
                    } else if (remaining > 0) {
                        maxWidth = `${Math.max(72, Math.min(Math.max(remaining, hostWidth), 420))}px`;
                    }
                }
                if (wrapMode) host.classList.add('is-wrap'); else host.classList.remove('is-wrap');
                host.style.left = `${left}px`;
                host.style.top = `${top}px`;
                host.style.maxWidth = maxWidth;
                host.classList.add('is-ready');
                inlineMetaLayoutCache.set(taskId, {
                    ts: Date.now(),
                    textSig,
                    widthSig,
                    viewportSig,
                    html: layoutHtml,
                    inBlock: true,
                    layoutRevision,
                    left: `${left}px`,
                    top: `${top}px`,
                    maxWidth,
                    wrapMode,
                    hostWidth,
                    hostHeight,
                });
                return true;
            }
            // --- FAST PATH 0: block lives in a hidden protyle. Cheap O(1)
            // check via the protyle-visibility WeakMap (no rect reads, no
            // forced reflow). The host is inside a display:none ancestor,
            // so whatever is-ready state it carries is invisible to the
            // user. Bail out WITHOUT mutating is-ready or the cache —
            // stripping is-ready here is the root cause of "chips vanish
            // when a sibling tab opens": opening a new tab clears the
            // global layout cache, and any subsequent scroll-driven
            // refreshInlineMetaPositions sweep then walks every hidden
            // host with prevLayout === null and would strip is-ready,
            // leaving the host invisible after the protyle is revealed
            // again. Preserving the previous is-ready state means the
            // chip is already shown the moment the tab is brought to
            // front; the live render that follows just refreshes its
            // position.
            try {
                const protyleEl = blockEl.closest?.('.protyle');
                if (protyleEl && inlineMetaProtyleVisibility.get(protyleEl) === false) {
                    return !!prevLayout;
                }
            } catch (e) {}
            // --- FAST PATH: skip expensive geometry reads when content is unchanged ---
            if (!forceRefresh && prevLayout && prevLayout.layoutRevision === layoutRevision && prevLayout.textSig === textSig && prevLayout.html === layoutHtml && !inlineMetaScrolling) {
                host.classList.toggle('is-wrap', !!prevLayout.wrapMode);
                host.style.left = prevLayout.left;
                host.style.top = prevLayout.top;
                host.style.maxWidth = prevLayout.maxWidth;
                host.classList.add('is-ready');
                inlineMetaOccupiedRects.push({
                    left: Number.parseInt(prevLayout.left, 10) || 0,
                    top: Number.parseInt(prevLayout.top, 10) || 0,
                    right: (Number.parseInt(prevLayout.left, 10) || 0) + Math.max(prevLayout.hostWidth || 72, 72),
                    bottom: (Number.parseInt(prevLayout.top, 10) || 0) + Math.max(prevLayout.hostHeight || 20, 20)
                });
                return true;
            }
            // --- READ PHASE: batch all geometry reads before any writes ---
            const layer = host.parentElement;
            const layerRect = layer?.getBoundingClientRect?.();
            const blockRect = blockEl.getBoundingClientRect();
            const widthSig = Math.round(Number(blockRect?.width) || 0);
            const plainText = getInlinePlainText(textAnchor);
            const textRect = getInlineTextTailRect(textAnchor);
            const bounds = getInlineViewportBounds(blockEl);
            const editing = isInlineMetaEditingBlock(blockEl);
            if (!layerRect || !blockRect || (!blockRect.width && !blockRect.height) || !plainText || !textRect) {
                if (editing && prevLayout) {
                    return true;
                }
                // Transient measurement failure (0×0 rect during SiYuan
                // virtualization repaint, missing text anchor while the
                // row is being mounted, layer with no dimensions during
                // a tab transition). Never strip is-ready or evict the
                // layout cache here — that's what flickers the chip
                // until the next render. The host keeps its last good
                // style, the cache keeps its last good prevLayout, and
                // the next layoutInlineMetaHost pass updates the chip
                // once measurements are valid again. The caller's
                // prev-layout restore (refreshInlineMetaPositions) may
                // also re-apply cached styles on this returned false.
                return false;
            }
            if (!isInlineRectVisibleInBounds(textRect, bounds, visibilityBuffer)) {
                // Block is offscreen. Don't strip is-ready — the chip
                // stays at its last visible position, which is clipped
                // by protyle-content's overflow:auto. When the row
                // scrolls back into the protyle viewport, the next
                // refreshInlineMetaPositions pass writes a fresh
                // position and the chip seamlessly re-anchors.
                return false;
            }
            const localTextRect = {
                left: Math.round(textRect.left - layerRect.left),
                top: Math.round(textRect.top - layerRect.top),
                right: Math.round(textRect.right - layerRect.left),
                bottom: Math.round(textRect.bottom - layerRect.top),
                height: Math.round(textRect.height)
            };
            const viewportSig = `${localTextRect.right}:${localTextRect.top}:${localTextRect.height}`;
            // --- CACHE HIT: reuse cached layout, use cached dimensions to avoid forced reflow ---
            if (!forceRefresh && prevLayout && prevLayout.layoutRevision === layoutRevision && prevLayout.textSig === textSig && prevLayout.widthSig === widthSig && prevLayout.viewportSig === viewportSig && prevLayout.html === layoutHtml) {
                host.classList.toggle('is-wrap', !!prevLayout.wrapMode);
                host.style.left = prevLayout.left;
                host.style.top = prevLayout.top;
                host.style.maxWidth = prevLayout.maxWidth;
                host.classList.add('is-ready');
                inlineMetaOccupiedRects.push({
                    left: Number.parseInt(prevLayout.left, 10) || 0,
                    top: Number.parseInt(prevLayout.top, 10) || 0,
                    right: (Number.parseInt(prevLayout.left, 10) || 0) + Math.max(prevLayout.hostWidth || 72, 72),
                    bottom: (Number.parseInt(prevLayout.top, 10) || 0) + Math.max(prevLayout.hostHeight || 20, 20)
                });
                finishDebug(true, 'geometry-cache');
                return true;
            }
            // --- READ host dimensions: remove is-wrap only here to measure natural size ---
            const estimatedHost = estimateInlineMetaHostSize(layoutHtml);
            const hostWidth = estimatedHost.width;
            const hostHeight = estimatedHost.height;
            const layerWidth = Math.max(0, Math.round(bounds?.width || layerRect.width || 0));
            // --- COMPUTE PHASE: pure calculations, no DOM access ---
            const minLeft = 8;
            const maxLeft = Math.max(minLeft, layerWidth - hostWidth - 8);
            const left = Math.max(minLeft, Math.min(maxLeft, Math.round(localTextRect.right + 6)));
            const top = Math.max(2, Math.round(localTextRect.top + ((localTextRect.height - hostHeight) / 2)));
            const remain = Math.max(96, Math.round(layerWidth - left - 8));
            const maxWidth = Math.max(72, Math.min(remain, Math.max(hostWidth, 320)));
            let wrapMode = remain < Math.max(140, Math.min(hostWidth + 12, 260));
            let finalLeft = left;
            let finalTop = top;
            let finalMaxWidth = maxWidth;
            if (wrapMode) {
                finalLeft = Math.max(minLeft, Math.min(Math.max(minLeft, layerWidth - 180), Math.round(localTextRect.left)));
                finalTop = Math.max(2, Math.round(localTextRect.bottom + 4));
                finalMaxWidth = Math.max(180, Math.min(Math.max(180, layerWidth - finalLeft - 8), Math.max(220, Math.min(560, Math.round(layerWidth * 0.76)))));
            }
            // Estimate actual dimensions from calculated values (avoid forced reflow from reading after writes)
            const estHostWidth = Math.min(hostWidth, finalMaxWidth);
            // In wrap mode, estimate rows from how much content overflows finalMaxWidth (row-gap: 4px)
            const estWrapRows = wrapMode ? Math.max(1, Math.ceil(hostWidth / Math.max(finalMaxWidth, 1))) : 1;
            const estHostHeight = hostHeight * estWrapRows + Math.max(0, estWrapRows - 1) * 4;
            const candidateRect = {
                left: finalLeft,
                top: finalTop,
                right: finalLeft + Math.max(estHostWidth, 72),
                bottom: finalTop + Math.max(estHostHeight, 20)
            };
            const expandedTextRect = {
                left: Math.max(0, Math.round(localTextRect.left - 2)),
                top: Math.max(0, Math.round(localTextRect.top - 2)),
                right: Math.round(localTextRect.right + 2),
                bottom: Math.round(localTextRect.bottom + 2)
            };
            const textCollision = rectsOverlap(candidateRect, expandedTextRect, 2);
            const occupiedCollision = inlineMetaOccupiedRects.some((rect) => rectsOverlap(candidateRect, rect, 4));
            if ((textCollision && !editing) || occupiedCollision) {
                if (editing) {
                    inlineMetaOccupiedRects.push(candidateRect);
                    const leftPx = `${finalLeft}px`;
                    const topPx = `${finalTop}px`;
                    const maxWidthPx = `${finalMaxWidth}px`;
                    if (wrapMode) host.classList.add('is-wrap'); else host.classList.remove('is-wrap');
                    host.style.left = leftPx;
                    host.style.top = topPx;
                    host.style.maxWidth = maxWidthPx;
                    host.classList.add('is-ready');
                    inlineMetaLayoutCache.set(taskId, { ts: Date.now(), textSig, widthSig, viewportSig, html: layoutHtml, layoutRevision, left: leftPx, top: topPx, maxWidth: maxWidthPx, wrapMode, hostWidth: estHostWidth, hostHeight: estHostHeight });
                    return true;
                }
                // Same preservation as the failure paths above:
                // collisions are usually transient (a sibling chip's
                // rect briefly overlaps ours while positions shift on
                // a scroll tick). Stripping is-ready here was the
                // primary flicker source — sibling chips bouncing as
                // they re-collide on every render. The chip keeps its
                // last position; the next layout pass after the
                // sibling moves resolves the collision cleanly.
                return false;
            }
            // --- WRITE PHASE: batch all DOM writes together ---
            const leftPx = `${finalLeft}px`;
            const topPx = `${finalTop}px`;
            const maxWidthPx = `${finalMaxWidth}px`;
            if (wrapMode) host.classList.add('is-wrap'); else host.classList.remove('is-wrap');
            host.style.left = leftPx;
            host.style.top = topPx;
            host.style.maxWidth = maxWidthPx;
            host.classList.add('is-ready');
            inlineMetaLayoutCache.set(taskId, { ts: Date.now(), textSig, widthSig, viewportSig, html: layoutHtml, layoutRevision, left: leftPx, top: topPx, maxWidth: maxWidthPx, wrapMode, hostWidth: estHostWidth, hostHeight: estHostHeight });
            inlineMetaOccupiedRects.push(candidateRect);
            return true;
        }

        function refreshInlineMetaPositions() {
            if (!isInlineMetaEnabled()) return;
            // Gather hosts from every layer in the document. Each protyle
            // has its own layer; the old code only re-positioned hosts in
            // whichever layer was last set as `inlineMetaLayer`, so a
            // split-view (or dock + tab) would have chips frozen in one
            // protyle while the other scrolled correctly.
            const layers = Array.from(document.querySelectorAll('.sy-custom-props-inline-layer'));
            if (!layers.length) return;
            inlineMetaOccupiedRects = [];
            const hosts = [];
            for (let li = 0; li < layers.length; li += 1) {
                const layerEl = layers[li];
                if (!layerEl?.isConnected) continue;
                Array.prototype.push.apply(hosts, Array.from(layerEl.querySelectorAll('.sy-custom-props-inline-host[data-block-id]')));
            }
            const entries = [];
            let missingBlockCount = 0;
            let outsideViewportCount = 0;
            const viewportTop = -900;
            const viewportBottom = (window.innerHeight || document.documentElement?.clientHeight || 0) + 900;
            for (let i = 0; i < hosts.length; i++) {
                const host = hosts[i];
                const taskId = String(host?.dataset?.blockId || '').trim();
                if (!taskId) continue;
                const sourceTaskId = String(host?.dataset?.taskId || '').trim();
                const attrHostId = String(host?.dataset?.attrHostId || taskId).trim();
                const liveResolved = resolveQuickbarBindingForHostIds(sourceTaskId, attrHostId, taskId);
                const blockEl = liveResolved?.blockEl || getBlockElById(sourceTaskId) || getBlockElById(taskId);
                if (liveResolved?.taskId) host.dataset.taskId = liveResolved.taskId;
                if (liveResolved?.attrHostId) host.dataset.attrHostId = liveResolved.attrHostId;
                const textAnchor = getInlineTextAnchor(blockEl);
                if (!blockEl || !textAnchor) {
                    entries.push({ host, taskId, skip: true });
                    missingBlockCount += 1;
                    continue;
                }
                inlineMetaMissingHostSeenAt.delete(taskId);
                if (inlineMetaScrolling) {
                    try {
                        const rect = blockEl.getBoundingClientRect?.();
                        if (!rect || rect.bottom < viewportTop || rect.top > viewportBottom) {
                            outsideViewportCount += 1;
                            continue;
                        }
                    } catch (e) {}
                }
                entries.push({ host, taskId, blockEl, textAnchor, html: inlineMetaLayoutCache.get(taskId)?.html || host._inlineMetaHtml || host.innerHTML || '', skip: false });
            }
            let laidOut = 0;
            let restored = 0;
            for (let i = 0; i < entries.length; i++) {
                const e = entries[i];
                if (e.skip) {
                    // Block is missing from DOM (SiYuan may have
                    // virtualized it, or it's truly gone). Don't strip
                    // is-ready here either — the chip's host stays in
                    // its layer at its last position. If the block
                    // truly is gone for good, pruneInlineMetaOutsideViewport
                    // removes the host once the recent-scroll grace
                    // window expires; meanwhile a re-materialized row
                    // (back-and-forth scroll, virtualization reflow)
                    // finds its chip already in place and just gets a
                    // fresh position from the next successful pass.
                    continue;
                }
                const prevLayout = inlineMetaScrolling ? inlineMetaLayoutCache.get(e.taskId) : null;
                const ok = layoutInlineMetaHost(e.blockEl, e.host, e.taskId, e.textAnchor, e.html, false);
                if (ok) laidOut += 1;
                if (!ok && prevLayout) {
                    e.host.classList.toggle('is-wrap', !!prevLayout.wrapMode);
                    e.host.style.left = prevLayout.left;
                    e.host.style.top = prevLayout.top;
                    e.host.style.maxWidth = prevLayout.maxWidth;
                    e.host.classList.add('is-ready');
                    restored += 1;
                }
            }
        }

        async function renderInlineMetaForBlock(blockEl, forceRefresh = false, visibilityBuffer = 0) {
            if (!isInlineMetaEnabled()) return;
            if (isInlineMetaScrollSettling() && forceRefresh) forceRefresh = false;
            let binding = null;
            try { binding = resolveTaskBindingFromBlockEl(blockEl); } catch (e) { binding = null; }
            const taskId = String(binding?.attrHostId || binding?.taskId || resolveTaskAttrNodeIdForDetail(blockEl) || blockEl?.dataset?.nodeId || '').trim();
            if (!taskId) return;
            try { maybeRequestQuickbarSubtaskFieldInheritance(blockEl, binding, 'inline-meta-render'); } catch (e) {}
            const cfg = getQuickbarInlineSettings();
            const hasVisibleDateInlineField = Array.isArray(cfg?.fields)
                && (cfg.fields.includes('custom-start-date') || cfg.fields.includes('custom-completion-time'));
            if (isInlineMetaHiddenDoneTaskBlock(blockEl)) {
                removeInlineMetaHostByTaskId(taskId);
                inlineMetaLayoutCache.delete(taskId);
                return;
            }
            const isInScope = isInlineMetaScopeAllowedForBlockCached(blockEl);
            if (!isInScope) {
                removeInlineMetaHostByTaskId(taskId);
                inlineMetaLayoutCache.delete(taskId);
                return;
            }
            const useOverlayHost = isInlineMetaNativeHostSuppressed(taskId)
                || isInlineMetaNativeHostUnsafeBlock(blockEl)
                || !QUICKBAR_INLINE_USE_NATIVE_HOST;
            if (useOverlayHost) removeInlineMetaHostByTaskId(taskId, 'in-block');
            const hostParent = getInlineHostParent(blockEl);
            if (!hostParent) return;
            const textAnchor = getInlineTextAnchor(blockEl);
            if (!textAnchor) return;
            const hasRemarkInlineField = Array.isArray(cfg?.fields) && cfg.fields.includes('custom-remark');
            const transitionSourceId = String(binding?.attrHostMigrationSourceId || '').trim();
            const attrHostIdForRender = String(binding?.attrHostId || taskId).trim() || taskId;
            const hasRecentAttrHostChange = hasRecentQuickbarAttrHostStructuralChange(5000);
            const hasRecentAttrHostDrag = hasRecentQuickbarAttrHostDragChange(2500);
            let runtimeProps = getRuntimeTaskCustomProps(taskId, blockEl);
            if (runtimeProps?.props && !shouldUseQuickbarRuntimePropsForBinding(runtimeProps, binding)) {
                pushQuickbarInlineSyncLog('runtime-host-conflict', {
                    taskId,
                    sourceTaskId: String(binding?.taskId || '').trim(),
                    attrHostId: String(binding?.attrHostId || '').trim(),
                    runtimeTaskId: String(runtimeProps.taskId || '').trim(),
                    runtimeAttrHostId: String(runtimeProps.attrHostId || '').trim(),
                    reason: 'inline-render',
                });
                runtimeProps = null;
            }
            if (runtimeProps?.props && hasVisibleDateInlineField
                && String(binding?.taskId || '').trim()
                && String(binding?.attrHostId || '').trim()
                && String(binding?.taskId || '').trim() !== String(binding?.attrHostId || '').trim()) {
                const cachedDateProps = inlineMetaCache.get(taskId);
                if (cachedDateProps?.__tmQuickbarHasManagedAttrHostAttrs === true) {
                    runtimeProps = null;
                }
            }
            const shouldRevalidateRuntimeDateProps = !!(
                runtimeProps?.props
                && hasVisibleDateInlineField
                && String(binding?.taskId || '').trim()
                && String(binding?.attrHostId || '').trim()
                && String(binding?.taskId || '').trim() !== String(binding?.attrHostId || '').trim()
            );
            if (!runtimeProps?.props) {
                try {
                    const dragSnapshot = getQuickbarAttrHostDragSnapshot(binding?.taskId, binding?.attrHostId || taskId);
                    const snapshotAttrs = dragSnapshot?.attrs && typeof dragSnapshot.attrs === 'object' ? dragSnapshot.attrs : null;
                    if (snapshotAttrs && getQuickbarAttrHostMigrationKeys(snapshotAttrs).length) {
                        const snapshotProps = normalizeCustomProps({
                            ...(inlineMetaCache.get(taskId) || {}),
                            ...snapshotAttrs,
                        });
                        setInlineMetaCache(taskId, snapshotProps);
                        const sourceTaskId = String(binding?.taskId || '').trim();
                        if (sourceTaskId && sourceTaskId !== taskId) setInlineMetaCache(sourceTaskId, snapshotProps);
                        pushQuickbarInlineSyncLog('drag-snapshot-cache', {
                            taskId,
                            sourceTaskId,
                            attrHostId: String(binding?.attrHostId || taskId).trim(),
                            sourceHostId: String(dragSnapshot.sourceHostId || '').trim(),
                            status: String(readQuickbarTaskMetaAttrValue(snapshotAttrs, 'customStatus', '') || '').trim(),
                        });
                    }
                } catch (e) {}
            }
            // (Removed an aggressive is-ready strip here: when a date
            // field was configured and neither runtime props nor cache
            // were available, the original code blanked the chip until
            // fresh props arrived. For an already-rendered chip this
            // produced a visible blink on every render where the cache
            // had been wiped or the runtime task wasn't registered yet.
            // The applyFreshProps callback below updates innerHTML when
            // fresh data actually differs, so the strip wasn't load-
            // bearing — it was just a flicker source.)
            if (runtimeProps?.props) {
                const cachedSpentDisplay = String(inlineMetaCache.get(taskId)?.['custom-focus-spent-display'] || '').trim();
                const runtimeSpentDisplay = String(runtimeProps.props['custom-focus-spent-display'] || '').trim();
                const runtimePropsForCacheBase = (!runtimeSpentDisplay && cachedSpentDisplay)
                    ? normalizeCustomProps({ ...runtimeProps.props, 'custom-focus-spent-display': cachedSpentDisplay })
                    : runtimeProps.props;
                const runtimePropsForCache = applyInlineMetaOptimisticPatch(runtimePropsForCacheBase, [
                    taskId,
                    runtimeProps.taskId,
                    runtimeProps.attrHostId,
                    binding?.taskId,
                    binding?.attrHostId,
                ], 'runtime-props');
                setInlineMetaCache(taskId, runtimePropsForCache);
                if (runtimeProps.taskId && runtimeProps.taskId !== taskId) setInlineMetaCache(runtimeProps.taskId, runtimePropsForCache);
                if (runtimeProps.attrHostId && runtimeProps.attrHostId !== taskId) setInlineMetaCache(runtimeProps.attrHostId, runtimePropsForCache);
            }
            if (!runtimeProps?.props) {
                try {
                    const currentCache = inlineMetaCache.get(taskId);
                    if (transitionSourceId && transitionSourceId !== attrHostIdForRender
                        && (hasRecentAttrHostChange
                            || currentCache?.__tmQuickbarHasManagedAttrHostAttrs !== true)) {
                        const sourceProps = inlineMetaCache.get(transitionSourceId);
                        const sourceStatus = String(sourceProps?.['custom-status'] || '').trim();
                        const currentStatus = String(currentCache?.['custom-status'] || '').trim();
                        const defaultUndoneStatus = getDefaultUndoneStatusId(getStatusOptionsSnapshot());
                        if (sourceProps && sourceStatus && sourceStatus !== defaultUndoneStatus
                            && (!currentStatus || currentStatus === defaultUndoneStatus)) {
                            setInlineMetaCache(taskId, sourceProps);
                            const sourceTaskId = String(binding?.taskId || '').trim();
                            if (sourceTaskId && sourceTaskId !== taskId) setInlineMetaCache(sourceTaskId, sourceProps);
                            pushQuickbarInlineSyncLog('transition-source-cache', {
                                taskId,
                                sourceTaskId,
                                attrHostId: attrHostIdForRender,
                                sourceId: transitionSourceId,
                                status: sourceStatus,
                                previousStatus: currentStatus,
                            });
                        }
                    }
                } catch (e) {}
            }
            const hasCacheForRender = inlineMetaCache.has(taskId) && !runtimeProps?.props;
            const hasCached = hasCacheForRender && !forceRefresh;
            const revalidateCached = hasCached && isInlineMetaCacheStale(taskId, hasRemarkInlineField ? 30000 : 12000);
            const includeRemarkForFreshRead = false;
            const useEmptyPropsForRender = !runtimeProps?.props && !hasCacheForRender;
            if (useEmptyPropsForRender && transitionSourceId && hasRecentAttrHostDrag) {
                Promise.resolve(ensureTaskPropsReady(taskId, true, { skipAttrFallback: false, blockEl, includeRemark: includeRemarkForFreshRead }))
                    .then(() => {
                        try { queueInlineMetaRenderBlock(blockEl, true, visibilityBuffer || 420); } catch (e) {}
                    })
                    .catch(() => null);
                pushQuickbarInlineSyncLog('transition-empty-defer', {
                    taskId,
                    sourceTaskId: String(binding?.taskId || '').trim(),
                    attrHostId: attrHostIdForRender,
                    sourceId: transitionSourceId,
                });
                return;
            }
            const cachedPropsForRender = useEmptyPropsForRender
                ? normalizeCustomProps()
                : getInlineCachedProps(taskId);
            const html = renderInlineMetaHtml(cfg, cachedPropsForRender, blockEl);
            if (!html) {
                if (inlineMetaScrolling) return;
                if (runtimeProps?.props || hasCacheForRender) {
                    removeInlineMetaHostByTaskId(taskId);
                    inlineMetaLayoutCache.delete(taskId);
                    return;
                }
                if (!inlineMetaScrolling && (!hasCacheForRender || revalidateCached || forceRefresh)) {
                    Promise.resolve(ensureTaskPropsReady(taskId, forceRefresh || revalidateCached, { skipAttrFallback: false, blockEl, includeRemark: includeRemarkForFreshRead })).catch(() => null);
                }
                return;
            }
            const sourceTaskIdForRender = String(binding?.taskId || taskId).trim() || taskId;
            const shouldDedupeSourceHosts = sourceTaskIdForRender
                && (sourceTaskIdForRender !== attrHostIdForRender || hasRecentAttrHostChange || hasRecentAttrHostDrag)
                && shouldRunInlineMetaSourceHostDedupe(sourceTaskIdForRender, attrHostIdForRender, hasRecentAttrHostChange || hasRecentAttrHostDrag ? 700 : QUICKBAR_INLINE_SOURCE_DEDUPE_TTL_MS);
            const removedSourceHosts = shouldDedupeSourceHosts
                ? removeInlineMetaHostsBySourceTaskId(sourceTaskIdForRender, attrHostIdForRender)
                : 0;
            if (removedSourceHosts > 0) {
                pushQuickbarInlineSyncLog('source-host-dedupe', {
                    taskId,
                    sourceTaskId: sourceTaskIdForRender,
                    attrHostId: attrHostIdForRender,
                    removed: removedSourceHosts,
                });
            }
            const host = ensureInlineHost(blockEl, { preferOverlay: useOverlayHost, blockId: taskId });
            if (!host) return;
            host.dataset.blockId = taskId;
            host.dataset.taskId = String(binding?.taskId || taskId).trim() || taskId;
            host.dataset.attrHostId = attrHostIdForRender;
            // Same comparison fix as applyFreshProps: track the last
            // source string we wrote, not the browser-serialized
            // host.innerHTML. Comparing against innerHTML caused a
            // rewrite every render-during-scroll for stable content,
            // which is the visible chip flicker.
            const htmlChanged = host._inlineMetaHtml !== html;
            const layoutOk = layoutInlineMetaHost(blockEl, host, taskId, textAnchor, html, forceRefresh, visibilityBuffer);
            if (Array.isArray(cfg?.fields) && cfg.fields.includes('custom-status')) {
                pushQuickbarInlineSyncLog('render', {
                    taskId,
                    sourceTaskId: String(binding?.taskId || '').trim(),
                    attrHostId: String(binding?.attrHostId || '').trim(),
                    forceRefresh: !!forceRefresh,
                    hasRuntimeProps: !!runtimeProps?.props,
                    hasCached,
                    revalidateCached,
                    status: String(cachedPropsForRender?.['custom-status'] || '').trim(),
                    taskCompleteAt: String(cachedPropsForRender?.taskCompleteAt || cachedPropsForRender?.task_complete_at || readQuickbarTaskMetaAttrValue(cachedPropsForRender || {}, 'taskCompleteAt', '') || '').trim(),
                    htmlChanged,
                    layoutOk,
                    placement: String(host?.dataset?.inlinePlacement || '').trim(),
                    hostParentTag: String(host?.parentElement?.tagName || '').toLowerCase(),
                    hostParentClass: String(host?.parentElement?.className || '').trim(),
                    hostParentType: String(host?.parentElement?.getAttribute?.('data-type') || '').trim(),
                    hostParentId: String(host?.parentElement?.dataset?.nodeId || '').trim(),
                });
            }
            if (htmlChanged && layoutOk && host.isConnected && String(host.dataset.blockId || '').trim() === taskId) {
                host.innerHTML = html;
                host._inlineMetaHtml = html;
            }
            if (runtimeProps?.props || (hasCached && !revalidateCached)) {
                if (shouldRevalidateRuntimeDateProps && !isInlineMetaScrollSettling()) {
                    const now = Date.now();
                    const revalidateKey = `${taskId}:${attrHostIdForRender}`;
                    const lastRevalidateAt = Number(inlineMetaRuntimeDateRevalidateSeenAt.get(revalidateKey) || 0);
                    if (!lastRevalidateAt || now - lastRevalidateAt > 8000) {
                        inlineMetaRuntimeDateRevalidateSeenAt.set(revalidateKey, now);
                        if (inlineMetaRuntimeDateRevalidateSeenAt.size > 300) {
                            inlineMetaRuntimeDateRevalidateSeenAt.forEach((seenAt, key) => {
                                if (now - Number(seenAt || 0) > 30000) inlineMetaRuntimeDateRevalidateSeenAt.delete(key);
                            });
                        }
                        Promise.resolve(ensureTaskPropsReady(taskId, true, { skipAttrFallback: false, blockEl, includeRemark: includeRemarkForFreshRead }))
                            .then(() => {
                                try { queueInlineMetaRenderBlock(blockEl, false, visibilityBuffer || 420); } catch (e) {}
                            })
                            .catch(() => null);
                    }
                }
                return;
            }
            if (inlineMetaScrolling && !hasRecentAttrHostDrag) return;
            if (hasRecentAttrHostChange && !hasRecentAttrHostDrag && hasCacheForRender) return;
            Promise.resolve(ensureTaskPropsReady(taskId, forceRefresh || revalidateCached, { skipAttrFallback: false, blockEl, includeRemark: includeRemarkForFreshRead })).catch(() => null);
        }

        function scheduleInlineMetaRender(forceRefresh = false, immediate = false) {
            const run = () => {
                inlineMetaRenderTimer = null;
                if (!isInlineMetaEnabled()) {
                    removeInlineMetaNodes();
                    return;
                }
                if (!inlineMetaScrolling || (inlineMetaNeedSyncBlocks && inlineMetaObservedTaskBlocks.size === 0)) {
                    syncInlineMetaObserveRoots();
                    syncInlineMetaTaskBlocks(false);
                }
                const scrollSettling = isInlineMetaScrollSettling();
                const structuralSettling = Date.now() < Number(inlineMetaRecentStructuralUntil || 0);
                const lightRender = scrollSettling || structuralSettling;
                if (!lightRender) {
                    pruneInlineMetaInvalidHosts(forceRefresh ? 'render-force' : 'render');
                }
                inlineMetaOccupiedRects = [];
                const dir = inlineMetaScrollDirection;
                const buckets = inlineMetaScrolling ? null : getInlineTaskBlockBuckets(dir);
                const blocks = buckets ? buckets.coreBlocks : [];
                if (inlineMetaScrolling) {
                    // Render a small core slice while scrolling so blocks
                    // entering the viewport get chips immediately. The old
                    // path skipped all rendering until the 150ms scroll-idle
                    // timer fired, which made fast scrolling reveal blank
                    // rows for ~150ms. Cap the batch tightly to keep frame
                    // budget — heavy work still waits for scroll-idle.
                    const scrollCoreUp = dir > 0 ? 240 : (dir < 0 ? 720 : 480);
                    const scrollCoreDown = dir > 0 ? 720 : (dir < 0 ? 240 : 480);
                    const scrollCoreBlocks = getInlineDirectionalTaskBlocks(scrollCoreUp, scrollCoreDown, 32, true);
                    const scrollCoreLimit = Math.min(QUICKBAR_INLINE_RENDER_BATCH_LIMIT, scrollCoreBlocks.length);
                    for (let i = 0; i < scrollCoreLimit; i += 1) {
                        const blockEl = scrollCoreBlocks[i];
                        const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                        let renderTaskId = blockId;
                        try { renderTaskId = String(resolveTaskAttrNodeIdForDetail(blockEl) || blockId).trim() || blockId; } catch (e) {}
                        if (renderTaskId && inlineMetaCache.has(renderTaskId)) {
                            queueInlineMetaRenderBlock(blockEl, false, 360);
                        }
                    }
                } else {
                    const viewportBlocks = buckets ? buckets.viewportBlocks : [];
                    const preRenderBlocks = buckets && !lightRender ? buckets.preRenderBlocks : [];
                    const keepBlocks = buckets ? buckets.keepBlocks : [];
                    if (lightRender) {
                        if (scrollSettling) scheduleInlineMetaDeferredPrune();
                    } else {
                        pruneInlineMetaOutsideViewport(keepBlocks);
                    }
                    const coreSet = new Set(blocks.map((el) => String(el?.dataset?.nodeId || '').trim()).filter(Boolean));
                    const renderSourceBlocks = [];
                    const renderSourceSeen = new Set();
                    const pushRenderSourceBlock = (blockEl) => {
                        const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                        if (!blockId || renderSourceSeen.has(blockId)) return;
                        renderSourceSeen.add(blockId);
                        renderSourceBlocks.push(blockEl);
                    };
                    viewportBlocks.forEach(pushRenderSourceBlock);
                    blocks.forEach(pushRenderSourceBlock);
                    preRenderBlocks.forEach(pushRenderSourceBlock);
                    sortInlineMetaBlocksByViewportPriority(renderSourceBlocks);
                    prefetchInlineMetaProps(renderSourceBlocks, lightRender ? 24 : 120);
                    const renderBlocks = [];
                    const renderLimit = Math.min(QUICKBAR_INLINE_RENDER_BATCH_LIMIT, renderSourceBlocks.length);
                    const renderCursor = renderSourceBlocks.length ? inlineMetaRenderCursor % renderSourceBlocks.length : 0;
                    for (let i = 0; i < renderLimit; i += 1) {
                        renderBlocks.push(renderSourceBlocks[(renderCursor + i) % renderSourceBlocks.length]);
                    }
                    const renderPassComplete = !renderSourceBlocks.length || (renderCursor + renderBlocks.length) >= renderSourceBlocks.length;
                    inlineMetaRenderCursor = renderSourceBlocks.length
                        ? (renderCursor + renderBlocks.length) % renderSourceBlocks.length
                        : 0;
                    renderBlocks.forEach((blockEl) => {
                        const blockId = String(blockEl?.dataset?.nodeId || '').trim();
                        const buffer = coreSet.has(blockId) ? 420 : 1800;
                        queueInlineMetaRenderBlock(blockEl, forceRefresh, buffer);
                    });
                    if (!lightRender && renderSourceBlocks.length > renderBlocks.length && !renderPassComplete) {
                        inlineMetaRenderTimer = setTimeout(() => {
                            inlineMetaRenderTimer = null;
                            requestInlineMetaRender(false);
                        }, 48);
                    }
                }
            };
            if (inlineMetaRenderTimer) clearTimeout(inlineMetaRenderTimer);
            if (immediate) {
                run();
                return;
            }
            inlineMetaRenderTimer = setTimeout(run, forceRefresh ? 12 : 24);
        }

        function startInlineMeta() {
            if (inlineMetaStarted) return;
            inlineMetaStarted = true;
            removeInlineMetaNodes();
            inlineMetaNeedSyncBlocks = true;
            inlineMetaLastScrollRenderTs = 0;
            inlineMetaScrollDirection = 0;
            inlineMetaLastScrollPos = getInlineScrollPositionFromEventTarget(window);
            rebindInlineMetaObservers();
            bindInlineMetaWakeEvents();
            inlineMetaScrollHandler = (e) => {
                if (!shouldHandleInlineMetaViewportEvent(e?.target || document.documentElement)) return;
                const isResizeEvent = e?.type === 'resize';
                if (isResizeEvent) bumpInlineMetaLayoutRevision();
                let pos = inlineMetaLastScrollPos;
                let delta = 0;
                const now = Date.now();
                const postStructuralScrollQuiet = !isResizeEvent && now < Number(inlineMetaRecentStructuralUntil || 0);
                if (!hasInlineMetaActiveTargets()) {
                    if (!inlineMetaNeedSyncBlocks) return;
                    if (inlineMetaScrollIdleTimer) clearTimeout(inlineMetaScrollIdleTimer);
                    inlineMetaScrollIdleTimer = setTimeout(() => {
                        inlineMetaScrollIdleTimer = null;
                        if (inlineMetaNeedSyncBlocks || inlineMetaDeferredStructural) {
                            inlineMetaLastScrollRenderTs = Date.now();
                            requestInlineMetaRender(false);
                        }
                    }, postStructuralScrollQuiet ? 1000 : 220);
                    return;
                }
                setInlineMetaScrolling(true);
                // Grace window for pruning after each scroll event. The
                // 150ms scroll-idle threshold below is fine for ending
                // the is-scrolling class and re-running layout, but
                // back-and-forth scrolling typically pauses 200–500ms
                // at the direction reversal. If pruning fires during
                // that pause, hosts at the keep-zone edge get evicted
                // and the reverse scroll then has to rebuild them.
                // Extending the prune deferral past the layout-idle
                // threshold keeps those hosts alive across the reversal.
                inlineMetaRecentScrollUntil = Date.now() + 2500;
                if (!isResizeEvent) {
                    pos = getInlineScrollPositionFromEventTarget(e?.target || document.documentElement);
                    delta = pos - inlineMetaLastScrollPos;
                    if (Math.abs(delta) >= 1) {
                        inlineMetaScrollDirection = delta > 0 ? 1 : -1;
                        inlineMetaLastScrollPos = pos;
                    }
                }
                if (!inlineMetaPositionRafId && hasInlineMetaOverlayHosts()) {
                    inlineMetaPositionRafId = requestAnimationFrame(() => {
                        inlineMetaPositionRafId = 0;
                        try { refreshInlineMetaPositions(); } catch (e2) {}
                    });
                }
                if (isResizeEvent && (now - inlineMetaLastScrollRenderTs) > 80) {
                    inlineMetaLastScrollRenderTs = now;
                    requestInlineMetaRender(false);
                }
                if (inlineMetaScrollIdleTimer) clearTimeout(inlineMetaScrollIdleTimer);
                inlineMetaScrollIdleTimer = setTimeout(() => {
                    inlineMetaScrollIdleTimer = null;
                    setInlineMetaScrolling(false);
                    if (isResizeEvent || inlineMetaNeedSyncBlocks || inlineMetaDeferredStructural) {
                        inlineMetaLastScrollRenderTs = Date.now();
                        requestInlineMetaRender(false);
                    }
                }, isResizeEvent ? 70 : (postStructuralScrollQuiet ? 1000 : 150));
            };
            inlineMetaPreScrollHandler = (e) => {
                if (!shouldHandleInlineMetaViewportEvent(e?.target || document.documentElement)) return;
                setInlineMetaScrolling(true);
                inlineMetaRecentScrollUntil = Date.now() + 2500;
            };
            try { document.addEventListener('wheel', inlineMetaPreScrollHandler, { capture: true, passive: true }); } catch (e) {}
            try { document.addEventListener('touchmove', inlineMetaPreScrollHandler, { capture: true, passive: true }); } catch (e) {}
            try { document.addEventListener('scroll', inlineMetaScrollHandler, { capture: true, passive: true }); } catch (e) {}
            try { window.addEventListener('resize', inlineMetaScrollHandler, true); } catch (e) {}
            try {
                if (!inlineMetaCompositionStartHandler) {
                    inlineMetaCompositionStartHandler = (event) => {
                        inlineMetaIsComposing = true;
                        try { inlineMetaEditingCleanupHandler?.(event); } catch (e2) {}
                        requestInlineMetaRender(false);
                    };
                }
                if (!inlineMetaCompositionEndHandler) {
                    inlineMetaCompositionEndHandler = () => {
                        inlineMetaIsComposing = false;
                        requestInlineMetaRender(false);
                    };
                }
                document.addEventListener('compositionstart', inlineMetaCompositionStartHandler, true);
                document.addEventListener('compositionend', inlineMetaCompositionEndHandler, true);
                if (!inlineMetaEditingCleanupHandler) {
                    inlineMetaEditingCleanupHandler = (event) => {
                        const eventType = String(event?.type || '').trim();
                        if (QUICKBAR_INLINE_USE_NATIVE_HOST && eventType === 'focusin' && isInlineMetaScrollSettling()) return;
                        const target = event?.target instanceof Element ? event.target : event?.target?.parentElement;
                        const editable = target?.closest?.('[contenteditable="true"]');
                        if (!editable) return;
                        const taskBlock = getTaskBlockElementFromTarget(editable) || editable.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                        if (!taskBlock) return;
                        if (QUICKBAR_INLINE_USE_NATIVE_HOST) {
                            suppressInlineMetaNativeHostForBlock(taskBlock, `edit-${eventType || 'input'}`, 8000);
                            return;
                        }
                        let binding = null;
                        try { binding = resolveTaskBindingFromBlockEl(taskBlock); } catch (e2) { binding = null; }
                        const hostId = String(binding?.attrHostId || binding?.taskId || resolveTaskAttrNodeIdForDetail(taskBlock) || taskBlock?.dataset?.nodeId || '').trim();
                        if (!hostId) return;
                        removeInlineMetaHostByTaskId(hostId, 'in-block');
                        try { queueInlineMetaRenderBlock(taskBlock, false, 420); } catch (e2) {}
                    };
                }
                if (!inlineMetaEditingRestoreHandler) {
                    inlineMetaEditingRestoreHandler = (event) => {
                        const target = event?.target instanceof Element ? event.target : event?.target?.parentElement;
                        const editable = target?.closest?.('[contenteditable="true"]');
                        const taskBlock = getTaskBlockElementFromTarget(editable) || editable?.closest?.('.li[data-node-id],[data-type="NodeListItem"][data-node-id]');
                        if (QUICKBAR_INLINE_USE_NATIVE_HOST && taskBlock) {
                            let binding = null;
                            try { binding = resolveTaskBindingFromBlockEl(taskBlock); } catch (e2) { binding = null; }
                            const hostId = String(binding?.attrHostId || binding?.taskId || resolveTaskAttrNodeIdForDetail(taskBlock) || taskBlock?.dataset?.nodeId || '').trim();
                            if (hostId) {
                                try { inlineMetaNativeHostSuppressedUntil.delete(hostId); } catch (e2) {}
                            }
                        }
                        setTimeout(() => {
                            try { requestInlineMetaRender(false); } catch (e2) {}
                        }, 120);
                    };
                }
                document.addEventListener('focusin', inlineMetaEditingCleanupHandler, true);
                document.addEventListener('beforeinput', inlineMetaEditingCleanupHandler, true);
                document.addEventListener('focusout', inlineMetaEditingRestoreHandler, true);
            } catch (e) {}
            try {
                const eb = globalThis.__taskHorizonPluginInstance?.eventBus || window.siyuan?.eventBus;
                if (eb && typeof eb.on === 'function' && !inlineMetaWsHandler) {
                    inlineMetaWsHandler = (msg) => {
                        const cmd = msg?.detail?.cmd || msg?.cmd;
                        if (cmd !== 'transactions') return;
                        const structuralActions = new Set(['insert', 'delete', 'move', 'append', 'prepend', 'foldHeading', 'unfoldHeading']);
                        let hasStructural = false;
                        try {
                            const data = msg?.detail?.data || msg?.data;
                            const txs = Array.isArray(data) ? data : (data ? [data] : []);
                            for (const tx of txs) {
                                const ops = tx?.doOperations || tx?.operations || [];
                                if (ops.some((op) => structuralActions.has(op?.action))) { hasStructural = true; break; }
                            }
                        } catch (e) {}
                        if (hasStructural) {
                            inlineMetaLayoutCache.clear();
                            inlineMetaNeedSyncBlocks = true;
                            if (inlineMetaWsTimer) clearTimeout(inlineMetaWsTimer);
                            inlineMetaWsTimer = setTimeout(() => {
                                inlineMetaWsTimer = null;
                                requestInlineMetaRender(true);
                            }, 60);
                        }
                    };
                    eb.on('ws-main', inlineMetaWsHandler);
                }
            } catch (e) {}
            requestInlineMetaRender(true);
        }

        function stopInlineMeta() {
            inlineMetaStarted = false;
            clearInlineMetaBootstrapTimers();
            clearInlineMetaWakeTimer();
            if (inlineMetaRenderTimer) clearTimeout(inlineMetaRenderTimer);
            inlineMetaRenderTimer = null;
            clearInlineMetaRenderQueue();
            if (inlineMetaRafId) cancelAnimationFrame(inlineMetaRafId);
            inlineMetaRafId = 0;
            if (inlineMetaPositionRafId) cancelAnimationFrame(inlineMetaPositionRafId);
            inlineMetaPositionRafId = 0;
            if (inlineMetaScrollIdleTimer) clearTimeout(inlineMetaScrollIdleTimer);
            inlineMetaScrollIdleTimer = null;
            if (inlineMetaDeferredPruneTimer) clearTimeout(inlineMetaDeferredPruneTimer);
            inlineMetaDeferredPruneTimer = 0;
            inlineMetaDeferredStructural = false;
            inlineMetaDeferredStructuralAnchor = null;
            cleanupInlineMetaTaskBlocks();
            try { inlineMetaObserver?.disconnect?.(); } catch (e) {}
            inlineMetaObserver = null;
            try { inlineMetaResizeObserver?.disconnect?.(); } catch (e) {}
            inlineMetaResizeObserver = null;
            if (inlineMetaResizeTimer) clearTimeout(inlineMetaResizeTimer);
            inlineMetaResizeTimer = 0;
            inlineMetaResizeLastRenderAt = 0;
            inlineMetaResizeObservedWidths = new WeakMap();
            inlineMetaObservedRoots = [];
            inlineMetaProtyleHints.clear();
            unbindInlineMetaWakeEvents();
            try { if (inlineMetaPreScrollHandler) document.removeEventListener('wheel', inlineMetaPreScrollHandler, true); } catch (e) {}
            try { if (inlineMetaPreScrollHandler) document.removeEventListener('touchmove', inlineMetaPreScrollHandler, true); } catch (e) {}
            inlineMetaPreScrollHandler = null;
            try { if (inlineMetaScrollHandler) document.removeEventListener('scroll', inlineMetaScrollHandler, true); } catch (e) {}
            try { if (inlineMetaScrollHandler) window.removeEventListener('resize', inlineMetaScrollHandler, true); } catch (e) {}
            inlineMetaScrollHandler = null;
            try { if (inlineMetaCompositionStartHandler) document.removeEventListener('compositionstart', inlineMetaCompositionStartHandler, true); } catch (e) {}
            try { if (inlineMetaCompositionEndHandler) document.removeEventListener('compositionend', inlineMetaCompositionEndHandler, true); } catch (e) {}
            try { if (inlineMetaEditingCleanupHandler) document.removeEventListener('focusin', inlineMetaEditingCleanupHandler, true); } catch (e) {}
            try { if (inlineMetaEditingCleanupHandler) document.removeEventListener('beforeinput', inlineMetaEditingCleanupHandler, true); } catch (e) {}
            try { if (inlineMetaEditingRestoreHandler) document.removeEventListener('focusout', inlineMetaEditingRestoreHandler, true); } catch (e) {}
            try {
                const eb = globalThis.__taskHorizonPluginInstance?.eventBus || window.siyuan?.eventBus;
                if (eb && typeof eb.off === 'function' && inlineMetaWsHandler) {
                    eb.off('ws-main', inlineMetaWsHandler);
                }
            } catch (e) {}
            inlineMetaWsHandler = null;
            if (inlineMetaWsTimer) clearTimeout(inlineMetaWsTimer);
            inlineMetaWsTimer = null;
            try { inlineMetaProtyleVisibilityObserver?.disconnect?.(); } catch (e) {}
            inlineMetaProtyleVisibilityObserver = null;
            inlineMetaProtyleVisibility = new WeakMap();
            inlineMetaNativeHostSuppressedUntil.clear();
            inlineMetaIsComposing = false;
            inlineMetaLastInvalidHostPruneAt = 0;
            inlineMetaInvalidHostPruneCursor = 0;
            try { clearQuickbarTaskBindingCaches(); } catch (e) {}
            try { clearInlineMetaRuntimeCaches(); } catch (e) {}
            setInlineMetaScrolling(false);
            removeInlineMetaNodes();
        }

        function refreshInlineMetaMode(forceRefresh = true) {
            invalidateQuickbarInlineSettingsCache();
            if (forceRefresh) clearInlineMetaScopeDocCache();
            invalidateInlineMetaActiveTargetsCache();
            if (isInlineMetaEnabled()) {
                startInlineMeta();
                scheduleInlineMetaBootstrapRenders(!!forceRefresh);
            } else {
                stopInlineMeta();
            }
        }

        // 触发器处理
        let lastTriggerTime = 0;

        function handleTrigger(e) {
            const now = Date.now();
            if (now - lastTriggerTime < 80) return;  // 防抖
            lastTriggerTime = now;
            if (Date.now() < inlineMetaInteractUntil) return;

            const target = e.target;
            if (isQuickbarInteractionTarget(target)) noteQuickbarActivity();
            if (target?.closest?.('.sy-custom-props-inline-host,.sy-custom-props-inline-chip')) return;
            if (shouldSuppressFloatBarForTarget(target, now)) {
                if (floatBar.style.display !== 'none') hideFloatBar();
                return;
            }

            // ========== 新增：检测是否选中了文字 ==========
            const selection = window.getSelection();
            const selectedText = selection?.toString() || '';
            const hasTextSelection = selectedText.length > 0 && selection?.anchorNode;
            
            // 如果选中了文字，检查是否在任何可见的编辑器内
            if (hasTextSelection) {
                let inVisibleEditor = false;
                const anchorNode = selection.anchorNode;
                
                // 向上遍历 DOM 树，检查是否在任何可见的编辑器区域内
                let current = (anchorNode && anchorNode.nodeType === Node.ELEMENT_NODE)
                    ? anchorNode
                    : anchorNode?.parentElement;
                while (current && current !== document.body) {
                    const style = window.getComputedStyle(current);
                    const isVisible = style.display !== 'none' && style.visibility !== 'hidden';
                    
                    // 检查是否在思源编辑器区域内
                    if (current.classList) {
                        if (current.classList.contains('protyle-wysiwyg') || 
                            current.classList.contains('protyle-content') ||
                            current.classList.contains('protyle')) {
                            if (isVisible) {
                                inVisibleEditor = true;
                            }
                        }
                    }
                    // 检查父元素是否可见
                    if (!isVisible) break;
                    current = current.parentElement;
                }
                
                // 如果选中了文字且在可见编辑器内，隐藏自定义悬浮条
                if (inVisibleEditor) {
                    if (floatBar.style.display !== 'none') {
                        hideFloatBar();
                    }
                    return;
                }
            }
            // ========== 新增结束 ==========

            // 如果点击在悬浮条或其弹出层内，不处理
            if (floatBar.contains(target) || selectMenu.contains(target) || inputEditor.contains(target)) return;

            const blockEl = getTaskBlockElementFromTarget(target);

            if (!blockEl) {
                if (floatBar.style.display !== 'none') hideFloatBar();
                return;
            }

            // 阻止事件冒泡，避免触发其他处理
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }
            e.stopPropagation();

            showFloatBar(blockEl);
        }

        function isQuickbarEnabled() {
            try {
                const raw = localStorage.getItem('tm_enable_quickbar');
                if (raw == null) return true;
                const v = JSON.parse(raw);
                return !!v;
            } catch (e) {
                const raw = localStorage.getItem('tm_enable_quickbar');
                if (raw == null) return true;
                return raw !== 'false' && raw !== '0';
            }
        }

        let quickbarStarted = false;
        let storageHandler = null;
        let closePopupsHandler = null;
        let taskAttrUpdatedHandler = null;
        let selectionChangeHandler = null;  // 新增：文字选择变化监听器
        let mouseUpHandler = null;
        let mouseUpSelectionTimer = null;
        let subtaskInheritanceObserver = null;
        let subtaskInheritanceScanTimers = [];
        let subtaskInheritanceEbHandlers = [];

        function scanQuickbarSubtaskInheritanceRoot(root, limit = 48) {
            const scope = root instanceof Element ? root : document;
            const blocks = [];
            try {
                if (scope.matches?.('.li[data-node-id],[data-type=NodeListItem][data-node-id]')) blocks.push(scope);
                scope.querySelectorAll?.('.li[data-node-id],[data-type=NodeListItem][data-node-id]').forEach((el) => blocks.push(el));
            } catch (e) {}
            const seen = new Set();
            for (let i = 0; i < blocks.length && seen.size < limit; i += 1) {
                const blockEl = blocks[i];
                const id = String(blockEl?.dataset?.nodeId || '').trim();
                if (!id || seen.has(id) || !isTaskBlockElement(blockEl)) continue;
                seen.add(id);
                try {
                    maybeRequestQuickbarSubtaskFieldInheritance(blockEl, null, 'dom-task-observer');
                } catch (e) {}
            }
        }

        function scheduleQuickbarSubtaskInheritanceScan(root, delayMs = 160) {
            const timer = setTimeout(() => {
                subtaskInheritanceScanTimers = subtaskInheritanceScanTimers.filter((item) => item !== timer);
                scanQuickbarSubtaskInheritanceRoot(root);
            }, Math.max(0, Number(delayMs) || 0));
            subtaskInheritanceScanTimers.push(timer);
        }

        function startQuickbarSubtaskInheritanceObserver() {
            if (typeof MutationObserver !== 'function') return;
            if (!subtaskInheritanceObserver) {
                subtaskInheritanceObserver = new MutationObserver((mutations) => {
                    let scanRoot = null;
                    for (const m of mutations) {
                        if (m.type !== 'childList') continue;
                        const nodes = Array.from(m.addedNodes || []);
                        const matched = nodes.find((node) => {
                            if (!(node instanceof Element)) return false;
                            return node.matches?.('.li[data-node-id],[data-type=NodeListItem][data-node-id]')
                                || !!node.querySelector?.('.li[data-node-id],[data-type=NodeListItem][data-node-id]');
                        });
                        if (matched) {
                            scanRoot = matched;
                            break;
                        }
                    }
                    if (!scanRoot) return;
                    scheduleQuickbarSubtaskInheritanceScan(scanRoot, QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS);
                    scheduleQuickbarSubtaskInheritanceScan(scanRoot, QUICKBAR_SUBTASK_INHERIT_RETRY_DELAY_MS);
                });
            } else {
                try { subtaskInheritanceObserver.disconnect(); } catch (e) {}
            }
            try {
                document.querySelectorAll('.protyle-wysiwyg').forEach((root) => {
                    subtaskInheritanceObserver.observe(root, { childList: true, subtree: true });
                });
            } catch (e) {}
        }

        function bindQuickbarSubtaskInheritanceEvents() {
            if (subtaskInheritanceEbHandlers.length) return;
            try {
                const eb = globalThis.__taskHorizonPluginInstance?.eventBus || window.siyuan?.eventBus;
                if (!eb || typeof eb.on !== 'function') return;
                const rebind = (e) => {
                    const protyle = e?.protyle || e?.detail?.protyle;
                    const root = protyle?.wysiwyg?.element || null;
                    startQuickbarSubtaskInheritanceObserver();
                    if (root) scheduleQuickbarSubtaskInheritanceScan(root, QUICKBAR_SUBTASK_INHERIT_MIN_AGE_MS);
                };
                ['loaded-protyle-static', 'loaded-protyle-dynamic', 'switch-protyle', 'switch-protyle-mode'].forEach((event) => {
                    try {
                        eb.on(event, rebind);
                        subtaskInheritanceEbHandlers.push({ eb, event, handler: rebind });
                    } catch (e) {}
                });
            } catch (e) {}
        }

        function unbindQuickbarSubtaskInheritanceEvents() {
            subtaskInheritanceEbHandlers.forEach(({ eb, event, handler }) => {
                try { eb.off(event, handler); } catch (e) {}
            });
            subtaskInheritanceEbHandlers = [];
        }

        function stopQuickbarSubtaskInheritanceObserver() {
            try { subtaskInheritanceObserver?.disconnect?.(); } catch (e) {}
            subtaskInheritanceObserver = null;
            subtaskInheritanceScanTimers.forEach((timer) => {
                try { clearTimeout(timer); } catch (e) {}
            });
            subtaskInheritanceScanTimers = [];
        }

        function startQuickbar() {
            if (quickbarStarted) return;
            quickbarStarted = true;

            initStatusOptionsListener();

            // ========== 新增：检测文字选择并隐藏悬浮条 ==========
            const checkAndHideForTextSelection = () => {
                if (floatBar.style.display === 'none') return;
                
                try {
                    const selection = window.getSelection();
                    if (!selection) return;
                    
                    const selectedText = selection.toString();
                    if (!selectedText || selectedText.length === 0) return;
                    
                    // 简单检查：选中的节点是否在任何 protyle 编辑器内
                    let node = selection.anchorNode;
                    while (node && node !== document) {
                        if (node.classList) {
                            const className = node.className || '';
                            if (className.includes('protyle-wysiwyg') || 
                                className.includes('protyle-content') ||
                                className.includes('protyle')) {
                                // 检查元素是否可见（通过 offsetParent）
                                if (node.offsetParent !== null) {
                                    hideFloatBar();
                                    return;
                                }
                            }
                        }
                        node = node.parentNode;
                    }
                } catch (e) {
                    // 忽略错误
                }
            };
            
            // 监听多种事件
            selectionChangeHandler = () => {
                checkAndHideForTextSelection();
                updateInlineMetaSelectionVisibility();
            };
            document.addEventListener('selectionchange', selectionChangeHandler, { passive: true });
            
            // mouseup 事件 - 当用户释放鼠标时检测（选择文字后）
            mouseUpHandler = (e) => {
                // 延迟一点执行，确保 selection 已经更新
                if (mouseUpSelectionTimer) {
                    try { clearTimeout(mouseUpSelectionTimer); } catch (err) {}
                    mouseUpSelectionTimer = null;
                }
                mouseUpSelectionTimer = setTimeout(() => {
                    mouseUpSelectionTimer = null;
                    checkAndHideForTextSelection();
                    updateInlineMetaSelectionVisibility();
                }, 10);
            };
            document.addEventListener('mouseup', mouseUpHandler, true);
            // ========== 新增结束 ==========

            document.addEventListener('pointerup', handleTrigger, true);
            document.addEventListener('click', handleTrigger, true);
            document.addEventListener('scroll', updatePosition, true);
            window.addEventListener('resize', updatePosition, true);
            bindQuickbarAutoHideEvents();
            startQuickbarSubtaskInheritanceObserver();
            bindQuickbarSubtaskInheritanceEvents();

            closePopupsHandler = (e) => {
                if (Date.now() < inlineMetaInteractUntil) return;
                if (floatBar.style.display === 'none') return;
                if (e.target?.closest?.('.sy-custom-props-inline-host,.sy-custom-props-inline-chip')) return;
                if (floatBar.contains(e.target) || selectMenu.contains(e.target) || inputEditor.contains(e.target)) return;
                hideAllPopups();
            };
            document.addEventListener('pointerdown', closePopupsHandler, true);

            taskAttrUpdatedHandler = async (e) => {
                try { syncInlineMetaCacheFromAttrUpdate(e?.detail || {}); } catch (err) {}
                const normalizedAttrKey = normalizeTaskHorizonAttrKeyForDisplay(e?.detail?.attrKey);
                if (!e?.detail || !isReminderRelatedAttrKey(normalizedAttrKey)) return;
                if (!floatBar || floatBar.style.display === 'none') return;
                const incomingTaskId = String(e.detail.taskId || '').trim();
                const incomingResolvedTaskId = String(e.detail.resolvedTaskId || '').trim();
                const incomingAttrHostId = String(e.detail.attrHostId || '').trim();
                const currentIds = new Set([
                    String(currentBlockId || '').trim(),
                    String(currentTaskId || '').trim(),
                    String(resolveCurrentTaskId() || '').trim(),
                ].filter(Boolean));
                if (!currentIds.has(incomingTaskId) && !currentIds.has(incomingResolvedTaskId) && !currentIds.has(incomingAttrHostId)) return;
                if (normalizedAttrKey === 'bookmark') {
                    currentProps = normalizeCustomProps({ ...currentProps, bookmark: String(e.detail.value || '') });
                } else if (currentBlockId) {
                    try {
                        currentProps = await getTaskCustomProps(currentBlockId, true);
                    } catch (err) {}
                }
                await refreshCurrentReminderSnapshot(true);
                if (!floatBar || floatBar.style.display === 'none') return;
                renderFloatBar();
                updatePosition();
            };
            window.addEventListener('tm-task-attr-updated', taskAttrUpdatedHandler);
        }

        function stopQuickbar() {
            if (!quickbarStarted) return;
            quickbarStarted = false;
            try { document.removeEventListener('pointerup', handleTrigger, true); } catch (e) {}
            try { document.removeEventListener('click', handleTrigger, true); } catch (e) {}
            try { document.removeEventListener('scroll', updatePosition, true); } catch (e) {}
            try { window.removeEventListener('resize', updatePosition, true); } catch (e) {}
            unbindQuickbarAutoHideEvents();
            try { if (closePopupsHandler) document.removeEventListener('pointerdown', closePopupsHandler, true); } catch (e) {}
            closePopupsHandler = null;
            try { if (taskAttrUpdatedHandler) window.removeEventListener('tm-task-attr-updated', taskAttrUpdatedHandler); } catch (e) {}
            taskAttrUpdatedHandler = null;

            // ========== 新增：移除文字选择变化监听 ==========
            try { if (selectionChangeHandler) document.removeEventListener('selectionchange', selectionChangeHandler); } catch (e) {}
            selectionChangeHandler = null;
            try { if (mouseUpHandler) document.removeEventListener('mouseup', mouseUpHandler, true); } catch (e) {}
            mouseUpHandler = null;
            if (mouseUpSelectionTimer) {
                try { clearTimeout(mouseUpSelectionTimer); } catch (e) {}
                mouseUpSelectionTimer = null;
            }
            try {
                document.querySelectorAll('.sy-custom-props-inline-layer').forEach((layer) => {
                    layer.classList.remove('is-selection-active');
                });
            } catch (e) {}
            // ========== 新增结束 ==========

            try { if (storageHandler) window.removeEventListener('storage', storageHandler); } catch (e) {}
            storageHandler = null;

            hideFloatBar();
        }

        // 监听任务管理器状态变化
        function initStatusOptionsListener() {
            // 立即读取一次
            loadStatusOptions();

            // 监听localStorage变化（跨标签页同步）
            storageHandler = (e) => {
                try { __tmQBStatusRenderStorageHandler?.(e); } catch (err) {}
                if (e.key === 'tm_quickbar_visible_items') {
                    try {
                        if (floatBar && floatBar.style.display !== 'none') renderFloatBar();
                    } catch (err) {}
                }
                if (e.key === 'tm_custom_field_defs' || e.key === 'tm_custom_field_defs_version') {
                    try {
                        if (floatBar && floatBar.style.display !== 'none') renderFloatBar();
                    } catch (err) {}
                }
            };
            window.addEventListener('storage', storageHandler);
        }

        globalThis.__taskHorizonQuickbarToggle = (enabled) => {
            const on = !!enabled;
            try { localStorage.setItem('tm_enable_quickbar', JSON.stringify(on)); } catch (e) {}
            if (on) startQuickbar();
            else stopQuickbar();
        };
        globalThis.__taskHorizonQuickbarRefreshInline = () => {
            try { refreshInlineMetaMode(true); } catch (e) {}
        };
        globalThis.__taskHorizonQuickbarRefresh = () => {
            try {
                if (floatBar && floatBar.style.display !== 'none') {
                    renderFloatBar();
                    updatePosition();
                }
            } catch (e) {}
        };
        globalThis.__taskHorizonQuickbarInlineStats = () => {
            try { return getQuickbarInlineStats(); } catch (e) { return null; }
        };

        globalThis.__taskHorizonQuickbarCleanup = () => {
            quickbarDisposed = true;
            try { stopQuickbar(); } catch (e) {}
            try { stopInlineMeta(); } catch (e) {}
            try { unbindQuickbarSubtaskInheritanceEvents(); } catch (e) {}
            try { stopQuickbarSubtaskInheritanceObserver(); } catch (e) {}
            try { stopTaskIconPatch(); } catch (e) {}
            try { if (__tmQBStatusRenderStorageHandler) window.removeEventListener('storage', __tmQBStatusRenderStorageHandler); } catch (e) {}
            __tmQBStatusRenderStorageHandler = null;
            try { document.removeEventListener('contextmenu', __tmQBOnContextmenuCapture, true); } catch (e) {}
            try { document.removeEventListener('pointerdown', __tmQBOnPointerdownCapture, true); } catch (e) {}
            try { document.removeEventListener('pointerdown', __tmQBOnInlineMetaPointerdownCapture, true); } catch (e) {}
            try { window.removeEventListener('pointerdown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { window.removeEventListener('mousedown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { window.removeEventListener('keydown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { document.removeEventListener('pointerdown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { document.removeEventListener('mousedown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { document.removeEventListener('keydown', __tmQBOnInlineMetaEditIntentCapture, true); } catch (e) {}
            try { window.removeEventListener('pointerdown', __tmQBOnTaskCheckboxActionCapture, true); } catch (e) {}
            try { window.removeEventListener('mousedown', __tmQBOnTaskCheckboxActionCapture, true); } catch (e) {}
            try { document.removeEventListener('pointerdown', __tmQBOnTaskCheckboxActionCapture, true); } catch (e) {}
            try { document.removeEventListener('mousedown', __tmQBOnTaskCheckboxActionCapture, true); } catch (e) {}
            try { document.removeEventListener('click', __tmQBOnTaskCheckboxActionCapture, true); } catch (e) {}
            try { document.removeEventListener('dragstart', __tmQBOnAttrHostDragStartCapture, true); } catch (e) {}
            try { document.removeEventListener('dragstart', __tmQBOnAttrHostDragSnapshotCapture, true); } catch (e) {}
            inlineMetaHostPointerDownHandler = null;
            try { document.removeEventListener('dragend', __tmQBOnAttrHostDragEndCapture, true); } catch (e) {}
            try { document.removeEventListener('drop', __tmQBOnAttrHostDragEndCapture, true); } catch (e) {}
            try { if (quickbarAttrHostMigrationTimer) clearTimeout(quickbarAttrHostMigrationTimer); } catch (e) {}
            quickbarAttrHostMigrationTimer = 0;
            quickbarAttrHostMigrationScheduler = null;
            try { delete globalThis.__taskHorizonQuickbarScheduleAttrHostMigration; } catch (e) {}
            try { blockMenuObserver?.disconnect?.(); } catch (e) {}
            blockMenuObserver = null;
            try { delete globalThis.__taskHorizonQuickbarToggle; } catch (e) {}
            try { delete globalThis.__taskHorizonQuickbarRefreshInline; } catch (e) {}
            try { delete globalThis.__taskHorizonQuickbarRefresh; } catch (e) {}
            try { delete globalThis.__taskHorizonQuickbarInlineStats; } catch (e) {}
            try { delete globalThis.__taskHorizonQuickbarCleanup; } catch (e) {}
            try { delete globalThis.__taskHorizonQuickbarLoaded; } catch (e) {}
        };

        if (isQuickbarEnabled()) startQuickbar();
        else stopQuickbar();
        startQuickbarSubtaskInheritanceObserver();
        bindQuickbarSubtaskInheritanceEvents();
        refreshInlineMetaMode(true);
    }

    // ==================== Task Icon Patch ====================
    // data-task="-" 的任务项，图标应显示为 iconTaskCancelled 而非 iconCheck
    const taskIconMap = {
        '-': 'iconTaskCancelled',
    };
    let taskIconPatchObserver = null;
    let taskIconPatchEbHandlers = [];

    function patchTaskIcons(root) {
        const scope = root || document;
        try {
            scope.querySelectorAll('.li[data-task]').forEach((li) => {
                const targetIcon = taskIconMap[li.getAttribute('data-task')];
                if (!targetIcon) return;
                const use = li.querySelector(':scope > .protyle-action--task use');
                if (use && use.getAttribute('xlink:href') !== '#' + targetIcon) {
                    use.setAttribute('xlink:href', '#' + targetIcon);
                }
            });
        } catch (e) {}
    }

    let _patchTimer = null;
    function schedulePatchTaskIcons(root, delay = 0) {
        clearTimeout(_patchTimer);
        _patchTimer = setTimeout(() => patchTaskIcons(root), delay);
    }

    function startTaskIconPatch() {
        patchTaskIcons(document);
        try {
            taskIconPatchObserver = new MutationObserver((mutations) => {
                let needPatch = false;
                for (const m of mutations) {
                    if (m.type === 'attributes' && m.attributeName === 'data-task') {
                        needPatch = true;
                        break;
                    }
                    if (m.type === 'childList') {
                        const nodes = [...m.addedNodes];
                        if (nodes.some((n) => n.nodeType === Node.ELEMENT_NODE && (n.matches?.('[data-task]') || n.querySelector?.('[data-task]')))) {
                            needPatch = true;
                            break;
                        }
                    }
                }
                if (needPatch) {
                    // 延迟执行，确保在思源完成所有 DOM 操作（如重写 <use> href）之后
                    schedulePatchTaskIcons(document, 0);
                }
            });
            document.querySelectorAll('.protyle-wysiwyg').forEach((root) => {
                taskIconPatchObserver.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-task'] });
            });
        } catch (e) {}
        try {
            const eb = globalThis.__taskHorizonPluginInstance?.eventBus || window.siyuan?.eventBus;
            if (eb && typeof eb.on === 'function') {
                const onStatic = (e) => {
                    const protyle = e?.protyle || e?.detail?.protyle;
                    const root = protyle?.wysiwyg?.element;
                    schedulePatchTaskIcons(root || document, 20);
                };
                const onDynamic = (e) => {
                    const protyle = e?.protyle || e?.detail?.protyle;
                    const root = protyle?.wysiwyg?.element;
                    schedulePatchTaskIcons(root || document, 20);
                };
                const onWsMain = (msg) => {
                    const cmd = msg?.detail?.cmd || msg?.cmd;
                    if (cmd !== 'transactions') return;
                    try {
                        const data = msg?.detail?.data || msg?.data;
                        const txs = Array.isArray(data) ? data : (data ? [data] : []);
                        let hasUpdate = false;
                        for (const tx of txs) {
                            const ops = tx?.doOperations || tx?.operations || [];
                            for (const op of ops) {
                                if (op?.action === 'update') { hasUpdate = true; break; }
                            }
                            if (hasUpdate) break;
                        }
                        if (!hasUpdate) return;
                    } catch (e) {}
                    schedulePatchTaskIcons(document, 60);
                };
                eb.on('loaded-protyle-static', onStatic);
                eb.on('loaded-protyle-dynamic', onDynamic);
                eb.on('ws-main', onWsMain);
                taskIconPatchEbHandlers.push({ eb, event: 'loaded-protyle-static', handler: onStatic });
                taskIconPatchEbHandlers.push({ eb, event: 'loaded-protyle-dynamic', handler: onDynamic });
                taskIconPatchEbHandlers.push({ eb, event: 'ws-main', handler: onWsMain });
            }
        } catch (e) {}
    }

    function stopTaskIconPatch() {
        clearTimeout(_patchTimer);
        _patchTimer = null;
        try { taskIconPatchObserver?.disconnect?.(); } catch (e) {}
        taskIconPatchObserver = null;
        taskIconPatchEbHandlers.forEach(({ eb, event, handler }) => {
            try { eb.off(event, handler); } catch (e) {}
        });
        taskIconPatchEbHandlers = [];
    }

    // 启动 task icon patch
    startTaskIconPatch();

    // 思源笔记 API 请求封装
    async function requestApi(url, data, method = 'POST') {
        try {
            const response = await fetch(url, {
                method: method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data || {})
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            return await response.json();
        } catch (error) {
            console.error(`API请求失败 ${url}:`, error);
            throw error;
        }
    }

    // 思源笔记 API 封装
    function showMessage(message, isError = false, delay = 7000) {
        return fetch('/api/notification/' + (isError ? 'pushErrMsg' : 'pushMsg'), {
            method: "POST",
            body: JSON.stringify({ "msg": message, "timeout": delay })
        });
    }

})();
