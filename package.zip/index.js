const { Plugin, openTab, openMobileFileById } = require("siyuan");

const PLUGIN_ID = "siyuan-plugin-task-horizon";
const TASK_SCRIPT_PATH = `/data/plugins/${PLUGIN_ID}/task.js`;
const QUICKBAR_SCRIPT_PATH = `/data/plugins/${PLUGIN_ID}/quickbar.js`;
const FULLCALENDAR_MIN_SCRIPT_PATH = `/data/plugins/${PLUGIN_ID}/src/fullcalendar/index.global.min.js`;
const FULLCALENDAR_ZH_LOCALE_SCRIPT_PATH = `/data/plugins/${PLUGIN_ID}/src/fullcalendar/locales/zh-cn.global.min.js`;
const CALENDAR_VIEW_SCRIPT_PATH = `/data/plugins/${PLUGIN_ID}/calendar-view.js`;
const CALENDAR_VIEW_CSS_PATH = `/data/plugins/${PLUGIN_ID}/calendar-view.css`;
const TAB_TYPE = "task-horizon";
const TAB_TITLE = "任务管理器";
const ICON_ID = "iconTaskHorizon";
const CUSTOM_TAB_ID = PLUGIN_ID + TAB_TYPE;

const ICON_SYMBOL = `<symbol id="${ICON_ID}" viewBox="0 0 24 24">
  <g transform="translate(12 12) scale(1.25) translate(-12 -12)" fill="none" stroke="currentColor">
    <path d="M7.25 3.75h9.5c1.105 0 2 .895 2 2v12.5c0 1.105-.895 2-2 2h-9.5c-1.105 0-2-.895-2-2V5.75c0-1.105.895-2 2-2Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M8.75 7h6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M8.75 10.5h6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M8.75 14h4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M12.1 17.6l1.55 1.55 3.2-3.5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
</symbol>`;

const fetchText = async (url, data) => {
    const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data || {}),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
};

const unwrapGetFileText = (raw) => {
    const text = String(raw ?? "");
    const trimmed = text.replace(/^\uFEFF/, "").trim();
    if (!trimmed) return "";
    if (!trimmed.startsWith("{")) return text;
    if (!/\"(code|msg|data|content)\"\s*:/.test(trimmed)) return text;

    let obj;
    try {
        obj = JSON.parse(trimmed);
    } catch (e) {
        throw new Error(`getFile response looks like JSON but failed to parse: ${e?.message || e}`);
    }

    if (obj && typeof obj === "object") {
        if (typeof obj.data === "string") return obj.data;
        if (typeof obj.content === "string") return obj.content;
        if (obj.data && typeof obj.data === "object" && typeof obj.data.content === "string") return obj.data.content;
        if (typeof obj.msg === "string" && typeof obj.code !== "undefined") {
            throw new Error(`getFile error: ${obj.code} ${obj.msg}`);
        }
    }
    return text;
};

const loadScriptText = async (path, sourceName) => {
    try {
        const raw = await fetchText("/api/file/getFile", { path });
        const code = unwrapGetFileText(raw);
        if (!code || !code.trim()) throw new Error("empty script");

        const script = document.createElement("script");
        script.textContent = code + `\n//# sourceURL=${sourceName}`;
        document.head.appendChild(script);
        script.remove();

        return true;
    } catch (e) {
        const msg = String(e?.message || e || "");
        if (msg.includes("getFile error: 404") || msg.includes("file does not exist")) {
            console.warn("[task-horizon] script not found", sourceName);
            return false;
        }
        console.error("[task-horizon] load script failed", sourceName, e);
        return false;
    }
};

const loadStyleText = async (path, sourceName) => {
    try {
        const raw = await fetchText("/api/file/getFile", { path });
        const css = unwrapGetFileText(raw);
        if (!css || !css.trim()) throw new Error("empty style");
        const style = document.createElement("style");
        style.textContent = css + `\n/*# sourceURL=${sourceName} */`;
        style.dataset.tmStyleSource = sourceName || "";
        document.head.appendChild(style);
        return true;
    } catch (e) {
        const msg = String(e?.message || e || "");
        if (msg.includes("getFile error: 404") || msg.includes("file does not exist")) {
            console.warn("[task-horizon] style not found", sourceName);
            return false;
        }
        console.error("[task-horizon] load style failed", sourceName, e);
        return false;
    }
};

module.exports = class TaskHorizonPlugin extends Plugin {
    async onload() {
        const mountToken = String(Date.now());
        this._mountToken = mountToken;
        this._mountExistingTabsStopped = false;
        this._mountExistingTabsTimer = null;
        globalThis.__taskHorizonPluginApp = this.app;
        globalThis.__taskHorizonPluginInstance = this;
        globalThis.__taskHorizonPluginIsMobile = !!this.isMobile;
        globalThis.__taskHorizonOpenTab = typeof openTab === "function" ? openTab : null;
        globalThis.__taskHorizonOpenMobileFileById = typeof openMobileFileById === "function" ? openMobileFileById : null;
        globalThis.__taskHorizonOpenTabView = this.openTaskHorizonTab.bind(this);
        globalThis.__taskHorizonCustomTabId = CUSTOM_TAB_ID;
        globalThis.__taskHorizonTabType = TAB_TYPE;
        globalThis.__taskHorizonMountToken = mountToken;
        try { this.addIcons(ICON_SYMBOL); } catch (e) {}
        this.ensureCustomTab();
        try {
            document.querySelectorAll('style[data-tm-style-source="calendar-view.css"]').forEach((el) => { try { el.remove(); } catch (e) {} });
        } catch (e) {}
        try {
            globalThis.__tmCalendar?.cleanup?.();
        } catch (e) {}
        try {
            delete globalThis.__tmCalendar;
        } catch (e) {}
        await loadScriptText(TASK_SCRIPT_PATH, "task.js");
        await loadScriptText(QUICKBAR_SCRIPT_PATH, "quickbar.js");
        await loadScriptText(FULLCALENDAR_MIN_SCRIPT_PATH, "fullcalendar/index.global.min.js");
        await loadScriptText(FULLCALENDAR_ZH_LOCALE_SCRIPT_PATH, "fullcalendar/locales/zh-cn.global.min.js");
        await loadScriptText(CALENDAR_VIEW_SCRIPT_PATH, "calendar-view.js");
        await loadStyleText(CALENDAR_VIEW_CSS_PATH, "calendar-view.css");
        this.mountExistingTabs();
    }

    ensureCustomTab() {
        if (this._tabRegistered) return;
        const type = TAB_TYPE;
        this.addTab({
            type,
            init() {
                // Use function syntax to preserve `this` as the tab instance
                this.element.classList.add("tm-tab-root");
                this.element.style.display = "flex";
                this.element.style.flexDirection = "column";
                this.element.style.height = "100%";
                globalThis.__taskHorizonTabElement = this.element;
                if (typeof globalThis.__taskHorizonMount === "function") {
                    globalThis.__taskHorizonMount(this.element);
                }
            },
        });
        this._tabRegistered = true;
    }

    mountExistingTabs() {
        if (this.isMobile) return;
        let tries = 0;
        const run = () => {
            if (this._mountExistingTabsStopped) return;
            tries += 1;
            const mountFn = globalThis.__taskHorizonMount;
            const roots = Array.from(document.querySelectorAll(".tm-tab-root"));
            const token = String(globalThis.__taskHorizonMountToken || this._mountToken || "");
            if (typeof mountFn === "function") {
                roots.forEach((el) => {
                    if (!el) return;
                    if (token && el.dataset?.tmTaskHorizonMounted === token) return;
                    try {
                        globalThis.__taskHorizonTabElement = el;
                        mountFn(el);
                        if (token) el.dataset.tmTaskHorizonMounted = token;
                    } catch (e) {}
                });
                return;
            }
            if (tries < 50) this._mountExistingTabsTimer = setTimeout(run, 200);
        };
        run();
    }

    openTaskHorizonTab() {
        if (this.isMobile) {
            // Mobile has no tabs; fallback is handled by task.js.
            return;
        }
        this.ensureCustomTab();
        openTab({
            app: this.app,
            openNewTab: false,
            custom: {
                title: TAB_TITLE,
                icon: ICON_ID,
                id: CUSTOM_TAB_ID,
            },
        });
    }

    onunload() {
        try {
            this._mountExistingTabsStopped = true;
            if (this._mountExistingTabsTimer) {
                clearTimeout(this._mountExistingTabsTimer);
                this._mountExistingTabsTimer = null;
            }
        } catch (e) {}
        try { globalThis.__TaskManagerCleanup?.(); } catch (e) {}
        try { globalThis.__taskHorizonQuickbarCleanup?.(); } catch (e) {}
        try { globalThis.tmClose?.(); } catch (e) {}

        try {
            const styles = Array.from(document.querySelectorAll('style[data-tm-style-source]'));
            styles.forEach((el) => {
                const s = String(el?.dataset?.tmStyleSource || '');
                if (s === 'calendar-view.css') {
                    try { el.remove(); } catch (e) {}
                }
            });
        } catch (e) {}

        try { delete globalThis.__taskHorizonPluginApp; } catch (e) {}
        try { delete globalThis.__taskHorizonPluginInstance; } catch (e) {}
        try { delete globalThis.__taskHorizonPluginIsMobile; } catch (e) {}
        try { delete globalThis.__taskHorizonOpenTab; } catch (e) {}
        try { delete globalThis.__taskHorizonOpenMobileFileById; } catch (e) {}
        try { delete globalThis.__taskHorizonOpenTabView; } catch (e) {}
        try { delete globalThis.__taskHorizonCustomTabId; } catch (e) {}
        try { delete globalThis.__taskHorizonTabElement; } catch (e) {}
        try { delete globalThis.__taskHorizonQuickbarLoaded; } catch (e) {}
        try { delete globalThis.__taskHorizonQuickbarToggle; } catch (e) {}
        try { delete globalThis.__taskHorizonQuickbarCleanup; } catch (e) {}
        try { delete globalThis.__taskHorizonMount; } catch (e) {}
        try { delete globalThis.__TaskManagerCleanup; } catch (e) {}
        try { delete globalThis.__taskHorizonMountToken; } catch (e) {}
        try { delete globalThis.__taskHorizonTabType; } catch (e) {}
    }

    async uninstall() {
        try { globalThis.__TaskManagerCleanup?.(); } catch (e) {}
        try { globalThis.__taskHorizonQuickbarCleanup?.(); } catch (e) {}

        try {
            const ns = globalThis["siyuan-plugin-task-horizon"];
            if (ns && typeof ns.uninstallCleanup === "function") {
                await ns.uninstallCleanup();
            }
        } catch (e) {}

        try {
            const paths = [
                "/data/storage/petal/siyuan-plugin-task-horizon/task-settings.json",
                "/data/storage/petal/siyuan-plugin-task-horizon/task-meta.json",
            ];
            await Promise.all(paths.map((path) => fetch("/api/file/removeFile", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ path }),
            }).catch(() => null)));
        } catch (e) {}
    }
};
