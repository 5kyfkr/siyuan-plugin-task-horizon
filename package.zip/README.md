# Task Horizon

A task manager plugin for SiYuan with custom filters, grouping, and sorting.

## Usage
1. Enable the plugin in SiYuan.
2. Refresh the app.
3. Click the "📋 任务管理" button in the bottom-right corner to open the manager.